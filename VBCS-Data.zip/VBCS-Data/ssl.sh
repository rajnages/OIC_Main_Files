#!/bin/bash

# Define variables
DOMAIN=$1        # Replace with your domain (e.g., example.com)
EMAIL=$2         # Replace with your email for Let's Encrypt notifications
USE_SELF_SIGNED=$3  # Set to "yes" to use a self-signed certificate, leave blank for Let's Encrypt

# Check if domain and email are provided
if [[ -z "$DOMAIN" || -z "$EMAIL" ]]; then
    echo "Usage: $0 cloud-dev.xyz nagesrajavarapu@gmail.com [yes|no]"
    echo "Set the third argument to 'yes' to use a self-signed certificate."
    exit 1
fi

# Step 1: Update system
echo "Updating system..."
sudo apt update && sudo apt upgrade -y

# Step 2: Install dependencies
echo "Installing dependencies..."
sudo apt install curl openssh-server ca-certificates tzdata perl -y

# Step 3: Add GitLab repository and install GitLab CE
echo "Adding GitLab repository and installing GitLab CE..."
curl -fsSL https://packages.gitlab.com/install/repositories/gitlab/gitlab-ce/script.deb.sh | sudo bash
sudo EXTERNAL_URL="http://$DOMAIN" apt install gitlab-ce -y

# Step 4: Configure SSL
if [[ "$USE_SELF_SIGNED" == "yes" ]]; then
    echo "Creating a self-signed SSL certificate..."

    # Generate a private key and self-signed certificate
    sudo mkdir -p /etc/gitlab/ssl
    sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
        -keyout /etc/gitlab/ssl/$DOMAIN.key \
        -out /etc/gitlab/ssl/$DOMAIN.crt \
        -subj "/C=US/ST=State/L=City/O=Organization/OU=Department/CN=$DOMAIN"

    # Update GitLab configuration for self-signed SSL
    sudo nano /etc/gitlab/gitlab.rb <<EOF
external_url 'https://$DOMAIN'
nginx['ssl_certificate'] = "/etc/gitlab/ssl/$DOMAIN.crt"
nginx['ssl_certificate_key'] = "/etc/gitlab/ssl/$DOMAIN.key"
EOF

else
    echo "Configuring GitLab with Let's Encrypt SSL..."

    # Update GitLab configuration for Let's Encrypt
    sudo nano /etc/gitlab/gitlab.rb <<EOF
external_url 'https://$DOMAIN'
letsencrypt['enable'] = true
letsencrypt['contact_emails'] = ['$EMAIL']
EOF
fi

# Step 5: Reconfigure GitLab
echo "Reconfiguring GitLab..."
sudo gitlab-ctl reconfigure

# Step 6: Open firewall ports
echo "Opening firewall ports for HTTP, HTTPS, and SSH..."
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 22/tcp
sudo ufw enable

# Step 7: Verify GitLab services
echo "Verifying GitLab services..."
sudo gitlab-ctl status

# Step 8: Test access to GitLab
echo "GitLab installation complete!"
if [[ "$USE_SELF_SIGNED" == "yes" ]]; then
    echo "Access your GitLab instance at: https://$DOMAIN (Self-Signed Certificate)"
    echo "Note: Browsers will show a warning for self-signed certificates."
else
    echo "Access your GitLab instance at: https://$DOMAIN (Let's Encrypt SSL)"
fi


   
   