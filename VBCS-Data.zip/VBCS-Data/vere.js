PageModule.prototype.getData2 = function (Dbo, demandid, qualification) {
    var data = [];
    let demandbo;
    let mainobj = {
      DE: true,
      PSC: true,
      Cap: true
    }
    if (qualification) {
      if (demandid) {
        if (qualification == 'DE') {
        //   demandbo = Dbo.filter(ele => ele.globalPractice === 180);
          mainobj.DE = false;
        }
        if (qualification == 'PSC') {
        //   demandbo = Dbo.filter(ele => ele.pSCQualified === 'No');
          mainobj.PSC = false;
        }
        if (qualification == 'Cap') {
        //   demandbo = Dbo.filter(ele => ele.capabilityQualified === 'No');
          mainobj.Cap = false;
        }
        let demand = Dbo.find(ele => ele.teamRequestNumber == demandid);
        let temp = {};
        temp['teamRequestNumber'] = demand.teamRequestNumber;
        temp['dE'] = demand.globalPractice === 180 && !mainobj.DE ? 'No' : '';
        temp['pSC'] = demand.pSCQualified === 'No' && !mainobj.PSC ? 'No' : '';
        temp['cap'] = demand.capabilityQualified === 'No' && !mainobj.Cap ? 'No' : '';
        data.push(temp);
      }
      else {
        if (qualification == 'DE') {
          demandbo = Dbo.filter(ele => ele.globalPractice === 180);
        }
        if (qualification == 'PSC') {
          demandbo = Dbo.filter(ele => ele.pSCQualified === 'No');
        }
        if (qualification == 'Cap') {
          demandbo = Dbo.filter(ele => ele.capabilityQualified === 'No');
        }
        for (let i = 0; i < demandbo.length; i++) {
          let temp = {};
          temp['teamRequestNumber'] = demandbo[i].teamRequestNumber;
          temp['skillGroup'] = demandbo[i].skillGroup;
          temp['dE'] = demandbo[i].globalPractice === 180 ? 'No' : 'Yes';
          temp['pSC'] = demandbo[i].pSCQualified === 'No' ? 'No' : 'Yes';
          temp['cap'] = demandbo[i].capabilityQualified === 'No' ? 'No' : 'Yes';
          data.push(temp);
        }
        mainobj.DE = false;
        mainobj.PSC = false;
        mainobj.Cap = false;
      }

    }
    else {
      let demand = Dbo.find(ele => ele.teamRequestNumber == demandid);
      let temp = {};
      temp['teamRequestNumber'] = demand.teamRequestNumber;
      temp['dE'] = demand.globalPractice === 180 ? 'No' : 'Yes';
      temp['pSC'] = demand.pSCQualified === 'No' ? 'No' : 'Yes';
      temp['cap'] = demand.capabilityQualified === 'No' ? 'No' : 'Yes';
      data.push(temp);
      mainobj.DE = false;
      mainobj.PSC = false;
      mainobj.Cap = false;
    }
    return [data, mainobj];
  }