# AWS EC2:
- AWS EC2, or Amazon Elastic Compute Cloud, is a fundamental service on AWS that provides scalable computing capacity in the cloud. Think of it as virtual servers that you can rent, allowing you to run your applications without the need for physical hardware

# Why use EC2?
- Scalability: Easily scale your applications up or down to meet fluctuating demand.
- Flexibility: Choose from a wide range of instance types to fit specific workloads.
- Reliability: Benefit from AWS's robust infrastructure and redundancy.
- Cost-Effectiveness: Pay only for the resources you use.
- Security: Leverage AWS's built-in security features.


# Example 
- Sure, let's say you're building a popular e-commerce website. During peak shopping seasons like Black Friday, you might experience a surge in traffic. To handle this increased load, you can use EC2 Auto Scaling Groups to automatically launch additional EC2 instances to distribute the traffic. This ensures your website remains responsive and performs optimally, even under heavy load.

- Additionally, you can use EC2 to host your backend services, such as databases and application servers. By leveraging EC2's flexibility and scalability, you can efficiently manage your infrastructure and meet the demands of your growing business.

# Challenges Solved by EC2:
- Infrastructure Setup: EC2 simplifies the process of setting up and configuring servers.
- Scalability: Easily scale resources up or down to meet demand.
- Reliability: Benefit from AWS's highly reliable infrastructure.
- Cost-Effectiveness: Pay only for the resources you use.
- Security: Leverage AWS's robust security features.


# AWS EC2 Pricing Models:
- On-Demand: Pay as you go, no upfront commitment.
- Reserved Instances: Significant discounts for 1 or 3-year commitments.
- Savings Plans: Flexible pricing with discounts based on usage.
- Spot Instances: Lowest-priced, but can be interrupted.

# Real-World Scenario: E-commerce Startup
- An e-commerce startup is launching a new product line. They anticipate a significant surge in website traffic during the launch period.

# Here's how they can leverage different EC2 pricing models:
# Development and Testing:
- On-Demand Instances: During the development and testing phases, they can use On-Demand instances to quickly spin up and terminate instances as needed. This provides flexibility and avoids long-term commitments.

# Production Environment (Initial Phase):
- Reserved Instances: To handle the expected baseline traffic, they can purchase Reserved Instances for a 1-year term to get significant discounts.

# Handling Launch-Day Traffic Spike:
- Spot Instances: To handle the temporary surge in traffic, they can utilize Spot Instances. While there's a risk of interruptions, the significant cost savings during this peak period can offset the potential downtime.


# AMIs
- Amazon Machine Image (AMI)
  An AMI is a template that contains the software configuration (operating system, applications, libraries, etc.) required to launch an EC2 instance. Think of it as a blueprint for creating new EC2 instances.


# Placement groups
- A placement group in AWS EC2 is a way to control how instances are placed on underlying hardware to optimize performance or improve fault tolerance. It helps ensure instances are either close together for better networking or spread out for higher availability.

- Cluster Placement Group: Places instances close together on the same hardware for low latency and high throughput.
- Spread Placement Group: Spreads instances across different hardware for high availability.
- Partition Placement Group: Divides instances into isolated partitions for fault isolation in distributed systems.

# global services and regional services

# Global services
1. IAM
2. s3
3. AWS DIRECT CONNECT
4. ROUTE 53
5. CLOUD FRONT
6. WAF & SHIELD
7. ARTIFACT
8. TRUSTED ADVISOR
9. personal health dashboard

# Regional services
1. EC2, ECS, LAMBDA, Lightsail
2. EBS,EFS,storage gateway
3. vpc
4. RDA, dynamodb, redshift, elasticache
5. elb, autoscaling
6. cloudwatch, cloudtrail
7. SNS
8. database migration service
9. snowball
10. guardduty, KMS, aws CloudHSM, inspector, config, catalog


# AWS Storage
1. EBS(elastic block storage)
-> attach directly to ec2 instances
-> similar to plugging in a usb Drive to computer
-> each USB drive that is attached adds a fixed amount of  additional storage
-> ebs volumes cannot be shared among multiple instaces

2. EFS(elastic file storage):
-> offers a solution to some of limitations of efs
-> efs is a network file system it can be shared among several different instaces.
-> as a network drive, efs has increased latency in data storage and retrieval when compared to ebs
-> also considerbly more costly than an ebs volume

3. Object storage (s3, Glacier):
-> used for object-level data storage
-> unlike efs and ebs object stoarge can not be mounted to an ec2 instance
-> object storage can not have lock, or permissions as you can with efs and ebs
-> ideal for storing images, video files, static html pages

# SnapShots
1. An EBS snapshot is a backup of an EBS volume that saves its data at a specific point in time and can be used to restore or create new volume
2. SSD stands for Solid State Drive.

# image builder
- AWS Image Builder is a service to automate the creation, customization, and management of system images (like AMIs). It helps maintain secure, up-to-date, and consistent images for EC2 instances.

# Problems Solved by AWS Image Builder:
- Manual Image Creation: Automates image updates and customization, reducing manual effort.
- Inconsistent Images: Ensures consistency across environments with standardized, pre-tested images.
- Outdated Images: Keeps images updated with the latest patches and software.
- Security Risks: Integrates security hardening and compliance checks into the image-building process.
- Time-Consuming Processes: Speeds up deployment with reusable automation pipelines.

1. Lifecycle Manager in AWS is a service that automates the creation, retention, and deletion of Amazon Machine Images (AMIs) and EBS snapshots based on defined policies.

2. Key pairs in AWS are a set of cryptographic keys used for secure SSH (Linux) or RDP (Windows) access to EC2 instances. A key pair consists of a public key (stored by AWS) and a private key (kept by the user). When launching an EC2 instance, the private key is used to authenticate and securely connect to the instance.

3. Network interfaces in AWS refer to the virtual network cards attached to EC2 instances, allowing them to connect to a VPC. The primary type is the Elastic Network Interface (ENI), which can have multiple IP addresses, security groups, and be moved between instances


# load balancer:
- A load balancer distributes incoming application traffic across multiple targets (such as EC2 instances) to ensure no single resource is overwhelmed, thereby enhancing availability, fault tolerance, and scalability. 

# Why Use Load Balancing?
1. Distribute Traffic: Balances the load across multiple resources (e.g., EC2 instances) to prevent bottlenecks.
2. High Availability: Ensures your application remains available by routing traffic to healthy instances.
3. Scalability: Automatically adjusts the number of instances behind the load balancer based on traffic demand.
4. Improved Fault Tolerance: Detects unhealthy instances and redirects traffic to healthy ones.

# Types of Load Balancers in AWS
1. Classic Load Balancer (CLB):
- Use Case: Simple load balancing for HTTP, HTTPS, TCP, and SSL.
- Features: Supports Layer 4 and Layer 7. Best for legacy applications.

2. Application Load Balancer (ALB):
- Use Case: Best for HTTP/HTTPS with content-based routing.
- Features: Routes based on URL paths, headers, and methods. Ideal for microservices.

3. Network Load Balancer (NLB):
- Use Case: High-performance, low-latency traffic (TCP).
- Features: Layer 4 routing, ultra-low latency, and supports TLS termination. Best for non-HTTP traffic like gaming.

4. Gateway Load Balancer (GWLB):
- Use Case: Distributes traffic across network appliances (e.g., firewalls).
- Features: Routes traffic to virtual appliances, simplifying network configurations.

# How AWS Load Balancer Works
1. Client Request: A user sends a request to the application (e.g., a website).
2. DNS Resolution: The DNS system resolves the request to the load balancer’s IP.
3. Traffic Routing: The load balancer routes the request to one of the available backend instances based on its configured routing rules.
4. Health Checks: Periodic health checks are done on backend instances to ensure they are healthy. If a backend fails a health check, the load balancer stops routing traffic to it.

# stickness:
- Stickiness (or session persistence) ensures that all requests from a user go to the same backend server during a session.
- How It Works:
1. Cookie-Based: Load balancer tracks sessions using cookies.
2. IP-Based: Tracks sessions using the user's IP address.
 
# routing:
# application-level routing types
1. Path-Based Routing
- Definition: Routes traffic based on the URL path in the incoming request.
- Example:
- /api/v1 → Backend Service A
- /static/images → Backend Service B
- Use Case: Useful in microservices to direct specific parts of an application to different services.
- Common Use: In Application Load Balancers (ALB) or reverse proxies like NGINX.

2. Host-Based Routing
- Definition: Routes traffic based on the host or domain name in the HTTP request.
- Example:
- app1.example.com → Backend Service A
- app2.example.com → Backend Service B
- Use Case: Hosting multiple applications or services on a single load balancer or server.
- Common Use: Multi-tenant systems or applications with subdomains.


# Target Groups:
- Target Groups are used to route requests to a set of resources (such as EC2 instances, IP addresses, or Lambda functions) through a load balancer.

# Key Points:
- Purpose: Define the destinations (targets) for incoming traffic handled by a load balancer.
- Types of Targets: EC2 instances, IP addresses, or Lambda functions.
- Health Checks: Monitors the health of the targets, ensuring that traffic is only sent to healthy resources.
- Routing: Load balancers route traffic to the target group based on the configured rules.

# Example:
- In Application Load Balancer (ALB), you can have different target groups for different services, like one target group for the front-end service and another for the back-end service.

# Auto Scaling Group (ASG) in AWS
- An Auto Scaling Group (ASG) is a collection of Amazon EC2 instances that automatically adjust based on demand, ensuring your application remains available and scalable.

# Key Features:
- Automatic Scaling: Automatically adds or removes EC2 instances based on demand (e.g., increasing traffic or reduced load).
- Health Checks: Monitors the health of EC2 instances and replaces unhealthy ones to maintain high availability.
- Instance Management: Ensures that the correct number of instances are running to handle the application load, even during failures.
- Scaling Policies: Configures how and when to scale, based on metrics like CPU usage or memory utilization.

# Benefits:
- Improved Availability: Ensures application uptime by replacing unhealthy instances.
- Cost Efficiency: Scales the number of instances up or down, helping optimize costs based on traffic.
- Dynamic Scaling: Automatically adjusts based on real-time application demand.




=========================================================================================================

# ec2 pricing models:
on-demand : 
- You pay for the instance by the hour or second, with no long-term commitment.
- highest bill is yearly come => 3285$
- Good for development, testing, or short-term workloads.
- Pay as you go, no upfront cost, and you can stop and start at any time.

reserved instaces:
- A pricing model where you commit to using an instance for a one- or three-year term.
-  You reserve EC2 capacity and receive a significant discount over On-Demand
- You pay for the reserved instance upfront or in installments.
- Discounts can be up to 75% compared to On-Demand pricing.
Types:
- Standard Reserved Instances: Best for predictable workloads, offering the largest discount.
- Convertible Reserved Instances: Allows you to change the instance family, operating system, or tenancy  during the term.
- Scheduled Reserved Instances: 

spot instaces:
- Instances that allow you to bid for unused EC2 capacity at a lower price.
- Can be up to 90% cheaper than On-Demand instances.
- You pay the current spot price, which fluctuates based on supply and demand.
- Instances can be interrupted, and you need to handle this in your architecture (e.g., with Auto Scaling or checkpointing).