##########################################################################################################################

# OIC gen3/gen2 Over View

OIC Gen3 -> Redwood theme -> isolated environment -> Projects(connections,integrations,libraries,packages,events,RPA,Deploy,design)
			best feature of we design here and we can deploy same and we can observe here get the any errors
            Design(application integration stuff),Observability(track dahsboards and errors and instances all)
			limit of notifications -> 5000 per pack per hour -> one pack 1,20,000 notifications per day
			
For Oracle Integration Cloud => Each message pack includes Less than 5K messages per hour
						        You can select up to 12 message packs in the user interface.
						  
Oracle Integration for SaaS: You can select up to 43 message packs in the user interface.
							 This is monthly based cost
							 
If you brought an existing Oracle Fusion Middleware license to the cloud (BYOL): 3 message packs,Each message pack includes 20,000 messages per hour.
BYOL -> Buy your own license

Data Retension Days -> standared and enterprise -> 32 Days adjust you want
healthcare -> 184 Days

OIC Gen2 -> Integrations 

# integration patterns roles:
1. Trigger => This is an entry point where external systems initiate the integration -> Inbound (external → OIC)
2. invoke => It acts as a client, sending data or requests to another system. -> Outbound (OIC → external)


# Main Features are in OIC Gen3
1. Redwood theme
2. Menu Simplification
3. Cut and Paste Activities
4. expandible and collapseble action
5. Data retension in activation : Audit -> 8 Days, Production-> 32 Days, Debug-> 24 hours
6. Activity stream enhancements
7. Scheduled integration enhancements
8. Mapper function, operator, and XSLT statement embedded help
9. New mapper functions : matches, replace, tokenize
10. Oracle Cloud Infrastructure object storage action enhancements
11. Parallel Processing


===========================================================================================================================================
rest adapter -> 3 MB for XML documents used for schema generation 
			 -> request/response 100 KB JSON sample files used to specify the response payload format
			 -> 100 MB for incoming structured message payloads(Any format)
			 -> Agent 50MB
			 
			 -> records at a time in payload or normal -> 100 to 500 below and file size should be 100KB
			 
			 ==> HTTP methods
			 -> get,put,patch,post,delete
			 -> get -> retrieve records from endpoints. so this is read only. we can't edit the records
			 -> put -> update structure and all columns in existing records
			 -> patch -> Updates specific fields;
			 -> post -> Used to insert new data
			 -> delete -> Deletes rows from the dataset
			 
			 -> Custom Headers:Supported for authentication, content-type, etc.
			 -> Authentication methods
				Trigger -> Basic Auth, OAuth2.0 Basic or OAuth2.0
				invoke -> Basic Auth, OAuth2.0 client creds, OAuth2.0 client jwt client assertion,OAuth Authentication code
						  API key based authentication.
						  
			 -> template parameters/path parameters -> A template parameter is part of the URL path. -> Get a specific item -> it defines curly braces
			 -> query parameters/input/URL -> input parameters/URL parameters -> Get a filtered list of items -> we need setup manully
			 -> header parameter -> http header
			 -> body parameter -> JSON/XML payload

			 -> Content-Type values used in HTTP headers to specify the format of the data being sent or received.
			    like -> application/xml -> json -> text/plain -> html these are all Content-Type
		     -> Caching helps improve performance and reduce server load by storing copies of responses and reusing them for future requests.
			    like -> no-cache,no-store,public,private
			 
			 -> up to 11 resources configured in verbs in rest Trigger
				
==========================================================================================================================================
webservice in oic a rest or soap interface that can be invoked or exposed by an integration to send or receive data b/w systems.

SOAP(simple object access protocol) is a protocol for exchanging Data between systems				
soap adapter -> with schema 100MB(Trigger) -> XML
			 ->	with schema 100MB(Invoke) -> XML
			 -> 50 MB Agent based.
			 
			 -> Trigger => Username password token, basic auth, No security policy
			 -> Invoke => Username password token, OAuth Autherization code, OAuth client creds, Basic Auth
			 
			 -> WSDL -> without WSDL we can't do anything in soap
			 -> WSDL file components -> web services description language
			    -> WSDL tells how to interact with soap service
				
			 =====> WSDL File All components ============
			 -> XSD -> XML schema Defination
			 -> abstract
				-> definations -> root element of a wsdl file. it defines the document structure.
				-> types -> define data types used in the service. request/response data.
				-> messages -> data being exchange between client and service like input and output messages
				-> prototypes -> defines the operations like functions or methods.
				
			 -> concret
				-> binding -> Specifies the protocols like HTTP SOAP and data format used for communications.
				-> service -> specifies the endpoint URL where the service can be accessed.

# Protocols:
  -> HTTP:
  -> HTTPS
  -> FTP
  -> TCP/IP
  -> SMTP
  -> SOAP -> Web Service Protocol
  -> REST -> API communication
  
REST -> Representational  -> Data like Json xml that represents a resource
        State  -> The current condition of the resource like user profile,product info
		Transfer -> Sending the resources representation over a network usually HTTP
Rest is stateless server does't remember the previous state of the client
		
SOAP -> Simple -> it's designed to be easy to understand
        object -> refers to data being sent usually structured as xml
		Access -> Means you are accessing remote services or objects
		protocol -> It's strict set of rules for communication between systems
		
REST Protocols:
1. HTTP -> protocols is set of rules -> methods/verbs -> Get some more
2. HTTPS -> same as HTTP but extra layer is added Security
3. REST -> Architecture style

# Difference between REST and SOAP:
  -> REST supports multiple formats -> JSON,XML,HTTP
  -> SOAP uses xml-based messages over -> HTTP,SMTP
  -> REST used for communication HTTP methods like -> GET,PUT,PATCH,POST,DELETE
  -> SOAP used for communication XML based over the internet -> HTTP,SMTP
  -> REST Supported with SCHEMA and without SCHEMA
  -> SOAP only with SCHEMA is Supported. 
  
===============================================================================================================================		
FTP adapter(External File Transfer) : -> Invoke configuration only 
                                      -> Read file 1GB used without schema -> when used with or without a connectivity agent
			                          -> Download file 1GB 
			                          -> Write file there is no limit
			                          -> What are the key operations supported by the FTP Adapter?
                  							Read File -> input direc-tory,file name pattern
                  							Write File -> output directory, filename pattern
                  							List Files -> input directory, file name pattern
                  							Delete File -> 
                  							Download File -> input,filename,download dir
           									Move File
											
# Difference between FTP and File server											
-> File server is local like internal SFTP server hosted by oracle OIC
-> FTP server is remote like external FTP/SFTP server that oic connects to


==============================================================================================================================
				  
ATP adapter : Operations -> invoke a stored procedure
                            run a sql statement
							perform on operation on a table -> insert,update, insert or update (merge)
							select AI for sql
						 -> Polling Operations -> system check requraly every 10 minutes like automation It looks for new records, 
						                          updated data, or specific changes. if it finds well send to another system.
												  
												  agent based (50MB),Private endpoints(100MB)
												  
						 -> All 100 MB data -> select SQL query is 10 MB -> Agent mode is 50MB
						 
     # Steps to Set Up Private Endpoints for ATP
     Create a VCN (Virtual Cloud Network)
       You can do this manually or use the "VCN with Internet Connectivity" quickstart wizard in Oracle Cloud.
       The VCN includes subnets, route tables, and security lists.
     Create Private Subnets
        These are subnets without internet access.
        Your ATP instance will use one of these subnets for its private endpoint.
     Create the ATP Instance
        During creation, in the "Network Access" section: -> This is not avalible in free tier section
        Choose "Private Endpoint".
        Select the VCN and private subnet you created.
     Check Security Rules
        If you're having trouble accessing the ATP instance:
        Make sure Security Lists or Network Security Groups (NSGs) allow traffic from your client (e.g., your laptop or app server).
        Check DNS resolution if you're using a custom DNS setup


# What is difference between ATP and Normal Database?
-> ATP is the fully automated like self managing, self-patching, self-tuning
-> Normal DB is requires manual DBA management ->  oracle Base Database like VM,BM
-> ATP is Auto pathed without downtime
-> Normal DB is DBA must patch Manually

# ATP work loads:
1. Data warehouse
2. transaction Processing
3. JSON
4. APEX

# Connection details
-> wallet details, service_name: oicatp_high

# ADW and ATP
-> ADW is like a smart analyst good at reading large volumes of data and generating reports
-> ATP is like a fast cashier great at quickly processing thousands of small transactions

# Private endpoints and agent
-> private endpoints in oic gen3 inside a vcn used to talk to other oci services or private IP-based services within oci.
-> Agents for on-premises or external systems where you install an agent to let oic securely connect without VPN.
 
# On-premises and Cloud
-> On-premises you manage everything hardware to apps
-> Cloud(iaas,paas,saas) shared responsibility some by cloud provider, some of like me.

============================================================================================================================

# DBAAS -> Database as a service
-> Dbaas in oic pre built connector that allows to oic to securily connect any oracle Database
   whether it's on-premises, cloud-based, or autonomous - so that can run sql queries, call plsql procedures,
   and perform sql opeations like insert,update,delete,select.
-> Oracle Base Database (VM,BM)
-> Mandotory VCN for Oracle Base Database (VM,BM)

# Extra Information collect
-> 

=============================================================================================================================	
					
# Agent Limits && all limits?
-> service instances -> 200 service instances per region
-> Conenctivity Agent timeout outbound adapter invocation timeout -> 4 minutes -> 240 seconds
-> outbound adapter timeout -> Read timeout -> 5 minutes -> Connection timeout -> 5 minutess
-> Active integrations -> 800 integrations

-> trigger concurrent requests -> 100 concurrent requests per message pack, up to a maximum of 600 
							   -> 50 requests per message pack, up to a maximum of 300

-> integration flow duration -> Synchronous: 5 minutes
							 -> Asynchronous: 6 hours
							 -> Scheduled: 6 hours
							 
-> Notification size limits -> 500 KB maximum email body size (cannot be exceeded) -> 2 MB File Size, -> Javascript 15 seconds

-> scheduled way and ad-hoc way to run scheduled integration.

-> Outbound emails (sent from Oracle Integration in a rolling 24-hour window) -> Default method: 10,000 emails

-> Project limits (per project):
                     Integrations: 100
                     Connections: 50
                     Lookups: 50
                     JavaScript libraries: 20
                     Deployments: 50

-> XSLT execution duration -> 120 seconds

-> instance re submit -> 10 times

============================================================================================================================	
		
✅ Integration Overview
=> Requirement:
   We needed to send daily email notifications when a project releases a particular employee. 
   The email should be sent to the employee, their project leads, and their supervisor.

=> Solution:
   We built a scheduled integration using VBCS BO (Business Object) endpoints. Here's how it works:

=> First Step Retrieve Roll-Off Data:
   We used the RollOff BO endpoint with a REST GET method to retrieve data here we filter employees that is activeFlag='Y' this show active employees.
   This gives us a list of employees who are being rolled off from projects.

=> Filter Employees:
   We used a for-each loop to filter through the list of employees from the RollOff BO.
   For each employee, we made another REST call to the Employee BO endpoint to get detailed information.

=> Get Project Allocation:
   We used the EmployeeProjectAllocation BO endpoint to find out which project the employee is tagged to.
   We set a limit of 1.0 and ordered the results in descending order.
   This data is mapped to the Employee BO using the employee ID.

=> Get Project Details:
   We used the Project BO endpoint to get project-specific information.
   This is mapped using the EmployeeProjectAllocation BO ID.

=> Additional BO Calls:
   We made two more REST calls to Employee BO and Capability BO to fetch additional required fields.
   We applied filters like ID, limit, and order by.

=> Assign Variables:
   We initialized a variable Project_Email is store email addresses.

=> Error Handling:
   We used a Scope component for error handling.
   Inside the scope, we called the Project BO endpoint and assigned variables for manager email addresses.
   If any required data (like email or ID) is missing, we throw a custom error without stopping the email process.

=> Global Fault Handler:
  We used a Global Fault Handler to catch APIInvocationError.
  In case of an error, we reset the Project_Email variable to an empty string.

=> then final Prepare Email Notification:
   We assigned variables for all required recipients: project managers, high authorities, and DLs.
   We used the Notification component to send the email.
   In the Recipients field, we concatenated all the email addresses.
   The email body includes all the necessary project and employee information
   
===============================================================================================================================

10. ✅ Steps to Configure OAuth 2.0 in OCI Console?
   => Navigate to Identity & Security in OCI console
      Go to: Identity & Security → Compartment (e.g., Name: default) → Integrated Applications
   => Add a New Application
      Click Add Application
      Choose Confidential Application
   => Launch Workflow
      Proceed with the Launch Workflow

   => Configure Client Information =====> same delegate control also authentication code, refresh token, client credentials, resource owner password.
      Add the required grant types:
      Resource Owner Password Credentials
      Client Credentials
      Refresh Token
      Authorization Code
      SAML (if applicable)

  => Define Scope and Environment
     Add Scope Application and Environment
     This defines what the consumer can access at different scope levels

  => Proceed Through Setup
     Click Next
     You can Skip for Later if needed

  => Finish Setup
     Click Finish
     Note: The application will be inactive by default
  => Activate the Application
     Manually activate the application

  => Retrieve Credentials
     After activation, you will receive:
     Client ID
     Client Secret
	 
============================================================================================================================

# what are the roles in oic:
    ServiceAdministrator
    ServiceMonitor	
	ServiceDeployer	
	ServiceDeveloper	
	ServiceUser	
	ServiceViewer	
	ServiceInvoker	
	ServiceEndUser	
	
============================================================================================================================

# Policies in oci cloud:
->Allow group [group_name] to [verb] [resource-type] in compartment [compartment_name] where [condition]
=> Groups => Human users -> tenacy and compartments level => Grant users access to manage or use OCI resources
=> Dynamic groups => compute instances/resources => Allow instances or resources to interact with OCI service
Example: Allow group Admins to manage all-resources in tenancy

===========================================================================================================================

#####SQL###:
-> where -> Rows (before grouping) -> No (e.g., SUM(), COUNT() not allowed) -> WHERE filters rows
-> having -> Groups (after GROUP BY) -> After data is grouped -> we can use aggregate functions -> HAVING filters groups

======> Main Reason
-> group by is used to group rows based on column values 
   -> usually to apply aggreate functions like sum count etc.
-> where is used to filter individual rows before grouping
-> having is used to filter grouped results after aggregation
-> order by is sorting the Data asc or desc

Table → [WHERE filters rows] → [GROUP BY forms groups] → [Aggregate functions] → [HAVING filters groups]
SELECT Region, SUM(Amount) AS TotalSales
FROM Sales
WHERE Product = 'A'              -- Step 1: Filter rows before grouping
GROUP BY Region                  -- Step 2: Group the filtered rows
HAVING SUM(Amount) > 100;        -- Step 3: Filter groups based on aggregate

-> Delete -> delete the specific rows -> we can rollback
-> truncate -> Removes all rows from a table -> undo option is not avalible
-> drop -> Deletes the entire table (structure + data) -> undo option is not avalible

-> inner join -> Returns only matching rows from both tables -> Null values are not return
-> left join -> Returns all rows from the left table, and matching rows from the right -> Null values return
-> RIGHT JOIN -> Returns all rows from the right table, and matching rows from the left -> Null values return
-> FULL OUTER JOIN -> Returns all rows from both tables, with NULLs where there is no match -> Null values return
-> CROSS JOIN -> Returns the Cartesian product (every row of A with every row of B) -> Not return null values
-> SELF JOIN -> A table joined with itself -> Depends

-> Union and union all
   UNION: Combines the results of two queries and removes duplicate rows.
   UNION ALL: Combines the results of two queries but includes duplicate rows.

-> DDL -> Create, alter, drop
-> DML -> Select,insert,update,delete
-> DCL -> grant, invoke
-> tcl -> commit, rollback, savepoint

-> View -> A view is a virtual table based on the result of a query.
-> NVL -> NVL is a function in Oracle SQL that replaces NULL values with a specified default value

-> index -> An index is a database object that improves the speed of data retrieval operations on a table

#### PLSQL ##########
# Procedure : is a named block of plsql code that performs a specific task. 
              it does not return value but is accepts input and output parameters
# Functions : is a similar to procedure but it must return value.
# packages: is collection of procedures and functions and variables and cursors grouped together. it has two parts specification, body
# trigger: is block code it automatically runs when a specific action is perform like insert or update
# cursors:  it is used to when you need to handle multiple rows returned by a sql query especially inside loops.
           implicit cursor: automatically created by PLSQL for single row queries like insert,update for select into
		   explicit cursor: manually declared to handle multi-row query results.
		   

----> FOUND and NOT FOUND : to control loop exit -> it's like true or false
----> ROWCOUNT -> track how many rows were processed
----> OPEN -> to check if a cursor is open before fetching or closing
----> TYPE -> is used when you want a plsql variable to have same data type as a column in Table

-> Rank() -> same as row_number but gives same rank for ties
-> Rownumber() -> adds the number to each row with ordering
-> dense_rank() -> like rank() but no gaps in ranking
-> rownum -> adds rownumber no order control

============================================================================================================================

# Error codes in oic:
400 -> Bad request -> syntax or validation errors
401 -> Not Authorized -> missing authentication token 
403 -> Forbidden -> not autherized ti access the resource
404 -> Not Found -> endpoint does not exist
405 -> Method Not Allowed -> not supported method
429 -> Too Many Requests -> too many requests in given amount of time.


500 -> internal server error -> usually indicates a bug or misconfiguration
502 -> Bad gateway -> invalid response from the upstream or service
503 -> service unavalible -> temporily unavalible
504 -> gateway timeout -> timeout while waiting for a response from an external system



# Versioning in oic gen3:
-> major and minor Versioning
   1.0.0 -> initial Version
   1.1.0 -> minor changes
   2.0.0 -> major change

# Current version:
-> 24.04.1

=======================================================================================================================================

# XSLT Functions in OIC Gen3
-> XML (Extensible Markup Language)
-> XSLT -> XML stylesheet langauge transformation
-> XSL -> Extensible Stylesheet Language
-> XPath -> XML Path Language

XML is the base.
XSLT and XSL work with XML for transformation and styling.
XPath is used to query and navigate XML data, often as part of XSLT.

# components
-> Flow -> XML is top level langauge -> inside XSL includes XSLT,XSL- Formating Objects -> XPath (XML Path Language)
1. functions
  -> Advanced
     -> current-group
	 -> decodebase64
	 -> decodebase64ToReference
	 -> encodebase64
	 -> encodeReferenceToBase64
  -> Boolean
     -> true
	 -> false
	 -> lang
  -> conversion
     -> datetime
	 -> Date
	 -> Boolean
	 -> string
	 -> number
  -> Date
     -> current-Date
	 -> current-datetime
	 -> current-time
  -> integration Cloud
     -> getflowid
	 -> lookupvalue
  -> mathematical
     -> floor,round,SUM
  -> node-set
     -> exits,position
  -> string
     -> compare,contains, concat, format-string,lowercase,left-trim, replace,uppercase
	 ->  substring -> The substring() function allows you to 
	                  extract a portion of a string by specifying the starting position and optionally the length of the substring.
2. Operators
3. XSL Constructors :
  -> Flow level
    -> Choose
	-> for-each
	-> for-each-group
	-> If
	-> otherwise
	-> when
  -> Output:
    -> attribute
	-> copy-of
	-> literals
	-> text
	-> value-of
=======================================================================================================================================

-> Data stinch
1. Switch -> if 
2. 

=======================================================================================================================================

-> Business events in Fusion-based SAAS with OIC:
-> URL -> https://eqjz.ds-fa.oraclepdemos.com/
-> PO Order Number: US165202

=======================================================================================================================================

-> FBDI Process for OIC
1. in oracle cloud file-based data import is a method for importing large volumes of data into oracle fusion cloud Applications

-> Steps for FBDI process in OIC
   1. Download xlsm template in  oracle 
   2. Generate CSV file with or without Data
   3. create properties file
   4. Create ZIP file
   5. upload the file into oracle Cloud   
   
   
   
   
======================================================================================================================================

-> Query, Create, Update, or Delete Information -> Provides the standard configuration path for selecting a business object or service. 
												   This option displays the standard Operations and Response pages. This is the default selection.
-> Import Bulk Data into Oracle ERP Cloud -> Provides a scenario for loading and orchestrating data from a secure FTP location to Oracle ERP Cloud.
-> Send Files to ERP Cloud -> Select to upload files to Oracle WebCenter Content (Universal Content Manager) in encrypted or unencrypted format.

