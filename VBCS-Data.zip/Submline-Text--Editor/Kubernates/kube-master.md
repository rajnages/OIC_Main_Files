What is kubernates
Kubernetes (K8s) is an open-source platform that automates the deployment, scaling, and management of containerized applications. It ensures applications run efficiently and reliably across clusters of physical or virtual machines.

Why Do We Use Kubernetes?
 
 Container Management: Handles the lifecycle of containers, ensuring they are deployed, scaled, and updated needed.
 High Availability: Keeps applications running even if some containers or nodes fail.
 Scalability: Automatically scales applications up or down based on demand.
 Portability: Works across multiple environments, such as on-premise, cloud, or hybrid setups.
 Efficiency: Optimizes resource utilization across the infrastructure.

Problems Solved by Kubernetes

    Manual Container Management: Automates the process of deploying, starting, and stopping containers, eliminating manual efforts.
    Scaling Applications: Dynamically scales the number of containers up or down based on traffic or resource usage.
    Service Discovery and Load Balancing: Automatically distributes network traffic to the appropriate containers.
    Resource Optimization: Efficiently schedules workloads to optimize the use of available infrastructure.
    Self-Healing: Restarts failed containers, replaces dead nodes, and ensures the desired application state.
    Complex Deployment Management: Manages rolling updates, rollbacks, and blue-green deployments without downtime.
    Multi-Environment Support: Standardizes application deployment across development, testing, and production environments.

Key Features of Kubernetes

    Pods: The smallest unit of deployment, often running one or more containers.
    Nodes: Machines (physical or virtual) that run containers.
    Cluster: A group of nodes managed by Kubernetes.
    Controller: Automates desired states like deployment, scaling, and updates.
    Service: Exposes your application to the network.


 Challenges Kubernetes Solves in Real-Time Scenarios

    Scaling issues: Auto-scaling ensures optimal performance during traffic spikes.
    Downtime: Self-healing minimizes downtime by managing failed containers.
    Cloud and On-Premise Consistency: Makes migration and hybrid setups easier.
    Team Collaboration: Standardizes deployments, improving developer and operations team collaboration.


Why is Kubernetes Popular?

    Open-source and community-driven.
    Backed by major cloud providers like AWS, Azure, and Google Cloud.
    Extensible with a rich ecosystem of tools (e.g., Helm, Istio).
    Supports complex workloads like microservices and machine learning models.


=====================================================================================================================


Cluster Architecture:

A Kubernetes cluster consists of a control plane plus a set of worker machines, called nodes, that run containerized applications. Every cluster needs at least one worker node in order to run Pods.

The worker node(s) host the Pods that are the components of the application workload. The control plane manages the worker nodes and the Pods in the cluster. In production environments, the control plane usually runs across multiple computers and a cluster usually runs multiple nodes, providing fault-tolerance and high availability.

Control Plane Components
1. API Server

    What Happens:
        The API Server starts and becomes the central hub for all cluster communication.
        It listens for commands (kubectl or other tools) and interacts with other components like Scheduler, Controller Manager, and Etcd.

    Example: When you run kubectl create pod, the API Server processes the request and updates the desired state in Etcd.

2. Etcd

    What Happens:
        Etcd initializes and stores the entire state of the cluster, such as the pods, services, and configurations.
        Any changes in the cluster are recorded here for persistence.

    Example: When the desired state is "3 replicas of a pod," Etcd saves this information, ensuring it remains even after a crash.

3. Scheduler

    What Happens:
        The Scheduler looks for unscheduled pods in the cluster and assigns them to a suitable node based on resource availability (CPU, memory).
        It considers node conditions, taints, tolerations, and affinity rules.

    Example: If you create a deployment with 3 replicas, the Scheduler assigns these pods to nodes with enough resources.

4. Controller Manager

    What Happens:
        It watches for changes in the cluster (via API Server) and ensures the desired state is met by creating or updating resources.
        For example, it creates pods if a replica set is missing instances.

    Example: If a pod crashes, the Controller Manager automatically triggers a replacement pod.

Worker Node Components
1. Kubelet

    What Happens:
        Kubelet starts on each worker node and ensures the containers specified in the pod manifest are running correctly.
        It communicates with the API Server for updates and reports the node’s status.

    Example: Kubelet downloads the required container image (e.g., Nginx) and starts the container on the worker node.

2. Kube Proxy

    What Happens:
        Kube Proxy starts managing network rules for pods and services, ensuring communication between them.
        It sets up IP tables for traffic routing within the cluster and external access.

    Example: If you expose a service (e.g., a web app), Kube Proxy ensures requests are routed to the correct pod.

3. Container Runtime

    What Happens:
        The container runtime (e.g., Docker or containerd) pulls the container images from the registry (e.g., Docker Hub) and starts the containers.
        It manages running containers on the node.

    Example: When a pod definition specifies an image, the runtime downloads it and runs the container.