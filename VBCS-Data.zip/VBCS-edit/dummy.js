PageModule.prototype.updateAllocBatchOperation = function (allocDataArray, operation, BOName, batchSize, empBO, capabilityBO, skillGroupBO) {
    let batchProcessingVariableArray = [];

    for (let batchStart = 0; batchStart < allocDataArray.length; batchStart += batchSize) {
      let batchEnd = Math.min(batchStart + batchSize, allocDataArray.length);
      let batchData = allocDataArray.slice(batchStart, batchEnd);

      for (let index = 0; index < batchData.length; index++) {
        var data = {
            id: "part" + index,
            path: "/" + BOName + "/",
            operation: operation,
            payload: {
              format: dataBO[index].format,
              teamRequestNumber: dataBO[index].teamRequestNumber,
              positionId: dataBO[index].positionId,
              demandStatus: dataBO[index].demandStatus,
              teamRequestName: dataBO[index].teamRequestName,
              client: clientid,
              demandType: dataBO[index].demandType,
              projectCode: dataBO[index].projectCode,
              location: dataBO[index].location,
              localGrade: dataBO[index].localGrade,
              roleNotes: dataBO[index].roleNotes,
              roleStartDate: dataBO[index].roleStartDate,
              roleEndDate: dataBO[index].roleEndDate,
              demandCreationDate: dataBO[index].demandCreationDate,
              ageing: dataBO[index].ageing,
              requestedBy: dataBO[index].requestedBy,
              region: dataBO[index].region,
              subSector: dataBO[index].subSector
            }
          };

        batchProcessingVariableArray.push(data);
      }
    }

    return { parts: batchProcessingVariableArray };
  };