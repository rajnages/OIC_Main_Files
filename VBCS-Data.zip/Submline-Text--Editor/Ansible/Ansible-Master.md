# Day-01:
1.What is Ansible
What is Ansible?
Ansible is an open-source IT automation tool used to automate tasks such as configuration management, application deployment, orchestration, and provisioning. It simplifies complex manual tasks by describing them in a human-readable YAML language.

Agentless: No agents are required on managed nodes.
Idempotent: Ensures tasks produce consistent results even after multiple executions.
Easy-to-Learn: Uses YAML syntax, which is intuitive and human-readable.

=========================================================================================================

# Why we used Ansible:
=>Automation (Save Time & Reduce Errors):
Scenario: Imagine you're managing a fleet of web servers. Every time there's a security update, you manually log into each server, apply patches, and restart services. This is time-consuming and prone to human error.
With Ansible: You can automate this task. Write a simple playbook, and Ansible will apply the updates and restart services on all servers in one go, saving time and ensuring no mistakes.

=>Consistency (Uniform Configuration):
Scenario: You have different environments (e.g., production, staging) where you need the same application and server configuration. Manually ensuring they match can lead to errors.
With Ansible: You can define the exact configuration in a playbook, and Ansible will apply it consistently to all servers, making sure everything is the same across environments.

=>Scalability (Handle Many Servers):
Scenario: You have a small number of servers at first, but as your business grows, you need to manage hundreds or thousands of servers. Managing them manually would be nearly impossible.
With Ansible: You can scale your automation easily. Ansible can handle a small number of servers or scale up to thousands, all with the same playbook.

=>No Agent Installation (Less Overhead):
Scenario: Some automation tools require installing agents on each server. This can be complex to manage and sometimes adds overhead.
With Ansible: There's no need for agent installation. Ansible simply uses SSH to connect to your servers, making it easy to manage remote systems without extra software.

=>Declarative Language (Easy to Understand):
Scenario: You need to specify the exact configuration for a server. Instead of writing complex scripts or commands, you want something easy to read and understand.
With Ansible: You use YAML (a simple text format) to write your configuration, making it easy for anyone (even non-programmers) to read and understand the tasks that Ansible will execute.

=>Extensible (Custom Modules):
Scenario: Your company needs to manage cloud resources (e.g., AWS EC2 instances) in addition to servers. Creating custom scripts to handle this can be time-consuming.
With Ansible: You can use pre-built community modules or create your own to extend Ansible’s capabilities. For example, you can automate the provisioning of cloud infrastructure along with server configuration, all within a single playbook.

===========================================================================================================

# Advantages:
No Need for Agents:
Unlike other tools, Ansible doesn’t require agents on the target machines, as it uses SSH for communication.

Multi-Cloud and Hybrid Cloud Support:
Ansible can manage multiple cloud environments and hybrid infrastructures, making it a powerful tool for DevOps automation.

==========================================================================================================

# Main components of Ansible:

1.Controllers
2.Clients
3.INV File

=========================================================================================================

# Setup Ansible Controller
# Install Ansible in Controller Instance:
  sudo apt-add-repository ppa:ansible/ansible
  sudo apt update && sudo apt install ansible -y

# aws installation
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install

# terraform installtion
wget -O- https://apt.releases.hashicorp.com/gpg | sudo gpg --dearmor -o /usr/share/keyrings/hashicorp-archive-keyring.gpg
echo "deb [signed-by=/usr/share/keyrings/hashicorp-archive-keyring.gpg] https://apt.releases.hashicorp.com $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/hashicorp.list
sudo apt update
sudo apt install terraform -y

# Custom file generation
1.cd /etc/ansible && rm -rf ansible.cfg
2.sudo ansible-config init --disabled > ansible.cfg
3.vi ansible.cfg
  host_key_checking=False
  remote_user=ansibleadmin
  privaye_key_file=/home/ansibleadmin/key.pem

# aws keys export
export AWS_ACCESS_KEY_ID=AKIA6ODU4UQE7N3FI567
export AWS_SECRET_ACCESS_KEY=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
export AWS_DEFAULT_REGION=us-east-1

# Packer commands
packer validate --var-file vars.json packer.json 
packer inspect --var-file vars.json packer.json 
packer build --var-file vars.json packer.json


# Version checking in ubuntu
lsb_release -a
cat /etc/os-release

=============================================================================================================

# Ansible commands:
1.ansible -i invfile -m ping
2.ansible -i invfile -m shell -a "df -h | grep -i /dev/root" -vvv
3. ansible -i invfile server01 -m setup => all clients information
4.ansible-playbook -i invfile playbooks/sample.yaml --syntax-check => syntax check in playbook
5.ansible-playbook -i invfile playbooks/sample.yaml --check => dry run playbook
6.ansible-playbook -i invfile playbooks/sample.yaml -v => verbose mode running playbook
7.ansible-playbook -i invfile -m shell -a "ifconfig" => checking smoke test tools install or not

=============================================================================================================

# Redis in Ansible
# What is Redis
Redis is an in-memory, key-value data store used for caching, real-time data processing, and fast data retrieval.

# why we used.
Redis is used in Ansible as a caching mechanism to improve performance and manage data efficiently during playbook execution.

1.Caching Facts and Results
  Purpose: Ansible gathers facts about target systems (e.g., OS details, IP addresses) before executing tasks. Caching these facts avoids repeatedly collecting them during subsequent runs, improving efficiency

2.Speed and Performance
3.Idempotency and Consistency
4.Distributed Environment
5.Event-driven Automation

==========================================================================================================

# Ansible vault
Ansible Vault is a feature in Ansible used to securely encrypt and manage sensitive data, such as passwords, API keys, and configuration files, within playbooks or inventories. 
It ensures that confidential information is protected and can be safely shared within teams or repositories

# Commands:
ansible-vault create aws_creds
cat aws_creds
ansible-vault decrypt aws_creds
ansible-vault encrypt aws_creds


=========================================================================================================

# Difference between block and resue and always

1.block
Purpose: Groups tasks together to handle them as a single logical unit.
Behavior: Executes the tasks sequentially. If any task fails, it triggers the associated rescue block (if defined).
Usage: Used for grouping and structuring related tasks.

2.rescue
Purpose: Executes tasks when a failure occurs in the block.
Behavior: Only runs if a task in the associated block fails.
Usage: Used to define recovery or fallback actions for failures.

3.always
Purpose: Executes tasks regardless of whether the block or rescue tasks succeed or fail.
Behavior: Always runs after the block and rescue tasks.
Usage: Typically used for cleanup operations or logging.

