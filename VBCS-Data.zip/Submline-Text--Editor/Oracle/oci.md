# Oracle - 3 Major Types
1. Oracle Cloud Infrastructure (OCI)
* Compute: Virtual Machines (VMs), Bare Metal, Containers, Kubernetes
* Storage: Object Storage, Block Storage, File Storage
* Networking: VCN, Load Balancers, VPN, FastConnect
* Database Services: Autonomous DB, Oracle Exadata, MySQL HeatWave
* Security & Identity: IAM, WAF, Security Zones, Data Safe
* Observability & Management: Logging, Monitoring, Ressource Manager
* AI & Machine Learning: AI Services, Data Science, Language/ Vision AI
* DevOps & Developer Services: Terraform, Ansible, Resource Manager, API Gateway

2. Oracle Cloud Applications (Business Applications divided into)
a. Enterprise Resource Planning (ERP)
Financials: General Ledger, Accounts Payable/Receivable, Fixed Assets
Procurement: Supplier Management, Sourcing, Purchasing
Project Management: Project Costing, Billing, Grants
Risk Management: Financial Compliance, Security
Enterprise Performance Management (EPM): Planning, Budgeting, Financial Consolidation

b. Supply Chain Management (SCM)
Supply Chain Planning: Demand Planning, Sales & Operations Planning
Inventory Management: Warehouse Management, Order Management
Logistics: Transportation, Global Trade Management
Manufacturing: Discrete & Process Manufacturing, Maintenance
Product Lifecycle Management (PLM): Innovation Management, Product Data Hub

c. Customer Experience (CX)
Sales: Customer Data Management, Incentive Compensation
Marketing: Campaign Management, Lead Generation
Service: Field Service, Digital Customer Service
Commerce: B2B and B2C Commerce

d. Human Capital Management (HCM)
Core HR: Workforce Directory, Benefits, Payroll
Talent Management: Recruiting, Performance, Learning
Workforce Management: Time & Labor, Absence Management
Payroll: Global Payroll, Tax Reporting

3. Hardware & Software
* Oracle Database: Oracle DB, Oracle Exadata, Oracle Autonomous Database
* Java: Oracle JDK, OpenJDK, GraalVM
* MySQL: MySQL Enterprise Edition, MySQL HeatWave
* Linux: Oracle Linux, Virtualization, Cloud-Native Applications
* On-Premises Applications: Oracle E-Business Suite, PeopleSoft, JD Edwards, Siebel CRM

####################################################################################################################

OCI:
1. Tenacy -> Oracle Account(AWS Account)
2. Region -> oracle region (aws region)
3. Compartments -> oracle Compartments (aws organizational units/resource groups)
4. az -> oracle Availability Domains(aws az zones)

# policies in oci
-> Allow <who> to <what actions> in <which resources>
Who?	The user group or identity receiving the permissions	group Admins, group Developers
What?	The actions they are allowed to perform					manage, read, use
Where?	The scope (tenancy, compartment, resource type)			in compartment Development

✅ Tenancy Level – Policies apply to the entire OCI account.
✅ Compartment Level – Policies apply only to a specific compartment.
✅ Resource Level – Policies control specific services (e.g., Compute, Storage).


https://capnaoicprd-capnaop2-ia.integration.ocp.oraclecloud.com/ic/home/

https://capnaicsic-capnaop2.integration.ocp.oraclecloud.com/ic/home/

Usernames/password
oic.user
Oracle@Jun22
SC_OICUSR
Scoicprod@Jan23

46294610
Tbhk@3132


q7esj2qovu1goj8_high

https://capnaicsic-capnaop2.integration.ocp.oraclecloud.com:443/ic/builder/design/My_View_Dev_1_1_379/1.0/resources/data/EmployeeBO


1.0.12
7569235694@Nages

129.148.170.63

C:\db-sample-schemas\human_resources

@C:\db-sample-schemas\human_resources\hr_main.sql


# Pagination


$current.row => All rows stored after that mapping to variables



https://development-testing-ax2nt90xezad-hy.integration.ap-hyderabad-1.ocp.oraclecloud.com/ic/api/integration/v1/flows/rest/VBCS_PROJECT_INTEGRATIO/1.0/insert

{{$event.detail.cancelEdit}}

{{$event.detail.rowContext.componentElement.getDataForVisibleRow($event.detail.rowContext.status.rowIndex).data}}

{{$event.detail.rowContext.status.rowIndex}}

{{$event.detail.rowContext.status.rowKey}}

N_My_SandBox_Environment


username : hcm_impl
username: scm_impl
username: fin_impl


// Create and serve an Oracle JET 15.0.0 app
$ npx @oracle/ojet-cli@15.0.0 create myJET15app --template=navdrawer
$ cd myJET15app
$ npx @oracle/ojet-cli@15.0.0 serve

// Create and serve an Oracle JET 18.1.0 app
$ npx @oracle/ojet-cli@18.1.0 create myJETapp --template=navdrawer
$ cd myJETapp
$ npx @oracle/ojet-cli@18.1.0 serve



{
	"eventTitle":item.eventTitle,
	"id":item.id,
	"start":item.start1,
	"end":item.end1,
	"allDay":item.allDay,
	"calenderProvider":item.calenderProvider

};


I have completed all the required trainings and shared the requested details. Please let me know if anything else is needed to proceed with the onboarding


I am On leave 6th & 9th June 2025. Back on 10th June. Please expect delayed responses.