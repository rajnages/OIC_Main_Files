# Purpose of backup and cloning activity:
1. In oracle fusion applications, cloning means making an exact copy of an existing environment - incluing application setup, configuration, and data - into another environment
2. example two instances (Prod to test environments):
 -> PROD
    # This is the live system your compant user daily.
	#  all real users, roles, and data are here.
 -> Test
    # This is lower env for testing.
	# usually has old data and may not match production.
 -> All configurations, data and user roles from prod are copied to test
 -> Test now looks and feels exactly like Prod
3. Here in concorde what will happen like when cloning happens like Prod to Dev2 or different environment
  -> first and most users will lost there access.
  -> roles mismatch, they can't login
4. oracle coming this feature called backup and restore activity
  -> Two types
     1. pre clone
	 2. post clone

1. What are the instances we are doing backup cloning -> Depends client requirement they will decide.
2. why we are doing backup Cloning -> After cloning user lost there access in lower environments.
3. What are the access required --> Basic access is enough
4. after and before Emails to send anyone,or any group chat --> tomorrow we have cloning activity today we can take pre clone report user list report,
															 once that is completed. they will send the mail cloning is completed --> this mail loop shabharish mail loop he is informed
															 then we can start post cloning activity.
5. at what Time backup -> they will decide time intervals.


-------------------------------------------------------------------------------------------------------------------------------------------------------------------
-> before clone
1. download this report -> GEA_User_Role_Details_Report source and target and validate
2. prepare data file.
-> after clone
1. 




CreateException:Data Model definition not found:/Custom/Development/Shweta/Role_details.xdm

GEINC17681419 -> Suneetha
GEINC17690355 
GEINC17690286
GEINC17685721 -> empty


GESCTASK9070638 : Venkatesh


Jeddy


1. how you know what are instances --> this is decide leema and kalpa
2. 



what is used pre clone activity --> user list -> GEA 
post clone activitty -> 
 
 
Rally, SR, cloning actvities , 
Point of contact --> completed
Support central worflow, integration testing in Dev 2(SSS, bridger, IDM--ect)-- Technical team

Service now training
Timezone --> America/new york
Incident Level --> By Default -> Inprogress
Ctask Level --> Open --> work Inprogress
If CTASK Level in Pending state --> SLA will Pause
but in INC level That is On hold --> This will pause SLA --> But we don't have seperate INC level SLA
