# docker info => all information of docker
# docker container run -p 8080:80 nginx
1. Downlaoded image nginx from docker hub
2. started a new container from that image
3. Opened port 80 on the host ip
4. Routes that traffic to the container ip port 80

# docker container run -d -p 8080:80 nginx
1. this will run background

# docker container ls -a
1. list running and stop the continers

# docker container run always starts a new container && use docker container start to start an existing stopped one.

# docker container run -d -p 8080:80 --name detach nginx

# docker container logs 
1. Showing the logs of container

# docker container top contaienr_name
1. showing cpu and all of the container

# docker container rm -f id's
1. remove the containers

# docker container inspect container_name
1. all metadata for container

# docker container stats
1. streamining view of all containers

# docker exec -it container_name bash
1. inside container

# docker container port nginx
1. Showing The ports of particular containers

# docker container inspect --format '{{ .NetworkSettings.IPAddress }}' nginx
  docker container inspect --format '{{ .NetworkSettings.IPAddress }}' $(docker ps -q | head -n 3)
1. Specific format we want use --format

# docker network ls
1. List all networks

# docker network inspect <network_name>
1. Showing all details of network

# docker network create --driver bridge my_custom_network
1. Create custom network

# docker network connect <network_name> <container_name>
1. connect container to a network

# docker network disconnect <network_name> <container_name>
1. This is the disconnect network

# docker run --network <network_name> --name my_app_container nginx
1. run a conatienr specific netwrok

# docker network rm <network_name>
1. remove the host

# docker run --network host nginx
1. use host network

# docker exec -it <container_name> ping <another_container>
1. Debugging and Troubleshooting

# docker network prune
1. cleanup all unused networks

# Commands in Volumes
1. docker info | grep -i root  ==> This will show docker directory
2. docker volume rm $(docker volume ls -f=dangling=true -q)
3. sudo !! => re-run the last executed command with superuser privileges.
4. docker info | grep -i root
5. default docker directoy in ubuntu : /var/lib/docker/ and centos is /mnt/docker
6. default nginx inside container path nginx : /usr/share/nginx/html

# instead of stoping container use this rm and stop containers
1. docker rm -fv container_id

# If not installed tools you can use this
1. docker exec -it nginx1 sh -c "apt-get update && apt-get install iputils-ping -y"
2. docker exec -it nginx1 sh -c "ping nginx2"
3. docker ps --no-trunc

# docker build --build-arg APP_VERSION=1.0 -t myapp .
1. Build time arguments using ARG component

# docker build --progress=plain --build-arg APP_VERSION=1.0 -t app:v1 -f Dokcerfile1 .
1. The --progress flag has several options:
- --progress=auto (default): Shows dynamic progress with layer details
- --progress=plain: Shows all build output in plain text format
- --progress=tty: Similar to auto but optimized for terminal output
- --progress=quiet: Shows minimal output

=============================================================================================================

# Docker compose commands and Installation:
1. sudo curl -L "https://github.com/docker/compose/releases/download/1.29.2/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose

2. sudo chmod +x /usr/local/bin/docker-compose
3. docker-compose --version

# Docker compose components:
# Component Purpose
- version - Specifies Compose file version.
- services -  Defines the application’s containers.
- networks - Creates custom networks for communication.
- volumes - Configures persistent storage.
- build - Builds custom images using a Dockerfile.
- ports - Maps host ports to container ports.
- environment - Sets environment variables.
- depends_on - Specifies dependencies between services.
- command - Overrides the default container command.
- restart - Sets the container restart policy.

# Docker compose commands:
# Start services in detached mode
docker compose up -d

# Build and force recreate services
docker compose up --build --force-recreate

# Scale a specific service
docker compose up -d --scale web=3

# Stop and remove all containers, networks, and volumes
docker compose down -v

# View logs of all services
docker compose logs -f

# Execute a command in a running container
docker compose exec web bash

# Run a one-off command
docker compose run --rm web npm test

# docker compose components
1. version
2. services
3. volumes
4. networks
5. secrets

#############################################################################################################

# Docker swarm

1. docker swarm init 
2. docker swarm join --token SWMTKN-1-4tbls6583eb2up50v8sgt4g13lpq3s12ir6hlvlisx6qi7v2s5-690npg8ubtiym9wrmyk1la8k6 172.31.83.64:2377

3. docker run -it -d -p 8080:8080 -v /var/run/docker.sock:/var/run/docker.sock dockersamples/visualizer
4. docker service create app1 --replicas 3 --publish 8000:80 kiran 2361993/rollingupdate:v10

5. docker service create --name main --replicas 3 -p 9000:80 nginx:latest

6. docker service create --constraint node.role=worker --replicas 6 --publish 8000:80 nginx:latest

7. docker service create --name monitor --publish 9100:9100 --mode global prom/node-exporter:latest
   
   - --mode global
     Specifies the global mode for the service.
     A global service runs one instance (replica) of the container on every node in the Swarm cluster.
     This is useful for monitoring tools, as every node will have a Node Exporter instance running.



# docker secrets:

1. vi creds
2. docker secret ls
3. docker secret create aws_creds creds