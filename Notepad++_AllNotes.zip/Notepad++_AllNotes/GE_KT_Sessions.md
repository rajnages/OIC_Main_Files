========================================================================================================================
===========> EM Component process: KT Session : 05-06-2025 Thursday ====================================================
# IR-ISO process
1. IR -> Internal Requisition
2. ISO -> Internal Sales Order

# internal Rquisition Creation Tables:
=> PO_REQUISITION_HEADERS_ALL, PO_REQUISITION_LINES_ALL, PO_REQ_DISTRIBUTIONS_ALL

# Order Import and ISO Creation:
=> Order import table affected -> OE_HEADERS_IFACE_ALL,OE_LINES_IFACE_ALL
=> ISO creation table affected:
   OE_ORDER_HEADERS_ALL-> FLOW_STATUS_CODE is BOOKED
   OE_ORDER_LINES_ALL(FLOW_STATUS_CODE is AWAITING_SHIPPING)
   WSH_DELIVERY_DETAILS -> 
   WSH_DELIVERY_ASSIGNMENTS
   
=> ISO processing
=> Picking Table Affected:
   WSL_NEW_DELIVERIES -:> Yes
   DELIVERY_ID is populated in the table WSH_DELIVERY_ASSIGNMENTS
   RELEASED_STATUS in WSH_DELIVERY_DETAILS 	would be noew set Y -> pick confirmed
   if auto picj confirm is set to yes other wise 
   
=> Receipt at Destination Organization:
 -> TABLES AFFECTED:
    RCV_SHIPMENT_HEADERS
	


==========================================================================================================================

Date : 29 May 2025 ========= Day: ThursDay

# OverView Of Oracle Fusion Cloud Applications:
=> ERP (Enterprise Resource Planning):
   -> Financials
   -> procurement
   -> Project Management
   -> Risk Management and Complience
   -> EPM (Enterprise Performance Management)
   -> ERP Analytics
   
=> HCM (Human Capital Management):
   -> Human Resources
   -> Talenet Management
   -> Workforce Management
   -> Payroll
   -> HCM Analytics

=> SCM (Supply Chain Management):
   -> SCM OverView
   -> Maintenance
   -> Product Lifecycle Management
   -> inventory Management
   -> order Management
   -> procurement
   -> manufacturing
   -> Logistics

=> CX (Customer Experience):
   -> CX OverView
   -> Marketing
   -> Service
   -> Oracle CX Platform
   -> Sales
=============================================================================
=> Procure-to-Pay (P2P)	ERP → SCM (Supply Chain Management) & Financials
=> Supply Chain Management (SCM) -> procurement and inventory (Item Creation)
=> ERP (Financials) -> invoice and payment processing.

=============== Process =====================================================
Step 1: Need identified - The need for a product or service is identified.

Step 2: Requisition management - A formal request is made for the goods or services and approved.

Step 3: Purchase Order issued - Once the purchase requisition has been approved by the relevant management, 
        a purchase order is issued to the supplier.

Step 4: Goods receipt - The supplier delivers the requested goods or services and the relevant goods or services 
        receipt is created.

Step 5: Invoice received - The supplier’s invoice is submitted and entered into the processing system.

Step 6: Invoice processing - The invoice is either matched against the PO and the receiving documents or 
        any exceptions are flagged for investigation. Invoices that do not have an associated PO 
		are routed through workflow for review and approval.

Step 7: Accounts Payable - Approved invoices are passed to accounts payable who make the payment and update the system.


==============================================================================================================

=> (Request for Quotation and Quotation):
RFQ -> Defination & purpose
    -> Types of RFQ -> Bid(Competitive bidding with sealed quotes.)
	                -> standard(One-time purchase)
					-> catalog(For recurring purchases or catalog items.)
    -> creation of methods 
	                -> Manual -> Created directly by procurement users.
					-> Auto -> Generated from requisitions or sourcing rules.
	-> supplier involvment
	                -> Suppliers receive RFQs via the Supplier Portal.
					-> They submit quotations with pricing, delivery, and terms.
	
=> Purchase order
   -> defination & purpose               -> PO_HEADERS_ALL
   -> Types                              -> PO_LINES_ALL
   -> source document & reference        -> PO_LINE_LOCATIONS_ALL
   -> creation methods                   -> PO_DISTRIBUTIONS_ALL
   -> Approval Process
   
=> GRN (Goods Receipt Note):
   -> Defination & purpose  -> RCV_SHIPMENT_HEADERS 
   -> creation methods      -> RCV_SHIPMENT_LINES
   -> receiving methods     -> RCV_GOODS
   -> matching Types
   -> source document reference
   -> return and correction
   
=> PO invoice & Payments:
   -> Defination & purpose 
   -> invoice Creation
   -> invoice types -> standard, credit, debit and Service
   -> matching options -> 2,3 & 4 way
   -> validation
   -> Approval workflow
   -> payment processing
   -> reconcialtion
   -> accounting entries
   
   =======> Tables:
   -> AP_INVOICE_ALL
   -> 
   
=> General Ledger:
   -> Chart of Accounts (COA)
   -> Ledger - 3C'S
   -> Journal entries
   -> Posting
   
   =======> Tables:
   -> GL_JE_HEADERS
   -> GL_JE_LINES
   -> GL_CODE_COMBINATIONS
   -> GL_LEDGERS
   -> GL_BALANCES
   -> GL_PERIODS
   
   
   
Nag_PO_HEADERS_ALL -> PO_HEADER_ID, BILLTO_BU_ID, SOLDTO_LE_ID, CURRENT_VERSION_ID


===========================================================================================================================

Date: 11 June 2025 Day: Wendsday

