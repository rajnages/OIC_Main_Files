# What is Ansible, and how does it work?

->Ansible is an open-source automation tool that helps in configuration management, application deployment, and task automation. 
->It uses an agentless architecture, meaning no agent is installed on the managed nodes. 
->Ansible communicates via SSH and pushes configurations from the control node to the managed nodes. 
->It works by defining a set of instructions (playbooks) in YAML format and executing them to bring systems to the desired state.

# Can you explain the difference between Ansible and other configuration management tools like Puppet or Chef?

Unlike Puppet and Chef, which use a pull-based model (agents pull configurations), Ansible uses a push-based model, which means the control node pushes the configurations to the managed nodes via SSH. Ansible also uses a simpler, agentless architecture, whereas Puppet and Chef require installing agents on the nodes.

# What are the key components of Ansible architecture?

Control Node: The machine where Ansible is installed. It orchestrates and sends commands to managed nodes.
Managed Nodes: The remote systems (usually servers) that Ansible manages, and where tasks are executed.
Inventory: A list of managed nodes that Ansible communicates with. It can be static (written in a file) or dynamic (generated from cloud providers or other sources).
Modules: Reusable units of code that perform specific tasks (e.g., installing a package, managing services).
Playbooks: YAML files that define the tasks and configurations to be applied to the managed nodes.

# What is the role of an inventory file in Ansible, and what are the differences between static and dynamic inventories?

The inventory file defines the managed nodes and their configurations (e.g., hostnames, IP addresses).
Static Inventory: A simple text file listing IPs or hostnames of nodes.
Dynamic Inventory: Generated dynamically, usually through scripts that query a cloud provider (e.g., AWS, GCP) to gather the nodes in real-time.


# How does Ansible ensure idempotency in tasks?

Ansible tasks are designed to be idempotent, meaning running the same task multiple times won’t change the state if the desired state is already achieved. For example, if a package is already installed, Ansible won’t reinstall it.

# Explain Ansible’s push-based model and how it differs from pull-based systems like Chef and Puppet.

Ansible is push-based, meaning the control node pushes configurations to managed nodes via SSH. In contrast, Chef and Puppet use pull-based models where the nodes pull configurations from a central server.

==============================================================================================================

# What is an Ansible playbook, and how is it structured?

An Ansible playbook is a YAML file that defines a series of plays. A play maps hosts to tasks and applies configurations. A playbook includes:
hosts: Defines which nodes the play applies to.
tasks: A list of actions to be performed.
vars: Optional variables used in the playbook.


# What is the difference between tasks, roles, and handlers in a playbook?

Tasks: Basic units of work, such as installing a package or copying a file.
Roles: Groupings of tasks, templates, variables, etc., used to modularize playbooks. Roles make it easier to reuse and organize configurations.
Handlers: Special tasks triggered only when notified by another task (e.g., restarting a service after a configuration change).

# How do you pass variables to a playbook, and how would you override default variable values?

Variables can be passed in many ways:
Command line: ansible-playbook playbook.yml -e "var_name=value"
Inventory files: Defined in group_vars or host_vars.
Playbooks: Declared in vars or defaults within roles.
Override: Higher precedence variables (e.g., passed via CLI) will override lower precedence variables (e.g., set in playbooks).

# Can you explain the use of loops, conditionals (when), and includes in Ansible playbooks?

Loops: Allow multiple iterations over lists or dictionaries (e.g., with_items, loop).
Conditionals (when): Define conditions for executing tasks (e.g., when: ansible_facts['distribution'] == 'Ubuntu').
Includes: Allows modularization of playbooks by including other playbooks, tasks, or files (e.g., include_tasks: other_playbook.yml).

# What is the purpose of notify in a playbook, and how do handlers work in Ansible?

Notify: Triggers a handler when a task completes. Handlers are typically used to restart services after a change. For example, a task may notify a handler to restart a service if a configuration file changes.

# What is the tags feature in Ansible, and how would you use it in a large-scale playbook?

Tags allow you to run specific tasks in a playbook. Useful for large playbooks to run only a subset of tasks. Example: ansible-playbook playbook.yml --tags "install, config".


============================================================================================================

# What are Ansible modules, and can you name some commonly used modules in real-time DevOps scenarios?

Modules are the core building blocks of Ansible, performing specific tasks. Examples:
yum, apt: Package management on Linux systems.
service: Start, stop, or restart services.
copy: Copy files to managed nodes.
template: Copy a Jinja2 template to a managed node.
git: Clone or update a repository.
docker_container, docker_image: Manage Docker containers and images.

# Can you explain the difference between command and shell modules in Ansible?

command: Executes a command on the remote system without invoking a shell. It’s safer because it avoids the risk of shell injection.
shell: Executes a command through the shell (e.g., sh, bash), and can handle shell-specific functionality like piping and redirection

# How do you create custom Ansible modules, and when would you need to write them?

Custom modules can be written in Python or other languages. They are needed when existing modules don't meet your specific needs or when you need to integrate with external systems.

# How would you handle large file transfers using Ansible (e.g., using the copy or synchronize module)?

For large files, the synchronize module (which uses rsync) is more efficient as it only transfers changed parts of files and can resume interrupted transfers.

============================================================================================================

# How do you deploy configuration files using Ansible, and what role does Jinja2 templating play in this process?

Ansible uses the template module to deploy configuration files. Jinja2 templating allows dynamic variable substitution within configuration files. For example, replacing values like IP addresses or service names based on the environment.

# Explain the use of ansible.cfg file. What are some key configurations you can manage using this file?

ansible.cfg is the configuration file for Ansible that manages default settings such as the inventory location, roles path, module settings, and SSH timeout. Key configurations:
Inventory: Set default inventory location.
Timeout: Control timeouts for tasks.
Privilege escalation: Configure sudo or become settings.

# What is the purpose of Ansible Vault, and how would you use it for storing sensitive data?

Ansible Vault encrypts sensitive data (e.g., passwords, keys) within playbooks, roles, or variable files. It ensures secure storage and prevents accidental exposure. Usage: ansible-vault encrypt file.yml and ansible-playbook --ask-vault-pass playbook.yml.

# How would you ensure that a service (e.g., NGINX, Apache, MySQL) is installed, configured, and running using Ansible?

Use modules like yum or apt to install the service, template to deploy configuration files, and service to ensure the service is running and enabled.

