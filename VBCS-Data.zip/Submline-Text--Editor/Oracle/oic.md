# ATP(Autonomous Transaction Processing) => limited control => oracle automated entire thing
# DBaaS (Database as a Service) => full control but we need to DBA recommended => we need manual setup



# Intro OIC
* Oracle Integration Cloud (OIC) is a cloud-based tool that helps different applications talk to each other. 
* It allows businesses to connect their software systems, automate processes, and transfer data smoothly without needing complex coding.


# Real-Time Example
📌 Scenario: Connecting an E-commerce Website with an Inventory System
Imagine you run an online store. When a customer places an order, the order details need to be sent to the inventory system to check product availability.
🔹 Without OIC: You would manually update the inventory system, which takes time and can lead to errors.
🔹 With OIC:
OIC automatically sends the order details from the website to the inventory system.
If the product is available, OIC updates the order status and notifies the customer.
If the product is out of stock, OIC can trigger an alert to reorder stock.

# Difference between SOA and OIC:
📌 SOA (Service-Oriented Architecture)
✅ Architecture: Traditional integration model using SOA Suite (BPEL, Mediator, OSB, Human Workflow, Business Rules).
✅ Deployment: On-premises, requires dedicated hardware & maintenance.
✅ Integration Method: Uses Enterprise Service Bus (ESB) for routing & transformations.
✅ Development Effort: Manual, code-heavy development for complex workflows.
✅ Scalability: Harder to scale due to infrastructure limitations.
✅ Monitoring & Maintenance: Requires dedicated IT teams for monitoring & troubleshooting.
✅ Use Cases: Best for large enterprises with long-running transactions (e.g., banking, telecom).
High – Requires SOA Suite license (BPEL, OSB, BPM, etc.)


📌 OIC (Oracle Integration Cloud)
✅ Architecture: Cloud-based iPaaS (Integration Platform as a Service) with pre-built connectors.
✅ Deployment: Fully cloud-based, managed by Oracle (no on-prem setup needed).
✅ Integration Method: Uses pre-built Adapters & REST/SOAP APIs for quick integration.
✅ Development Effort: Low-code/no-code, with drag-and-drop UI for fast development.
✅ Scalability: Easily scalable in the cloud with automatic updates.
✅ Monitoring & Maintenance: Built-in Monitoring & Error Handling tools.
✅ Use Cases: Best for SaaS & Cloud-based integrations (e.g., Salesforce, Oracle ERP Cloud).
Lower – Pay-as-you-go model (subscription-based)

###################################################################################################################


# OIC Cloud Provides 3 main components for business purpose:
1. Integrations
2. Process Automation(BPL)
3. VBCS(visual builder cloud studio)

##################################################################################################################

# Types of Integrations
1. App-Driven Orchestration (Event-Based Integration) => Syncing customer data between apps
2. Scheduled Orchestration (Time-Based Integration) => Nightly data sync from database
3. File Transfer (FTP/SFTP-Based Integration) => Moving order files from an FTP server
4. Publish to OIC (Event Publishing) => Notify multiple systems about an order
5. Subscribe to OIC (Event Subscription) => Process customer registration events

##############################################################################################################


# Types of Adapters:
1. Application Adapters => connects Business Apps => Oracle ERP, Salesforce, SAP => Sync orders, invoices, employees
2. Techology Adapters => Connects to APIs & protocols => REST, SOAP, FTP, JDBC	=> Call APIs, fetch data, move files
3. Messaging Adapters => Asynchronous messaging => JMS, Kafka, Oracle AQ => Event-based processing
4. Database Adapters => Connects to databases => Oracle DB, MySQL, SQL Server =>	Read/write to databases
5. B2B Adapters => Handles EDI & B2B transactions	=> EDI X12, EDIFACT, AS2 =>	Automate supplier & customer transactions

###############################################################################################################

#  Summary
* Integrations → The main workflows connecting applications.
* Connections → Define how OIC connects to an external system.
* Lookups → Convert values between different systems.
* Packages → Group similar integrations together.
* Agents → Allow OIC to access on-premises apps securely.
* Adapters → Pre-built connectors for different applications.
* Libraries → Store reusable functions & scripts.

################################################################################################################

# Versioning
* 01.00.0000 => 01.01.0000 => 02.00.0000
1. 01 => major => release or major changes in the integration
2. 00 => minor => small improvements new features
3. 0000 => patch => bug fixes security patches

################################################################################################################
# Roles in integration:
1. trigger => inbound => this is start automatically
2. invoke => outbound => only needs to send data to another system
3. Trigger & Invoke => two is working

# security policies:
1. basic authentacation
2. OAuth2.0
3. OAuth2.0 or basic authentacation

# Summary
* Trigger → Inbound request (OIC receives data).
* Invoke → Outbound request (OIC sends data).

###############################################################################################################

# Agents:
Agents in Oracle Integration Cloud (OIC) are used when you need to connect OIC with on-premise systems (databases, applications, ERPs, etc.) that are not directly accessible from the cloud.

# Two types of Agents
1. connectivity Agent => Used to connect on-premise applications like databases, ERP, SAP, etc.
2. Execution Agent => Used for on-premise process automation (less commonly used).

# Real-Time Example
Scenario: Reading Employee Data from an On-Premise Oracle Database
Problem: OIC needs to fetch employee data from an on-premise Oracle Database, but OIC cannot access it directly because it's behind a firewall.
Solution: Install a Connectivity Agent inside the on-premise network.

# How it Works?
The agent acts as a bridge between OIC and the database.
OIC sends a request to the agent.
The agent fetches the data from the database and sends it back to OIC.


##################################################################################################################

# OAuth2.0 Setup In Oracle Cloud:
=> OAuth is open Authentacation protocol to protect the resources. it is the industry standard protocol for authorization.
1. create an confidential Application in identity Domain
2. generate the client id and client secret
3. choose security policy as OAuth2.0 in Rest trigger
4. Generate Access Token

# need to entire invoke is Asking So many Security Policies -> like Apikey and OAuth2.0 and so many are there in Oic console

# URL Explanation
1. https:// => protocols
2. example.com => domain name
3. Path => /api/employees
4. Query String	 => ?id=123&name=john
5. ? => separate the base url from Query String

###############################################################################################################

SOAP(Simple Object Access Protocol):
# formates
1. soap => request is xml and response xml => Slower (heavy XML processing)	
2. rest => used json by default also supports xml => Faster (lightweight JSON)

# WSDL(web service description language): 
# it have the parameters:
* What operations the service supports.
* What parameters it expects.
* What response format it returns.

##############################################################################################################

# File server:(SFTP):
1. file server in oic is a built-in  sftp(secure file transfer protocol) server allows to organizations
to store,manage,and exchange files securily within oic. it enables seamless integration between applications
that require file-based communication.

# FTP(File Transfer protocol):
1. The FTP Adapter in Oracle Integration Cloud (OIC) is a prebuilt connector that allows OIC integrations to connect with external FTP/SFTP servers (on-premises or cloud-based). FTP Provides Seamless integration with many other systems that is provide some features like
* Reading/Writing files
* Polling files from an FTP/SFTP server
* Transferring files between systems
2. it supports operations like read,write,delete,move,list,download
3. support to upload schema files to create structured way
(csv,xsd,xml,json)


# Stage file:
-> The Stage File action in Oracle Integration Cloud (OIC) is used to read, write, zip, unzip, and process files stored temporarily within an integration. It acts as a temporary storage location for file-based data before further processing.

# Example Use Case
📌 Scenario: A company receives customer orders as a CSV file via an FTP server. They need to process and store the data in Oracle ERP Cloud.

🔹 Solution using Stage File in OIC:
FTP Adapter downloads the CSV file from the FTP server.
Stage File action stores the file temporarily in OIC.
Stage File action reads the file and processes the data in chunks.
Data Mapping is applied to convert the CSV structure into Oracle ERP format.
ERP Adapter sends the processed data to Oracle ERP Cloud.
Stage File deletes the temporary file after successful processing.

# PGP(pretty Good Privacy):
* PGP (Pretty Good Privacy) is a data encryption and decryption program used for secure communication and file encryption. It ensures confidentiality, integrity, and authentication of data during transmission.
* PGP is widely used for encrypting emails, files, and documents, especially in secure file transfers (SFTP/FTP) and data integration processes.


###############################################################################################################

