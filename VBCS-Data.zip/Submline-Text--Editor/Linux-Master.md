# Linux
- What is Linux?
Linux is an open-source operating system that is fast, secure, and customizable. It is widely used on servers, desktops, and in embedded systems.

# Why is Linux Preferred for Servers and Production?
- Free and Open Source: No licensing costs, and it's customizable.
- Stable and Reliable: Linux runs for long periods without crashes, making it ideal for production - environments.
- Secure: Offers strong security features, frequent patches, and a permission-based access system.
- Performance: Lightweight and resource-efficient, it runs well on minimal hardware.
- Scalable: Suitable for everything from small devices to large data centers.
- Customizable: Linux can be stripped down to run only the necessary services.
- Community Support: Extensive resources, forums, and documentation.
- Widely Used in Enterprises: Major companies and cloud providers (e.g., Google, Amazon) rely on Linux.


# Why Not Windows or macOS for Servers?
- Windows:
  Costly Licenses: Requires paid licenses for Windows Server.  
  Less Efficient: More resource-heavy and requires frequent reboots.  
  Less Secure: More vulnerable to malware than Linux.

- macOS:
  Not Designed for Servers: Primarily for personal use, not optimized for production.
  Expensive Hardware: Runs only on Apple devices, which can be costly.
  Limited Enterprise Support: Not widely adopted in server environments.


# Components of Linux OS

- Kernel:
  The kernel is the heart of the OS, handling tasks like process management, memory management, and hardware communication. It is the interface between the hardware and software on your system.

- Shell:
  This is how you interact with the Linux OS. It's a command-line interface that lets you run commands, scripts, and interact with the system.

- File System:
  The file system organizes how data is stored on storage devices (like hard drives or SSDs). Linux uses a hierarchical directory structure where everything starts from the root directory /.

- System Libraries:
  These provide essential functions for applications to run. They ensure that programs can communicate with the kernel and perform system-level tasks, such as input/output or network communication.

- System Utilities:
  Utilities are small programs that allow you to perform tasks like copying files (cp), listing directories (ls), or viewing system processes (ps). These are key for managing the system.

- User Interface (UI):
  Linux supports both CLI (command-line interface) and GUI (graphical user interface). For example, Ubuntu uses GNOME, while KDE Plasma is another popular option.

- Package Manager:
  This tool simplifies the installation, upgrading, and removal of software packages. It automatically handles dependencies and ensures that software works with your system. Examples include apt (Debian/Ubuntu), yum (CentOS), and dnf (Fedora).

- Device Drivers:
  Drivers are required to enable the OS to communicate with hardware components like printers, video cards, network adapters, etc. In Linux, these are typically included in the kernel or as modules that can be loaded when necessary.

- Processes and Daemons:
  Linux runs processes (active programs) and daemons (background services). Daemons manage tasks like web servers, database management, and network communication without needing user interaction.

- Configuration Files:
  These files are used to configure system settings (such as user accounts or networking). They are often text files located in directories like /etc, which administrators can edit to modify system behavior.


++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


# System and Process Management
- top: Displays real-time system statistics like CPU and memory usage.
- htop: Interactive process viewer (improved version of top).
- ps aux: Shows running processes on the system.
- kill: Terminates a process by its PID (Process ID).
- systemctl: Manages system services (e.g., systemctl start nginx or systemctl status apache2).
- journalctl: Views logs of systemd services (e.g., journalctl -u nginx)
- uname -a => detailed system information
- shutdown -h now   # Shut down immediately
- shutdown -r now   # Restart immediately


# File and Directory Management
- ls: Lists files and directories (e.g., ls -l for detailed listing).
- cd: Changes the current directory.
- cp: Copies files or directories (e.g., cp file1 file2).
- mv: Moves or renames files (e.g., mv file1 file2).
- rm: Removes files or directories (e.g., rm -rf for recursive removal).
- find: Searches for files and directories (e.g., find /path -name 'file*').
- tar: Compresses and extracts files (e.g., tar -czf archive.tar.gz directory).

# Networking and Remote Management
- ping: Checks network connectivity (e.g., ping google.com).
- curl: Transfers data from or to a server using HTTP, FTP, etc. (e.g., curl http://example.com).
- ssh: Securely connects to remote servers (e.g., ssh user@hostname).
- scp: Securely copies files between systems (e.g., scp file1 user@hostname:/path).
- netstat: Displays network connections, routing tables, and interface statistics.
- ifconfig / ip: Displays or configures network interfaces.
- wget: Downloads files from the web (e.g., wget http://example.com/file.tar.gz).
- scp -i /c/Users/rajnages/Downloads/server.ppk Linux-Master ubuntu@ec2-98-80-74-13.compute-1.amazonaws.com:/home/ubuntu


# Disk and Storage Management
- df -h: Displays disk space usage in a human-readable format.
- du -sh: Displays the disk usage of a directory.  <du -sh web -c>
- fdisk: Manages disk partitions.
- lsblk: Lists all block devices like disks and partitions.
- mount: Mounts a filesystem (e.g., mount /dev/sda1 /mnt).
- umount: Unmounts a filesystem.
- Disk space useage:
  Best way to use df -h depends on your need:
  For overall disk usage: df -h
  For a specific directory: df -h /path/to/dir
  To see filesystem type: df -hT
  For inode usage: df -hi

#  User and Permission Management
- useradd, usermod, userdel: Add, modify, or delete users.
- groupadd, groupdel: Add or delete groups.
- chown: Changes file ownership (e.g., chown user:group file). 
  <chown -R user:group /path/to/directory>
  <chown 1001:1001 file.txt>
- chmod: Changes file permissions (e.g., chmod 755 file).

# Logs and Monitoring
- tail -f: Monitors the end of a log file in real-time (e.g., tail -f /var/log/syslog).
- less: Views large log files page by page (e.g., less /var/log/syslog).
- grep: Searches for patterns in files (e.g., grep 'error' /var/log/syslog).
- dmesg: Displays kernel-related messages and system logs.
  The dmesg command in Linux stands for "diagnostic message" or "driver message", and it is used to display the kernel ring buffer messages, which include system startup information, hardware device drivers, and kernel-related logs

- uptime: Shows how long the system has been running.
  <Key Differences:
   head shows the first lines of a file.
   tail shows the last lines of a file.>
- Use more for simple file viewing when you only need forward navigation.
- Use less for more advanced file viewing, with features like backward navigation and searching, especially   for large files.

# Package Management
- apt (Debian/Ubuntu): Installs, updates, and removes packages (e.g., sudo apt install nginx).
- yum (RHEL/CentOS): Installs, updates, and removes packages (e.g., sudo yum install nginx).
- dpkg (Debian/Ubuntu): Low-level package manager for installing .deb packages.
  <dpkg -l | grep docker>
  <apt list --installed | grep package_name>
- rpm (RHEL/CentOS): Installs, updates, and removes .rpm packages

# Automation and Scripting
- cron / crontab: Schedules periodic tasks (e.g., running a backup script).
- ansible: Automates server configuration and application deployment.
- docker: Manages containers (e.g., docker ps to list running containers).
- kubectl: Manages Kubernetes clusters (e.g., kubectl get pods).

# System Resource Management
- free -h: Displays memory usage in a human-readable format.
- vmstat: Displays system performance information.
- iostat: Monitors system input/output device loading.
- sar: Collects and reports system activity information.

# Backup and Recovery
- rsync: Syncs files and directories between systems (e.g., rsync -av source/ destination/).
- dd: Copies and converts files, often used for disk cloning (e.g., dd if=/dev/sda of=/dev/sdb).

# Security
- ufw: Manages the Uncomplicated Firewall (e.g., sudo ufw allow 80/tcp).
- iptables: Configures Linux kernel firewall rules.
- sudo: Executes commands with elevated privileges.

$ free: Memory usage.
$ df: Filesystem disk usage.
$ du: Directory-level disk usage.

#############################################################################################################

1. System Configuration Files:
/etc/hostname: Contains the hostname of the system.
/etc/hosts: Maps IP addresses to hostnames for local name resolution.
/etc/fstab: Lists all disk partitions and storage devices, and their mount points.
/etc/network/interfaces (Debian/Ubuntu): Configures network interfaces.
/etc/sysctl.conf: Configures kernel parameters (e.g., network settings, virtual memory).
/etc/resolv.conf: Defines DNS settings for name resolution.
/etc/apt/sources.list (Debian/Ubuntu): Lists repositories for package installation.

2. Package Management:
/etc/apt/ (Ubuntu/Debian): Directory containing configurations related to package management (apt).
/etc/yum.conf (RHEL/CentOS): Configures YUM package manager.
/var/cache/apt/archives/ (Ubuntu/Debian): Cache for downloaded packages.
/var/lib/rpm/ (RHEL/CentOS): Stores RPM package database.

3. Service Management:
/etc/systemd/system/: Directory where custom systemd unit files (for services) are stored.
/lib/systemd/system/: Contains systemd unit files for system services.
/etc/init.d/: Traditional directory for init.d scripts (SysV init scripts).
/etc/sudoers: Configures user privileges for sudo commands.
/etc/cron.d/: Contains cron job configurations.
/etc/cron.daily/, /etc/cron.hourly/, etc.: Directories for specific time-based cron jobs.

4. Log Files:
/var/log/: Main directory for log files.
/var/log/syslog: System-wide logs (Ubuntu/Debian).
/var/log/messages: General system logs (RHEL/CentOS).
/var/log/auth.log: Logs related to authentication.
/var/log/dmesg: Logs kernel ring buffer messages.
/var/log/apt/history.log (Ubuntu/Debian): Logs of package installations and removals.

5. User and Group Management:
/etc/passwd: Contains user account information (username, UID, GID, etc.).
/etc/group: Contains group information.
/etc/shadow: Stores user password information in a secure way.
/etc/sudoers: Configures user privileges for sudo.
/home/: Contains user home directories.

6. Networking Files:
/etc/hostname: Defines the system’s hostname.
/etc/hosts: Static hostname-to-IP mappings for name resolution.
/etc/network/interfaces (Debian/Ubuntu): Network interface configuration.
/etc/netplan/ (Ubuntu 18.04+): New configuration directory for networking.
/etc/firewalld/ (RHEL/CentOS): Directory for firewall configuration (used by firewalld service).
/etc/iptables/: Legacy firewall configurations.

7. Docker and Containers:
/etc/docker/: Docker configuration files.
/var/lib/docker/: Default Docker directory for images, containers, and volumes.
/etc/systemd/system/docker.service.d/: Directory for custom Docker systemd service configurations.

8. Version Control:
/var/lib/git/: Git repository storage on the server.
~/.gitconfig: User-specific configuration for Git.
/etc/gitconfig: System-wide Git configuration.

9. Security and SSH:
/etc/ssh/sshd_config: Configures the SSH daemon.
/etc/ssh/ssh_config: Configures SSH client settings.
/root/.ssh/: Contains SSH keys for the root user.
/home/user/.ssh/: Contains SSH keys for other users.

10. Performance and Monitoring:
/proc/: Virtual filesystem with process information (e.g., /proc/cpuinfo, /proc/meminfo).
/sys/: Virtual filesystem for kernel and device information (e.g., /sys/class/net/ for network interfaces).
/var/log/sysstat/: Contains logs from sysstat tools like sar, iostat, etc.
/etc/selinux/config: SELinux configuration file (on systems with SELinux enabled).

11. Containerization (Docker, Kubernetes):
/etc/kubernetes/: Configuration files for Kubernetes.
/etc/docker/daemon.json: Configuration for the Docker daemon.

12. Cloud-related Files:
/etc/aws/: Configuration directory for AWS CLI.
/etc/terraform/: Custom configuration for Terraform (if applicable).


##########################################################################################################


# Shell scripting

1. $? (Exit Status)
2. $# (Number of Arguments)
3. $@ (All Arguments)
4. $* (All Arguments - Different Interpretation)
5. `` (Backticks)
6. $() (Command Substitution)
   More modern and preferred method of command substitution.
7. ~ = Home directory of the current user (e.g., /home/username).
8. / = Root directory of the entire file system.
   
9. grep (Global Regular Expression Print)
Purpose: grep is primarily used for searching and filtering text based on patterns (regular expressions).
10. sed (Stream Editor)
Purpose: sed is used for stream editing — meaning it can perform operations like substituting, deleting, and inserting text in a stream of data or in files.
11. awk (Pattern Scanning and Processing Language)
Purpose: awk is a powerful text-processing language used to extract fields and process text based on patterns and actions.

12. The ! operator is used to check for the absence of a condition.
13. In this context, it ensures that the script creates the group only if it doesn't already exist.



- grep: Searches for a pattern in a file and outputs the matching lines.
- find: Searches for files and directories in a directory tree based on specified criteria.
- sed: Stream editor for performing text transformations like substitution, deletion, and insertion.
- less: Pager program to view file content one screen at a time, allowing backward and forward navigation.
- more: Simple pager program to view file content one screen at a time, with limited navigation.
- head: Displays the first few lines (default 10) of a file or output.
- tail: Displays the last few lines (default 10) of a file or output.
- cut: Extracts specific columns or fields from a file or input based on delimiters.
- awk: A powerful text-processing tool used to search, manipulate, and analyze text files, especially for pattern matching and generating formatted reports.


# OS
Ubuntu:
- Based On: Debian
- Package Manager: APT (Advanced Packaging Tool) using .deb packages
- Release Cycle: Regular releases every 6 months with Long-Term Support (LTS) versions every 2 years
- Target Audience: Beginner-friendly, desktop users, developers, and servers
- Focus: Ease of use, user-friendly interface, and extensive community support
- Support: Commercial support available through Canonical (the parent company)
- Example Use Case: Ideal for personal computers, development environments, and small to medium-sized businesses.

# Red Hat (RHEL):
- Based On: Fedora (community-driven), with enterprise-level modifications
- Package Manager: RPM (Red Hat Package Manager) using .rpm packages
- Release Cycle: Enterprise-focused, with a focus on stability and long-term support (up to 10 years)
- Target Audience: Enterprises, corporate servers, large-scale infrastructure
- Focus: Stability, security, and professional support for business-critical applications
- Support: Paid support from Red Hat, with access to official documentation, updates, and customer service
- Example Use Case: Used in large enterprise environments, data centers, and mission-critical applications.

# Debian:
- Based On: Independent, not derived from any other major distribution
- Package Manager: APT using .deb packages
- Release Cycle: More conservative release cycle with a focus on stability, releases are made when the system - is ready
- Target Audience: Advanced users, developers, and those needing a stable system
- Focus: Stability and freedom, with a large repository of software
- Support: Community-driven support (no commercial support, although third-party support is available)
- Example Use Case: Preferred for servers, particularly when maximum stability and control are required.

# Key Differences:
- Ubuntu is based on Debian and is designed to be user-friendly, making it a popular choice for desktop and server environments.
- Red Hat (RHEL) is a commercial distribution focused on enterprise environments, offering extensive support and stability for businesses.
- Debian is known for its stability and freedom, with a slower release cycle and a preference for open-source software, appealing to advanced users and those prioritizing stability over new features.










