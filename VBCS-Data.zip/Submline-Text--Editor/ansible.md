# Ansible
Ansible is an open-source automation tool used to simplify IT tasks like configuration management, application deployment, and task automation. It allows you to manage multiple systems efficiently and consistently.

# Why is Ansible Used?
- Automation: Automates repetitive tasks, saving time and reducing errors.
- Agentless: Unlike many other tools, Ansible doesn't require agents installed on client systems. It communicates using SSH or APIs.
- Simple Syntax: Uses YAML-based playbooks, which are easy to read and write.
- Scalability: Can manage a few servers or thousands of machines seamlessly.
- Cross-Platform: Works with various operating systems like Linux, Windows, and even network devices.

# Components of Ansible
1. Inventory: A list of machines (servers, devices) you want to manage. It tells Ansible where to connect.
   Example: webserver1, dbserver2.

2. Modules: Small programs used to perform tasks like installing software, copying files, or managing services.
   Example: yum, apt, copy.

3. Playbooks: YAML files that describe what tasks Ansible should do and in what order.
   Example: A playbook to set up a web server.

4. Tasks: Individual actions Ansible performs, like installing a package or restarting a service.
   Example: Install Apache.

5. Roles: Organized collections of tasks, variables, templates, and files to make playbooks reusable.
   Example: A role to configure a database.

6. Templates: Files with placeholders for variables, used to create customized configuration files.
   Example: A template for a web server config file.

7. Variables: Values used to make tasks flexible and reusable.
   Example: server_name: mywebsite.com.

8. Handlers: Tasks that only run when triggered by another task, often used for restarting services.
   Example: Restarting a web server after a config change.

9. Facts: Information Ansible gathers about systems, like OS type or IP address, to help make decisions.
   Example: ansible_os_family.