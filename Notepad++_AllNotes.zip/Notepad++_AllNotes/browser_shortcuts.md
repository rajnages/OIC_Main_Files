
# Common Browser Shortcuts

## Tab & Window Management
| Shortcut | Action |
|---------|--------|
| `Ctrl + T` | Open a new tab |
| `Ctrl + W` | Close current tab |
| `Ctrl + Shift + T` | Reopen last closed tab |
| `Ctrl + N` | Open a new window |
| `Ctrl + Shift + N` | Open a new incognito/private window |
| `Ctrl + Tab` or `Ctrl + Page Down` | Switch to the next tab |
| `Ctrl + Shift + Tab` or `Ctrl + Page Up` | Switch to the previous tab |

## Navigation
| Shortcut | Action |
|---------|--------|
| `Alt + Left Arrow` | Go back |
| `Alt + Right Arrow` | Go forward |
| `F5` or `Ctrl + R` | Reload page |
| `Ctrl + F5` | Hard reload (bypass cache) |
| `Esc` | Stop loading the page |

## Search & Address Bar
| Shortcut | Action |
|---------|--------|
| `Ctrl + L` or `Alt + D` | Focus address bar |
| `Ctrl + K` or `Ctrl + E` | Focus search bar (if separate) |
| `Ctrl + F` | Find on page |
| `Ctrl + H` | Open history |
| `Ctrl + J` | Open downloads |

## Zoom & View
| Shortcut | Action |
|---------|--------|
| `Ctrl + +` | Zoom in |
| `Ctrl + -` | Zoom out |
| `Ctrl + 0` | Reset zoom |
| `F11` | Toggle full screen |

---------------------------------------------------------------------------------------------------------------------------------

-> win + D,E,I,L,R,S,X,Tab,v => Navigation
-> win + Arrow keys
-> win + shift + s => sketch & spin
