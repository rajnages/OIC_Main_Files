# VPC Complete guide:
A Virtual Private Cloud (VPC) is a logically isolated network in the cloud where you can launch AWS resources. It gives you control over network settings, such as IP address ranges, subnets, route tables, gateways, and security.


# Default and non-default VPCs
Default VPCs and non-default VPCs are two types of virtual private clouds available in AWS.

# Core Components of VPC
1. VPC
- Purpose: A logical network to house your AWS resources securely.
- Why Use: Provides network isolation, IP address control, and supports private and public subnets.
- When Use: Always required for setting up any AWS network.

2. Subnets
- Purpose: Divide the VPC into smaller segments for resource grouping.
- Types:
- Public Subnet: For resources accessible from the internet (e.g., web servers).
- Private Subnet: For resources not directly exposed to the internet (e.g., databases).
- Why Use: Logical separation of workloads with different access requirements.
- When Use:
- Public Subnet: Hosting web servers.
- Private Subnet: Storing sensitive data like in databases.

3. Internet Gateway (IGW)
- Purpose: Enables communication between resources in your VPC and the internet.
- Why Use: To allow public subnets to access or be accessed from the internet.
- When Use: When hosting public-facing applications.

4. NAT Gateway (or NAT Instance)
- Purpose: Allows private subnet resources to access the internet without being directly accessible from the internet.
- Why Use: For updating software, downloading patches, or accessing third-party APIs.
- When Use: For private subnet communication to the internet while keeping them secure.

5. Route Tables
- Purpose: Define how traffic is directed within the VPC.
- Why Use: To manage routing between subnets, internet gateways, and other VPCs.
- When Use:
- Internet Gateway: Add route for 0.0.0.0/0 to IGW in public subnet route table.
- NAT Gateway: Add route for 0.0.0.0/0 to NAT Gateway in private subnet route table.

6. Security Groups
- Purpose: Act as a virtual firewall at the instance level to control inbound and outbound traffic.
- Why Use: To ensure that only the required traffic reaches instances.
- When Use: Always attach to EC2 or other AWS resources for granular control.

7. Network ACLs (NACLs)
- Purpose: Act as a stateless firewall at the subnet level.
- Why Use: To apply broader security rules across subnets.
- When Use: For additional security, especially when subnets share resources with multiple applications.

8. Elastic IP (EIP)
- Purpose: A static, public IPv4 address for your resources.
- Why Use: To maintain a consistent public address for critical resources.
- When Use: For resources requiring fixed public IPs (e.g., bastion hosts).

9. Peering Connections
- Purpose: Enable VPC-to-VPC communication.
- Why Use: To connect two VPCs without requiring the internet.
- When Use: For private communication between two applications hosted in separate VPCs.

10. VPC Endpoints
- Purpose: Privately connect to AWS services without an internet gateway, NAT, or VPN.
- Why Use: To securely access services like S3 or DynamoDB from your VPC.
- When Use: For better security and cost savings by avoiding NAT Gateway costs.



========================================================================================================

# To enable outbound private connectivity for resources in private subnets inside a VPC:
- NAT Gateway: Deploy in a public subnet. Private subnet routes use it for internet access securely.
- NAT Instance: Similar to NAT Gateway but requires manual setup.
- VPC Endpoint: Direct access to AWS services (e.g., S3, DynamoDB) without internet.
- PrivateLink: Private connection to AWS/third-party services over the AWS network.
- VPN/Direct Connect: Secure connection to on-premises or other VPCs.
- Transit Gateway: Centralized internet access for multiple VPCs.

- The NAT Gateway + VPC Endpoints combination is most common.

==========================================================================================================

VPC Peering
Purpose: Enables private communication between two VPCs.
How It Works: Routes traffic between VPCs using private IP addresses.
Use Cases:
Sharing resources like databases between different VPCs.
Connecting VPCs across regions (Inter-region VPC Peering).
Characteristics:
Bidirectional: Both VPCs can communicate.
Private IP Communication: Traffic doesn’t go over the internet.
No Transitive Peering: One VPC can't route traffic to another VPC via a third VPC.
Cost: You pay for data transfer between VPCs.
Steps to Set Up VPC Peering:
Create Peering Connection: Initiate a request from one VPC.
Accept the Request: In the peer VPC, accept the connection.
Update Route Tables: Add routes in both VPCs to route traffic between them.


VPC Endpoints
Purpose: Allows private connections to AWS services without using the public internet.
How It Works: Uses interface endpoints (elastic network interfaces) or gateway endpoints (specific to S3/DynamoDB).
Use Cases:
Accessing S3, DynamoDB, or other AWS services privately.
Avoid internet exposure for service access.
Types:
Gateway Endpoints: For S3 and DynamoDB.
Interface Endpoints: For other AWS services like EC2, SNS, etc.
Characteristics:
No Public Internet Traffic: Communication happens through the AWS backbone network.
Security: Access is controlled via security groups and IAM policies.
Cost: You pay for data processed through the endpoint (interface endpoint costs).


Types of VPC Peering

Intra-Region VPC Peering:

Description: Peering connections between VPCs within the same AWS region.
Use Case: Typically used when you have multiple VPCs within a single region that need to communicate privately.

Inter-Region VPC Peering:

Description: Peering connections between VPCs in different AWS regions.
Use Case: Used when VPCs in different regions need to communicate over private IP addresses, enabling global applications.

Types of VPC Endpoints
Gateway Endpoint:
Description: A VPC endpoint for services like Amazon S3 and Amazon DynamoDB. It is used to route traffic to these services via the AWS private network without requiring an internet gateway, NAT device, VPN, or Direct Connect.
Use Case: Best for private access to S3 or DynamoDB without using public IP addresses.
Interface Endpoint:
Description: A VPC endpoint for other AWS services (like EC2, SNS, SQS, Lambda, etc.) through private IPs using Elastic Network Interfaces (ENIs).
Use Case: Used for private communication with a wide range of AWS services or third-party services available in AWS Marketplace.

Summary of VPC Peering Types
Intra-Region VPC Peering: Same region, same AWS region.
Inter-Region VPC Peering: Different AWS regions.

Summary of VPC Endpoint Types
Gateway Endpoint: For S3 and DynamoDB.
Interface Endpoint: For other AWS services (EC2, SNS, etc.).


ssh -i key.pem ubuntu@98.80.251.67 -o ProxyCommand="ssh -i key.pem ubuntu@10.0.0.41 -W %h:%p"
aws sqs send-message --queue-url https://sqs.us-east-1.amazonaws.com/874616579683/main-queue --message-body "Test message"