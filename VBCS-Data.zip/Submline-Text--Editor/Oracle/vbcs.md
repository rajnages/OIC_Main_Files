# vbcs and redwood Application
1. vbcs is low code development platform for building custom web and mobile Applications using drag-drop components 
and rest Api integrations

# Redwood Applications
1. Oracle Redwood is the modern design system introduced by Oracle to create consistent, visually appealing, and responsive UIs across all Oracle Cloud applications.


# What is JSON?
=> JSON is a lightweight data format used to store and exchange data between different parts of an application.
=> In VBCS, JSON is used to define variables, store API responses, and configure data bindings.
=> This JSON object can be used in VBCS as a page variable or service variable.

# Variables:
1. Page Variables	        Available within a single page	Store temporary values like form inputs
2. Application Variables	Available across all pages	    Store user session data (e.g., logged-in user details)
3. Service Variables	    Store REST API responses	    Store data fetched from an external service


# What are Action Chains?
=> Action Chains are sequences of actions that execute when an event occurs.
=> They automate workflows like API calls, data processing, and UI updates.


# REST APIs:
=> REST APIs allow communication between VBCS and external data sources (databases, other applications, etc.).


# Oracle VBCS provides a low-code way to develop full-stack applications.
# The frontend (UI) interacts with the backend (REST APIs) using variables, event listeners, and action chains.
# JSON and JavaScript handle data and business logic.
# REST APIs allow integration with external data sources.

# Does Oracle VBCS Directly Communicate with Oracle ERP Applications?
1. No, Oracle VBCS does not directly communicate with Oracle ERP Cloud (or other Oracle SaaS applications like HCM, SCM, CX, etc.). Instead, it integrates with ERP applications using REST APIs or Oracle Integration Cloud (OIC).

# Why Can’t VBCS Directly Connect to ERP?
1. Oracle ERP Cloud and other SaaS applications have strict security controls and do not expose their database directly to external applications like VBCS. Instead, they provide REST APIs as the official way to exchange data.


#########################################################################################################

# padStart:
Dates like day and month can be single digits (e.g., 1, 2, ..., 9).
But in date formats like dd-MM-yyyy, you typically want two digits, like: