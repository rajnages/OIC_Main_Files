# Docker basics:

# What is Docker why we used:
1.Docker is an open-source platform that lets you build, run, and manage applications in lightweight, portable containers. It ensures applications run consistently across different environments.
2.We use Docker to run applications consistently across different environments, making deployment faster, efficient, and portable.

# Example:
A developer creates a containerized web application. Whether it runs on a local machine, testing server, or production server, Docker ensures it behaves the same way, avoiding the common "it works on my machine" issue.

# Container
A container is a lightweight, standalone package that includes an application and all its dependencies, ensuring it runs consistently across any environments

# Difference between VM's and Containers:

1.Container Architecture.
Containers are lightweight, isolated  for running applications on the host operating system. They share the host OS kernel and contain only the necessary applications and some lightweight OS APIs and services
This makes containers more agile and portable compared to VMs

2.Virtual Machine Architecture.
VMs run a complete operating system, including its own kernel, on top of an emulating software called the hypervisor.The hypervisor manages the sharing of physical resources into virtual machines, allowing each VM to run its guest OS his provides strong isolation but requires more system resources.

=============================================================================================================

# Docker architecture:

1.Client
  Doker run 
  Docker build
  Docker pull
2.Docker Host
  Docker daemon
  images
  containers
3.registry
  images
  extensions
  plugins

# Workflow
The Docker daemon (dockerd) runs as a background process and listens for API requests from clients (e.g., Docker CLI). The Docker client (e.g., the docker command-line tool) sends commands (such as docker run, docker build, etc.) to the Docker daemon, which processes and executes those commands.

a container is a process like any other but when created it receives special configurations. So just like any process, it has a Process ID (PID) and a Parent Process ID (PPID)

The sequence of events when we run a Docker command looks like this:
Docker client -> Docker daemon (dockerd) -> Container daemon (containerd) -> runc

# So when you use Docker, you tell Docker what to do, Docker’s manager (dockerd) asks its worker (containerd) to do the job, and the worker uses special features and rules (namespaces, cgroups, and runc) to make sure the job gets done within an/the isolated environment (container).

============================================================================================================

# Images
- A Docker image is a lightweight, standalone, and executable package that contains everything needed to run a piece of software. It includes the code, runtime, libraries, dependencies, and configuration files. Think of it as a blueprint or template used to create containers.

1. an image is the application we want to run
2. a container is an instance of that image running as a process
3. you have many containers running off the same image.

# What happens in docker container run:
1. looks for that image locally in image cache, doesn't find anything
2. then looks in remote image repository(defaults to docker hub)
3. Downloads the latest version
4. Creates new container based on that image and prepares to start
5. Give it a virtual ip on a private network inside docker engine
6. Opens up port 80 on host and forwards to port 80 in container
7. Starts container by using the CMD in the image dockerfile

# Master-Worker Architecture:
PID 1 is the master process
PID 29 is a worker process
Master manages workers, workers handle requests

#########################################################################################################

# Docker networking
1. Docker networking allows containers to communicate with each other, the host system, and external networks.

# Docker Network Drivers
1. Bridge Networks
Default network type for standalone containers.
Containers on the same bridge network can communicate using IP addresses or container names.
Suitable for applications running on a single host.

2. Host Networks
Containers share the host's network stack.
No network isolation between the container and the host.
Offers performance benefits by reducing network overhead.

3. Overlay Networks
Used for swarm services and multi-host networking.
Enables containers running on different Docker hosts to communicate securely.
Requires a key-value store like Consul or etcd for coordination.

4. Macvlan Networks
Assigns a MAC address to each container, making it appear as a physical device on the network.
Containers can be directly connected to the physical network.
Useful for legacy applications requiring direct network access.

Summary:
Bridge Network: Used for containers within the same host (e.g., frontend and backend containers).
Host Network: Used for performance-critical services (e.g., load balancer).
Overlay Network: Used for multi-host communication, especially for scaling (e.g., distributed backend).
None Network: Used for isolated containers that don’t need network access (e.g., logging container).


#############################################################################################################

# docker0 is the default virtual network bridge created by Docker. It connects containers to each other and allows them to communicate with the host system.
1. Every container attached to docker0 gets an internal IP address.
2. Containers can communicate via this bridge unless explicitly restricted.
3. It facilitates networking between containers and the host system.

############################################################################################################

# Docker volumes
1. Volumes in Docker are used to store data outside containers so it persists even if the container is deleted or recreated.

# Why Use Docker Volumes?
1. Data Persistence: Keeps data safe even when containers are removed or recreated.
2. Sharing Data: Allows multiple containers to share data.
3. Separation of Data: Keeps data separate from the container, making the container easier to manage.
4. Backup and Restore: Makes it easy to back up and restore data.

# Types of Volumes:

1. Named Volumes:
   What It Is: A Docker-managed volume stored in a specific location.   
   Why Use: Easy to manage and persistent across container recreations.
   Example: docker volume create my_volume
            docker run -v my_volume:/data my_container

2. Anonymous Volumes:
   What It Is: A volume without a name, created automatically when you mount a path.
   Why Use: Quick setup for temporary data.
   Example: docker run -v /data my_container

3. Bind Mounts:
   What It Is: Maps a directory on the host machine to a container directory.
   Why Use: Useful for development when you want the container to directly access host files.
   Example: docker run -v /host/path:/container/path my_container

# The -v /my/own/datadir:/var/lib/mysql part of the command mounts the /my/own/datadir directory from the underlying host system as /var/lib/mysql inside the container, where MySQL by default will write its data files.

#############################################################################################################

# Dockerfile components

# ARG APP_VERSION
1. The --build-arg option in Docker is used during build time, not run time. It allows you to pass build-time variables to the Docker build process, which can be accessed within the Dockerfile
- Advantages of --build-arg
   Customization: Dynamically modify the build process (e.g., version, environment-specific configuration).

  DisAdvantages:
- Limited Scope: Variables are only available during the build process and not at runtime.
- Not Secure: Arguments passed via --build-arg may be visible in build logs.

# FROM baseimage
1. specify the base image
2. Starting point for your image. Choose based on your application needs

# MAINTAINER (Legacy) / LABEL
1. Adds metadata to images
2. Organizing images in large organizations, tracking ownership, versioning

# RUN
1. Executes commands during build
2. Installing packages, system updates, creating directories

# COPY vs ADD
1. Simple file copying - COPY src/ /app/
2. Advanced copying with extra features - ADD https://example.com/file.tar.gz /app/
- Real use:
COPY: Most common, copying application code
ADD: Downloading remote files, auto-extracting archives

# ENV
1. Sets environment variables
2. eal use: Configuration settings, paths, application behavior control

# ARG
1. Build-time variables
2. Real use: Passing build-time configurations, versions during docker build
3. ARG (Build-time arguments)
   Only available during image build
   Not available when container runs
   Set using --build-arg when building image

# Difference between env and arg
1. ARG:
   Only for build time
   Not available in running container
   Set with --build-arg
   Good for build configuration
2. ENV:
   Available at build and runtime
   Can be changed when running container
   Set with -e or --env
   Good for application configuration

# WORKDIR
1. Sets working directory
2. Real use: Organizing files, setting context for RUN, CMD, ENTRYPOINT

# EXPOSE
1. Declares container ports
2. Real use: Documentation of service ports, networking setup
3. EXPOSE is just documentation and doesn't create any actual port bindings
4. You must explicitly map ports using -p when running containers to make them accessible from the host

# VOLUME
1. Creates mount points
2. Real use: Persistent data storage, sharing data between containers

# USER
1. Sets user context
2. Real use: Security, running processes as non-root

# CMD vs ENTRYPOINT
1. CMD: Default command
- CMD ["nginx", "-g", "daemon off;"]
- CMD ["python", "app.py"]
- ENTRYPOINT is like a fixed command that always runs, and anything you add after docker run image becomes additional parameters.
- ENTRYPOINT defines the container's main executable
- CMD provides default arguments to ENTRYPOINT
- CMD can be easily overridden from command line
- CMD: Easily overridable with normal docker run commands
- ENTRYPOINT: Not easily overridable, needs special --entrypoint flag

2. ENTRYPOINT: Container executable
- ENTRYPOINT ["nginx"]
- CMD ["-g", "daemon off;"]

- Real use:
- CMD: Default commands that can be overridden
- ENTRYPOINT: Fixed commands that always run

# HEALTHCHECK
1. Container health monitoring
2. real use: Container health monitoring, orchestration readiness checks

# SHELL
1. Changes default shell
2. Real use: Customizing command execution environment

# ONBUILD
1. Triggers for child images
2. Real use: Creating base images for multiple similar applications

###########################################################################################################

# Docker compose
- Docker Compose is a tool used for defining and managing multi-container Docker applications. With a simple YAML configuration file (docker-compose.yml), you can define services, networks, and volumes to be used by your application and then manage them as a group.

# Why Use Docker Compose?
- Simplifies Multi-Container Applications:
  Instead of manually running docker run commands for each container, you can define and manage multiple services (like web servers, databases, etc.) in one file.

- Easier Collaboration:
  The docker-compose.yml file is shareable, making it easier for teams to replicate the setup.

- Centralized Configuration:
  All container configurations (network, volume, environment variables) are centralized in one file.

- Single Command Deployment:
  Using commands like docker-compose up, you can start all defined services with a single command.

# Both tools work together in real-world scenarios. A Dockerfile can define how an image is built, and docker-compose.yml can define how that image is deployed along with others.

- Dockerfile is used to build a single custom image by defining step-by-step instructions.
- Docker Compose is used to manage and orchestrate multi-container applications using a YAML configuration.

###########################################################################################################

# Docker swarm:
- Docker Swarm is a native clustering and orchestration tool for Docker. It enables you to manage a cluster of Docker engines (nodes) as a single virtual system. In Swarm mode, you can deploy and manage containers across multiple machines in a Docker cluster.

# Why Use Docker Swarm?
- Docker Swarm is used to manage multi-container applications across multiple hosts, providing:
  
  High Availability: Ensures that services are running even if some nodes fail.
  Scalability: You can scale applications easily by adding or removing nodes.
  Load Balancing: Distributes incoming traffic across containers automatically.

# Docker swarm service:
- Docker Swarm Services
Definition: A service in Docker Swarm is the definition of a containerized application that is distributed and managed across a cluster of nodes.
# Features:
- Scaling: Replicas can be defined (docker service scale).
- Load Balancing: Built-in load balancing among service replicas.
- Simpler Updates: Rolling updates and rollbacks can be performed on services.
- Networking: Uses an overlay network for inter-service communication.
- Use Case: Best for smaller or medium-scale projects requiring quick and simple orchestration.


# Docker swarm stack:
- In Docker Swarm, a stack is a collection of services, networks, and volumes that are deployed together as a single unit. Stacks are defined using a docker-compose.yml file and allow you to manage multiple interdependent services in a Docker Swarm cluster.
- Stacks are deployed using docker stack deploy, while services are created with docker service create.