# AZs and region
Imagine the world as a big map.

Region: A specific country or area on the map where a company has its offices and warehouses.
Availability Zone (AZ): A specific city or town within that region where the company has its main office and a backup office.
Data Center: A building in that city or town where the company stores its important documents and computers.
So, a Region is a big area, an AZ is a smaller area within that region, and a Data Center is a building in that smaller area.


# AWS vpc:
- Think of AWS VPC as your own private network within the AWS cloud. It's like having your own data center, but in the cloud. This isolation ensures your resources are secure and accessible only to authorized users.

# components:
- subnents => Smaller divisions within the VPC for organizing resources.
- route tables => The Traffic Directors of Your VPC
- IGW => Connects your VPC to the public internet.
- NAT => Allows private resources to access the internet without exposing them directly.
- Security Groups: Act as firewalls, controlling inbound and outbound traffic to instances.
- Network ACLs (NACLs): Provide an additional layer of security by controlling traffic at the subnet level.


# vpc peering => Imagine you have two separate networks (VPCs): VPC A and VPC B. To allow these two networks to communicate directly, you can create a VPC peering connection.
# Here's how it works:
- Initiation: One VPC (the requester) sends a request to another VPC (the accepter).
- Acceptance: The accepter VPC either accepts or rejects the request.
- Route Table Configuration: Once accepted, both VPCs update their route tables to recognize each other's network.
- Direct Communication: Instances in one VPC can now communicate with instances in the other VPC using their private IP addresses, as if they were on the same network.

# vpc endpoints => VPC Endpoints allow you to connect your VPC to supported AWS services privately, without exposing your resources to the public internet.

# Two main types:
- Interface Endpoints:
- Connect to a wide range of AWS services (e.g., S3, DynamoDB).
- Use private IP addresses.
- Offer more flexibility and control.
 
# Gateway Endpoints:
- Connect to specific services like S3 and DynamoDB. 
- Simpler to set up.
- Limited to specific services.

# vpc transit gateways => AWS Transit Gateway is a central hub that connects multiple VPCs and on-premises networks. It simplifies network management by eliminating the need for complex peering configurations. This allows for efficient routing and secure communication between different parts of your network.

# dhcp(domain host configuration protocol) => DHCP is a network protocol that automatically assigns IP addresses and other network 1  settings (like subnet mask, default gateway, DNS server addresses) to devices on a network.

# Difference between Public Ip and Private IP and elastic Ip

# Public IP:
- Accessible from the public internet. 
- Dynamic, can change when an instance is stopped and started.

# Private IP:
- Accessible only within your VPC.
- Used for internal communication between instances.

# Elastic IP:
- Static public IP address.
- Can be associated with an instance and remains assigned even if the instance is stopped or restarted.
- Useful for load balancers and other services that require a fixed IP address


- ingress(inbound) and egress(outbound)
# Security Groups:
- Stateful firewalls applied at the instance level.
- Control inbound and outbound traffic for individual instances.
- Typically, you need to specify exact port numbers for inbound traffic (e.g., 22 for SSH, 80 for HTTP).
- For outbound traffic, you can often use a broader range, such as 0-65535, to allow traffic to various destinations.

# Network ACLs:
- Stateless firewalls applied at the subnet level.
- Control traffic entering and leaving an entire subnet.
- Require explicit rules for both inbound and outbound traffic.
- For outbound traffic, you can use a range like 2-65535 to cover most ephemeral ports.


# AWS VPC Limits
# AWS imposes certain limits on VPC resources to ensure fair resource allocation. Here are some common limits:
- VPCs per Region: Default is 5. Can be increased.  
- Subnets per VPC: Default is 200. Can be increased.  
- Security Groups per Network Interface: Default is 5. Can be increased.
- Network ACLs per VPC: Default is 200. Can be increased.
- Rules per Network ACL: Default is 20. Can be increased.
- Internet Gateways per Region: Default is 5. Can be increased.
- NAT Gateways per Availability Zone: Default is 5. Can be increased.  


# AWS VPC Flow Logs:
- VPC Flow Logs is a feature that enables you to capture information about the IP traffic going to and from network interfaces in your VPC. Flow log data can be published to the following locations: Amazon CloudWatch Logs, Amazon S3, or Amazon Data Firehose. After you create a flow log, you can retrieve and view the flow log records in the log group, bucket, or delivery stream that you configured

# difference between vpc peering and vpc private link
- VPC Peering is like connecting two houses directly with a road. Both houses can communicate freely with each other.
- Private Link is like building a tunnel from one house to a specific room in another house. Only that specific room can be accessed.


# AWS VPN(virtual private network):
- AWS VPN is a service that allows you to securely connect your on-premises network to your AWS VPC. It's like a private, encrypted tunnel between your physical network and the cloud

- Virtual Private Gateway – VGW
  A virtual private gateway is the VPN concentrator on the AWS side of the VPN connection
- Customer Gateway – CGW
  A customer gateway is a physical device or software application located on the customer side of the VPN connection.

# AWS Client VPN:
- It is a fully managed remote access VPN solution that allows your distant employees to safely access resources on AWS as well as your on-premises network. It automatically adjusts up or down dependent on demand because it is fully elastic. Your users can access your applications in the same way before, during, and after the transfer to AWS.
- You are billed for the number of active client connections per hour and the number of linked subnets with Client VPN per hour in AWS Client VPN.

# AWS Site-to-Site VPN:
- It is a fully managed service that uses IP Security (IPSec) tunnels to establish a secure link between your data centre or branch office and your AWS resources. You can connect to both your Amazon Virtual Private Clouds (VPC) and the AWS Transit Gateway when utilizing it, and two tunnels are used for each connection to increase redundancy.
- You are charged for each VPN connection hour that your VPN connection is provisioned and available if you create an AWS Site-to-Site VPN connection to your Amazon VPC. Each hour of partial VPN connection consumption is billed as a full hour. All data transferred via the VPN connection is also subject to standard AWS data transfer charges.

# VPN CloudHub
- If you have multiple VPN connections, it can be used to provide secure communication between multiple on-premises sites. It uses a Virtual Private gateway in a detached mode that can be used without a VPC and operates on a simple hub-and-spoke model.

====================================================================================================================

# Route 53
- AWS Route 53 is a highly available and scalable Domain Name System (DNS) web service provided by AWS. It translates human-readable domain names (e.g., example.com) into IP addresses (e.g., 192.0.2.1) that computers use to connect.

# Key Features:
- Domain Registration: Buy and manage domain names directly in Route 53.
- DNS Routing: Direct user traffic to resources inside and outside AWS using routing policies like Simple, Weighted, Latency, and Geolocation.
- Health Checks: Monitor the availability and health of your applications.
- Integration with AWS: Works seamlessly with other AWS services like S3, EC2, and CloudFront.
- Scalability and Reliability: Built on AWS’s global infrastructure.

# Use Cases:
- Hosting websites.
- Managing DNS for AWS or on-premise resources.
- Implementing traffic routing strategies.

- dns region level failover(two regions)

===================================================================================================================

# CloudFront
- Amazon CloudFront is a fast, secure, and scalable Content Delivery Network (CDN) service by AWS. It delivers content (like web pages, videos, APIs, or applications) to users globally with low latency and high transfer speeds using a network of edge locations.

# Why We Use CloudFront:
- Improve Performance: Cache content close to users at edge locations for faster delivery.
- Enhance Security: Protect applications using encryption (HTTPS) and integration with AWS Shield, AWS WAF, and IAM.
- Global Reach: Serve users worldwide efficiently through AWS's global edge network.
- Cost Optimization: Reduce bandwidth costs by caching content and minimizing the load on the origin server.

# Benefits of CloudFront:
- Low Latency: Content is cached closer to users at over 450+ edge locations worldwide.
- High Availability: Built on AWS's fault-tolerant global infrastructure.
- Scalability: Automatically handles traffic spikes without manual intervention.
- Security:
  HTTPS support for secure content delivery.
  Integration with AWS WAF for protection against web attacks.
  DDoS protection with AWS Shield.
- Customizable Delivery:
  Support for dynamic and static content.
  Flexible cache control for efficient content delivery.
- Cost-Effective: Pay-as-you-go pricing and reduced origin load.
- Easy Integration: Works seamlessly with AWS services like S3, EC2, and Elastic Load Balancing.

# Use Cases:
- Accelerating websites and APIs.
- Streaming video and audio.
- Delivering software, game patches, or large files.
- Securing and distributing content globally.


====================================================================================================================

# AWS ACM(Application certificate manager):
- AWS Certificate Manager (ACM) is a service that helps you provision, manage, and deploy SSL/TLS certificates on AWS resources. It ensures secure communication by encrypting data between users and your applications (HTTPS).

# Why We Use ACM:
- To enable HTTPS for secure communication.
- To simplify SSL/TLS certificate management (e.g., renewal and deployment).
- To ensure compliance with security standards.

# Problems Solved by ACM in Real-Time Projects:
- Manual Certificate Management: ACM automates provisioning, validation, and renewal, eliminating manual efforts.
- Security Risks: It reduces risks of expired certificates by auto-renewing them.
- Operational Overhead: Simplifies deployment to AWS services like CloudFront, ALB, and API Gateway.
- Inconsistent Security: Ensures consistent encryption for web apps, APIs, and services.

# Key Benefits:
- Automation: Auto-renews certificates, saving time and effort.
- Seamless Integration: Works with AWS services like CloudFront, Elastic Load Balancer, and API Gateway.
- Free Certificates: ACM provides free SSL/TLS certificates for AWS resources.
- Enhanced Security: Protects data in transit and improves application trust.