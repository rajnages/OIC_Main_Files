1. What is Amazon EKS, and why is it used?
- Amazon EKS is a managed Kubernetes service that helps you run, manage, and scale Kubernetes applications without handling the control plane or infrastructure.

2. How does EKS differ from ECS?
- EKS is based on Kubernetes and supports multi-cloud environments, while ECS is AWS-native and simpler to use for container management.

3. What are the key components of an EKS cluster?
- The control plane (managed by AWS), worker nodes (EC2 or Fargate), kubectl CLI, and networking (VPC, subnets, and security groups).

  The control plane (managed by AWS) -> kube api server, etcd, kube schedular, containerd(docker),eks controller manager, fargate controller manager
  worker nodes(ec2 or fargate) -> kubelet, kube proxy, dockerd(containerd)

