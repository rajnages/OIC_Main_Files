PageModule.prototype.getData = function (Dbo, demandid) {
  var data = [];
  var dE_No_Count = 0; // Count for `dE` as "No"
  var pSC_No_Count = 0; // Count for `pSC` as "No"
  var cap_No_Count = 0; // Count for `cap` as "No"

  if (demandid) {
      let demand = Dbo.find(ele => ele.teamRequestNumber == demandid);
      var temp = {};
      temp['teamRequestNumber'] = demand.teamRequestNumber;
      temp['skillGroup'] = demand.skillGroup;
      temp['cap'] = demand.cap;
      temp['dE'] = demand.dE;
      temp['pSC'] = demand.pSC;
      data.push(temp);
  } else {
      for (let i = 0; i < Dbo.length; i++) {
          var temp = {};  
          temp['teamRequestNumber'] = Dbo[i].teamRequestNumber;
          temp['pSCQualified'] = Dbo[i].pSCQualified;
          temp['capabilityQualified'] = Dbo[i].capabilityQualified;
          temp['dE'] = Dbo[i].dE;
          temp['pSC'] = Dbo[i].pSC;
          temp['cap'] = Dbo[i].cap;

          // Count logic
          if (pSCQualified === "Yes" && capabilityQualified === "Yes") {
              dE_No_Count++;
          } else if (pSCQualified === "No") {
              pSC_No_Count++;
          } else if (capabilityQualified === "No") {
              cap_No_Count++;
          }

          data.push(temp);
      }

      // Add a summary row
      var summary = {};
      // summary['teamRequestNumber'] = "Total No Count";
      summary['pSCQualified'] = "";
      summary['capabilityQualified'] = "";
      summary['dE'] = dE_No_Count; // Count for `dE` "No"
      summary['pSC'] = pSC_No_Count; // Count for `pSC` "No"
      summary['cap'] = cap_No_Count; // Count for `cap` "No"
      data.push(summary);
  }

  return data;
};


// activeFlag='Y'


"activeFlag='Y' AND (globalPractice = 180 OR pSCQualified = 'No' OR capabilityQualified = 'No')"