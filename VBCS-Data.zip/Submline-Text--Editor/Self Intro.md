# Self-Introduction:
Hi, I’m Rajavarapu Nageswarao, a DevOps Engineer with over two years of experience in automating, optimizing, 
and securing cloud infrastructures to support high-performance microservice applications.

My expertise includes working with cloud platforms such as AWS and Azure, containerization using 
Docker and Kubernetes, and Infrastructure as Code (IaC) with tools like Terraform. 
I am also proficient in CI/CD tools such as Jenkins, GitHub Actions, and Ansible. 
Additionally, I have hands-on experience with monitoring and observability tools like Splunk, 
New Relic, and Prometheus, as well as enterprise Kubernetes platforms like OpenShift. 
I also have experience in programming and automation using Python for scripting and workflow 
optimization.

During my tenure at Capgemini, I successfully implemented CI/CD pipelines using 
Jenkins and GitHub Actions, reducing deployment times by 40%. 
I automated cloud provisioning with Terraform and Ansible, significantly reducing manual errors. 
Additionally, my work with monitoring and logging tools such as Splunk, CloudWatch, and New Relic 
improved system reliability and increased uptime by 25%.

I am AWS Certified and passionate about building scalable, resilient, and secure infrastructures 
that enhance operational efficiency. I thrive in collaborative environments and enjoy working 
closely with cross-functional teams to drive continuous improvements in DevOps processes.




Project background:
1. I worked on a project for NBN, a leading telecom provider in Australia, where they faced challenges with manual infrastructure provisioning, slow deployment cycles, and inconsistent configurations, impacting scalability and reliability.

2. Task (Your Responsibilities):
As a DevOps Engineer , my responsibilities included:
1. Automating AWS infrastructure provisioning using Terraform.
2. Streamlining CI/CD pipelines to enable faster and more reliable deployments.
3. Implementing containerization for microservices using Docker and Kubernetes.
4. Enhancing monitoring and logging to proactively detect and resolve system issues.
5. Strengthening security measures by implementing AWS IAM policies and managing access controls."

3. Action (Steps You Took):
To address these challenges, I took the following actions:
1. Infrastructure Automation: Designed and implemented Terraform scripts to automate the provisioning of EC2 instances, VPCs,and S3 buckets. This reduced manual efforts by 50% and ensured consistent infrastructure setups.
2. CI/CD Implementation: Developed Jenkins pipelines for automated code integration, testing, and deployment. 
This cut release times by 40% , enabling faster delivery of features to production.
3. Containerization & Orchestration: Deployed applications in Docker containers and managed Kubernetes clusters to improve
   scalability and resilience. This allowed the applications to handle increased traffic without downtime.
4. Configuration Management: Used Ansible to automate software installations and system configurations, eliminating 90% of
   manual errors and ensuring consistency across environments.
5. Monitoring & Security: Set up Prometheus and CloudWatch for real-time monitoring, reducing downtime by 25% . I also enforced
   security best practices by managing AWS IAM roles and security groups , ensuring proper access control and compliance."
   
   
Day-to-Day Tasks:
1.Early Morning:
Check Outlook emails for any issues that need immediate attention. If any problems are identified, address them promptly.

2.Instance and Dashboard Monitoring:
Verify that all instances are operational by checking the production AWS dashboard using locally we developed using perl

3.Team Meeting:
Participate in the daily team call at 9:00 AM. Discuss any issue tickets and Jira tasks, and assign responsibilities to team members.

4.Issue Resolution:
Work on the assigned issues and tasks.

5.CI/CD Pipeline and Monitoring:
Check the health of Jenkins CI/CD pipelines.
Monitor system performance using tools like Splunk and New Relic.

6.IBM Workload Scheduler:
Monitor and ensure that jobs are triggering as expected.
Generate and send reports to the business team.

7.Task Assignment:
Work on any additional issues assigned on me.




Hello, my name is . I am having two years of experience in the capgemini.  
I am working on an internal project as a VBCS Developer. This is my second project and
in my first project i worked as a junior devops engineer for nbn client.




I worked on a project for NBN, a leading telecom provider in Australia, where they faced challenges with manual infrastructure 
provisioning, slow deployment cycles, and inconsistent configurations, impacting scalability and reliability. 
As a DevOps Engineer, I automated AWS infrastructure provisioning using Terraform, reducing manual efforts by 50%, 
and streamlined CI/CD pipelines with Jenkins, cutting deployment times by 40%. 
I containerized applications using Docker and orchestrated them with Kubernetes to improve scalability and resilience. 
Additionally, I automated configuration management with Ansible, eliminating 90% of manual errors, and enhanced monitoring using splunk and newrelic, reducing downtime by 25%. 
I also worked on security by implementing AWS IAM policies and access controls.





https://capnaoicprd-capnaop2-ia.integration.ocp.oraclecloud.com/ic/builder/rt/My_View_Dev_1_1_428/live/webApps/myviewpoc/


https://capnaoicprd-capnaop2-ia.integration.ocp.oraclecloud.com/ic/builder/rt/My_View_Dev/live/webApps/myviewpoc/


######################################################VBCS Intro#################################################
Good [morning/afternoon], and thank you for the opportunity. My name is Rajavarapu Nageswarao. I have 2.5 years of experience as an Oracle VBCS & OIC Developer, currently working at Capgemini.

In my current role, I design and develop web applications using Oracle VBCS, integrating them with external systems via OIC using REST and SOAP APIs. I’ve worked on business-critical modules like employee onboarding, transfers, and approvals, while managing backend services through OCI components like ATP, Object Storage, and Functions.

I enjoy building scalable, user-friendly UI using Oracle JET and JavaScript, and I'm comfortable working in agile environments, gathering business requirements and delivering iterative releases.

Although it's not mentioned in my resume, I’ve completed Oracle Cloud Infrastructure Foundations training and I’m currently preparing for the OIC certification to deepen my integration expertise.

I’m passionate about Oracle Cloud technologies and always looking to improve my development and integration skills.



#### HR Side Interview 30 seconds ######
Hi, I’m Rajavarapu Nageswarao. I have 2.5 years of experience as an Oracle VBCS & OIC Developer, currently working at Capgemini. I specialize in building responsive web applications using Oracle VBCS and developing integrations through OIC using REST and SOAP. I’ve worked on key modules like employee onboarding, approvals, and data dashboards. I’m also familiar with OCI services like ATP and Functions. Right now, I’m looking for opportunities where I can deepen my cloud and integration skills while contributing to impactful enterprise projects.


# Projects developed ####################
Sure. In my current role at Capgemini, I’ve been working on an internal Oracle-based application called 'My View', which is built using Oracle VBCS and Oracle Integration Cloud (OIC).

The goal of the project is to centralize and manage all employee-related data within a single cloud-based platform. This includes modules for personal information, department structures, manager approvals, onboarding, transfers, and exit processes.

One of the key components I worked on is the Time Card application, which allows employees to log their work hours. Managers can review and approve time cards through a dedicated approval workflow.

We also developed modules to track what each employee is doing — their roles, assignments, completed tasks, pending actions, and overall status. This gave management complete visibility over workforce activity and performance.

On the technical side, I built responsive UI screens using Oracle VBCS with Oracle JET, and handled dynamic data rendering through REST APIs. I also developed OIC integrations to connect VBCS with external systems like the internal HRMS and Oracle Autonomous Database (ATP).

Additionally, I configured OCI services such as Object Storage and Functions for background jobs like scheduled data syncs and automated reports.

Overall, this project helped automate HR and employee tracking workflows, ensured data consistency, and significantly reduced manual efforts.




Rest,soap,FTP,ATP 


ojs/ojpagingdataproviderview => oj/ojarraydataprovider write function this will take box page navigation links
like the buttom

another way if it's integration endpoint in the section overview transforms source it will create javascript file.
so you can edit the file. so you can setup limit of at time page reloads