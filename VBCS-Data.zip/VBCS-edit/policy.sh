mkdir iam-access-analyzer
cat << EOF > iam-access-analyzer/policy.json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "ec2:RunInstance"
            ],
            "Resource": "arn:aws:ec2:*:*:instance/my-custom-instance"
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:PutBucketPolicy"
            ],
            "Resource": "arn:aws:s3:::/my-s3-bucket"
        }
    ]
}
EOF