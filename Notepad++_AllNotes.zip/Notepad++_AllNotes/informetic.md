Install Token : k7UxoAAAACMAAAACAQAAAAEBAgAAAAzl5WbRZTBxEWllKZHnxH7NjIbnuVG7HrilcV0F_JjnlD61ANyXB0BPMea2vc8ymlc4uw==6BEeD7Ck2QHeRn72ybLrcc
https://apse1.dm-ap.informaticacloud.com/cloudUI/products/administer/main/SecureAgentDetailsWS/0130PS08000000000002/read
username: nagesrajavarapu@gmail.com
password: Nages@123


