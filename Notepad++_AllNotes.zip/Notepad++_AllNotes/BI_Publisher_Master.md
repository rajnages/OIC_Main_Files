========> TABLES SUFFIX =============================================
-> BASE TABLE AND BACKBONE OF DATA -> _B -> CORE TABLES
-> _TL -> TRANASACTION LAYER
-> _V -> VIEW WITH LANGUAGE
-> _VL -> VIEW WITH LANGUAGE
-> _ALL -> PARTITIONED TRANASACTION TABLE -> THIS TABLE SUPPORTS ALL ORGANIZATIONS
-> _H -> HEADERS TABLE
-> _L -> LINES TABLE
-> _D -> DETAILS
-> _X -> EXTENSION TABLE
-> _I -> INTERFACE TABLE
-> _GT -> GLOBAL TEMPORARY TABLE

==================================================================================================================================

=====> what are the tables you have worked with in oracle BI publisher for SCM?

==> POZ (Procurement supplier portal or supplier registration)
==> IBY (IPAYMENTS OR IBANKING)
--> HZ -> trading community
->  PON -> Procurement ONLINE NEGOTIATION

-> Supplier management:
POZ_SUPPLIERS -> MAIN SUPPLIER PROFILE INFORMATION
POZ_SUPPLIER_SITES -> SUPPLIER SITE DETAILS
HZ_PARTIES -> STORED SUPPLIER PARTY INFORMATION
HZ_LOCATIONS -> SUPPLIER ADDRESS/LOCATION
IBY_EXT_BANK_ACCOUNTS -> SUPPLIER BANK DETAILS
IBY_ACCOUNT_OWNER -> BANK ACCOUNT OWNERSHIP


-> SOURCING (RFQ,QUOTES):
PON_AUCTIONS -> SOURCING NEGOTIATIO OR RFQ HEADERS
PON_BIDDERS -> SUPPLIERS OR PARTICIPANTS INVITED TO RFQ
PON_NEGOTIATION_LINES -> LINE DETAILS FOR EACH NEGOTIATION
PON_NEGOTIATION_HEADERS -> HEADER-LEVEL
PON_SUPPLIERS -> BIDDING SUPPLIER INFORMATION
PON_RESPONSES -> BIDS OR QUOTES SUBMITTED BY Supplier

-> SUPPLY PLANNING:
MSC_SUPPLIER -> PLANNED SUPPLY LINES -> PLANNED ORDERS, PURCHASE ORDERS,WIP JOBS
MSC_DEMANDS -> DEMAND DATA -> SALES ORDERS, FORECASTS
MSC_PLANS -> PLANNING RUN RESULTS AND PLAN METADATA
MSC_ITEMS -> ITEM DEFINATIONS IN PLANNING CONTEXT
MSC_RESOURCES -> PLANNING RESOURCES LIKE WORK CENTERS


===================================================================================================================================
=> TWO TYPES FOLDER HAVE IN BI PUBLISHER
1. MY FOLDER -> THIS IS ONLY APPLICATBLE FOR WHO CREATE REPORT
2. SHARED FOLDER -> THIS IS USED OUTSIDE ORGANIZATIONS.

==> Best Practive set the data models separate folder this is shows all data models
==> Data models don't have open option only reports have the open and edit and more options
==> one Data model is we use multiple reports

# BI Publisher reports
=> .xdm -> xml data model
=> .xdo -> xml document object

=> Data Model:
-> Create -> Published Reporting Section -> Data model
-> Select properties section this will show details information for data model 
-> Time out is by default -> 300 seconds for dev/test -> 120 seconds for UAT -> 60 to 180 seconds for Prod for bulk/long running 300/600
-> in SQL developer it might take 2 to 3 minutes

====> Inside Data model we have 6 options
1. Data sets -> here we want create sql query and all those details in diagram -> sql query -> Name,Data source what module, Type of sql
                and write a query based on business requirement -> after click ok -> this will create diagram format -> you want see
				data -> view -> table view -> save data we have save sample data -> save as inside folder
				
2. Event triggers
3. flexfields
4. list of values -> write a query for this and that automatically select menu option in parameters.
5. parameters -> In BI bind parameter considerd as a parameter mention using -> (:)
6. bursting


→ in production particular team we will get a email notification

==================================================================================================================================

# ESS Job run using OIC using rest Adapter
-> https://eqjz.ds-fa.oraclepdemos.com/fscmUI/faces/FuseWelcome
-> Report path: /Custom/Nag_BIPREPORTS/INVOICES_REPORT.xdo
-> In Job Defination : Manage%Scheduler%,
   Manage Enterprise Scheduler Job Definitions and Job Sets for Financial, Supply Chain Management, and Related Applications
-> Display Name: Main Job BI report, Name: BIPReportJob, Path: /Custom/Nag_BIPREPORTS/
-> Job packagename: /oracle/apps/ess/custom/Custom/Nag_BIPREPORTS/

-> in INT: ErpIntegrationService, Services Section, operation: submitESSJobRequest
-------- Request Payload--------
{
	"ReportDefination":"BIPReportJob",
	"ReportPackage":"/oracle/apps/ess/custom/Custom/Nag_BIPREPORTS/"
}

----Response payload -------
{ 
   "RequestID":""
}

# ESS Job run using OIC using SOAP Adapter

-> SOAP WSDL : https://eqjz.ds-fa.oraclepdemos.com/fscmService/ErpIntegrationService?WSDL
-> Report package name: /oracle/apps/ess/custom/Custom/Nag_BIPREPORTS/
-> Report Defination: BIPReportJob
-> In Soap we have option called submitESSJobRequest


================================================================

-> bursting
1. bursting is a process of splitting data into blocks, generating documents for each block
   and delivering the documents to one or more destination like email,FTP,Fax,printer
2. the data for the report is generated by executing a query once and then
   splitting the data based on a key value. for each block of the data a seperate
   document is generated and delivered.
   
-> Bi Adminstration -> Manage BI Publisher -> Delivery -> FTP -> 

===================================================================

-> Event Triggers:
1. Before data Triggers
2. after data Triggers
3. scheduled Triggers


-> We can schedule in BIP console also or after created BIP report create a job defination and run the ESS Job


===================================================================================================================================================================

1. interfaces:
-> inserting the data into base tables.
-> in SAAS we don't have the customization we see the oracle seeded functionality
-> in PAAS we have the customization as we as the oracle seeded functionality.

2. Approaches of interfaces:
-> FBDI
-> ADFDI
-> Rest based web Services
-> SOA Based web Services
-> FBL -> file based load
