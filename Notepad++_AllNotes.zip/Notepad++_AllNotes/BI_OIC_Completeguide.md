# invoke BI report
# Invoke with parameters
# output file send over Email/store in FTP Server
#BIP insert into table


# Prerequisites:
-> Why use a Scheduled Integration instead of an Application Integration?
   Scheduled integrations are used to invoke BI Publisher reports in OIC Gen3 to automate periodic tasks, 
   ensure timely report generation, and reduce manual effort.

# Required Details:
-> WSDL URL: https://eqjz.ds-fa.oraclepdemos.com/xmlpserver/services/ExternalReportWSSService?WSDL
-> Path of BI Report: /Custom/Nag_OIC_Sessions/POZ_SUPPLIERS_REPORT.xdo
-> Report Format: .csv
-> Username and Password: fin_impl, nS8%Yz%7
# Steps to Create the Integration:
-> Create a SOAP Connection:
   Use the "Connections" section to create a SOAP connection. This acts like an adapter.
-> Create a Scheduled Integration:
   Design a scheduled integration to call the BI report.
-> Assign Variables:
   At the start of the integration, use the "Assign" activity to store all required parameters, such as:
   -> Report Path
   -> Report Format
   -> To Email
   -> From Email

-> Call the SOAP Connection:
   Use the SOAP adapter to call the runReport operation.
-> Mapping Section:
   Provide the required options in the mapping section. Map the following details:
   attributeFormat
   reportAbsolutePath
   sizeOfChunks
   These values should already be stored in the assigned variables.
-> Prepare Notification:
   To send a notification, prepare the required details for the notification component, such as:
    To
    From
    Subject
    Body
-> Test the Integration:
   Test the integration in ad-hoc mode.
-> Verify Email Notification:
   Ensure the email notification is sent with the report file attached.


-> Scheduled Request Types -> Ad-hoc -> Quick Response , As part of Scheduled
                           -> Another way left side 3 dots click that and Add schedule
						    here have two types 
							1. Simple -> only once, daily, hourly,weeks,months
							2. ICal -> it's like different syntax

====================================================================================================================================

# Insert BI Reports in ATP DB
-> Invoke BI Reports
   After writing a file, read another file.
   Next, call the ATP Adapter and provide the required details, such as:
    -> Invoke a stored procedure.
	-> Run an SQL statement.
    -> Perform operations.
-> Mapping Section
   In the mapping section, provide the required details, similar to how you created mappings for DB table columns.
   Be careful before running the integration:
   Check the data types for compatibility between the BI report and the table columns.
====================================================================================================================================

# Send BI Report output file over SFTP Server
-> FTP -> /home/users/radham.eswar-sai@capgemini.com/SupplierReport
-> FTP HOST -> fs-test-service-oic-axjjaskeq50w-hy.integration.ap-hyderabad-1.ocp.oraclecloud.com
-> PORT -> 10176

-> Write file operation -> Add at the last FTP Server Write a File in location

====================================================================================================================================

# Add lookup 
-> ones create the lookup that values calls using Assign variables so using functions lookup drag and drop the lookup

===================================================================================================================================
# how to access inside scope value outside
-> Local Variables
-> Global Variables
-> input Variables
-> output Variables
-> Scope Variables

=================================================================================================================================

# invoke BI report with parameter using OIC
-> path : /Custom/Nag_OIC_Sessions/OICParamsReport.xdo
-> WSDL -> https://fa-exgr-saasfademo1.ds-fa.oraclepdemos.com/xmlpserver/services/ExternalReportWSSService?WSDL
-> JSON Request Payload
=================================================================================================================================

# Bursting
-> it is used to process of generating and delivering a single report to multiple recipents each receiving a personalizes version of
   report based on specific data criteria.
-> it allows you to split a report into multiple parts and deliver each part to different destinations such as email, prints,file Server
   or content management systems
-> Bursting control file in XML

-> in BI Publisher profile -> Adminstration section -> Delivery -> we have options email,FTP,Content Server -> System maintenance
   Upload Server

-> BUSINESS_RELATIONSHIP this is important this is showing as a -> spend_authorized,prospective


# RunReport and Scheduled reports
-> RunReport is to generate amd view reports immediately in real timely -> live data
-> scheduled reports to automate the generation and delivery of reports at specified intervals


https://fa-exgr-saasfademo1.ds-fa.oraclepdemos.com/hcmRestApi/resources/11.13.18.05/emps

