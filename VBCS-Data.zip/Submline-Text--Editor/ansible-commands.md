1. ansible -i invfile pvt -m shell -a "df -h /root" -vv
-> after invfile we can mention anything like pvt,pub,all
-> conditions also works like server01:server02, pub:!server03
2. ansible -i invfile server01 -m setup | grep -i Distribution => this will showing all client info using ansible controller
-> this is called gather facts
3. become in yaml file => means go and install or tasks become root mode not admin mode
4. apt vs shell:
apt = For software installation tasks.
shell = For everything else you can’t do with Ansible's modules.
5. debug: 
The debug module is like a "print" statement in programming. It helps you see what's going on inside your playbook
6. no_log=true: The no_log: true directive in Ansible is used to hide sensitive information from being printed in the logs or output
## Which Modules Are Most Commonly Used in Real-Time:
In real-time environments, especially for DevOps, IT automation, and cloud infrastructure management, the most commonly used modules are:

apt, yum, dnf for package management (to install software like Nginx, MySQL, etc.).
service and systemd for service management (starting, stopping, and managing services).
copy and template,remote for managing files and configuration.
git for managing code repositories.
command and shell for executing arbitrary commands.
ec2, azure_rm_*, and gcloud for managing cloud infrastructure.
mysql_db, postgresql_db for managing databases.
slack, email for notifications.
cron for scheduling tasks.

## In Ansible, with_items is used to repeat the same task for each item in a list. It helps to perform a task multiple times without writing the same thing over and over again

## In Ansible (and in general command-line operations), rc stands for Return Code or Exit Code. It indicates the outcome of a command that was executed.
-> If rc = 0, no need to proceed with installation.
-> If rc ≠ 0, run tasks to fix the issue or install missing software.
-> Conditional Execution:
You can use the return code in when conditions to control what tasks should run next.

# ignore_errors
# register is using storing value of variable
# handler and notify 
- In Ansible, handlers and notify are used together to perform actions only when something changes during the playbook execution.
# Handler
- A handler is a special type of task that gets triggered only when it is explicitly notified. Handlers are typically used for actions like restarting services.

# Notify
- The notify directive is used to tell Ansible to run a specific handler after the current task has been completed, but only if the task results in a change.

#### main example of handler and notify
- Think of it like this:
- Imagine you have a machine, and you make a change (like updating a file). After that change, you want to restart a service and back up the file. The notify tells Ansible, "Hey, if you made any change, then go ahead and restart Redis and back up the file!"


# The build-essential package in Linux provides a collection of tools and libraries essential for compiling and building software from source code.
# Common Tools in build-essential:
gcc: A compiler for C and C++ programming languages.
make: A build automation tool that runs tasks defined in a Makefile.
libc6-dev: Development files for the GNU C library, needed for compiling many programs.
Other Supporting Tools: Utilities for building and linking software.

# tcl (Tool Command Language) is a scripting language often used for rapid prototyping, scripted applications, and embedded systems. When installing or compiling certain software (like Redis), tcl is sometimes required because it's used during the testing phase or for specific scripts.

# What is get_url in simple words?
get_url in Ansible is used to download files from the internet to your target machine. For example, if you need to get a software installer or any file from a website, you can use get_url to do it.
- Think of it like this:
If you want to download a file manually using your browser, get_url does the same thing but automatically through Ansible.

# Key Differences:
- shell: Allows advanced shell features like piping (|), redirection (>), and running complex shell commands.
         The shell module lets you run shell commands on the remote server.

- command: Simpler, no shell features; just runs the command as it is.
		   The command module is used to run commands without using the shell (no shell features like piping or redirection).

- raw: Bypasses Ansible's normal handling; runs commands directly without extra processing.
	   The raw module is used to run commands directly on the remote system without any special handling.



#### ansible vault
- Ansible Vault is a feature in Ansible that helps you keep sensitive data, such as passwords, API keys, and certificates, secure

# commands of vault
1. ansible-vault create aws_creds
2. ansible-vault encrypt aws_creds
3. ansible-vault decrypt aws_creds

# block and resucue and always
- Summary:
- block: Groups multiple tasks together.
- rescue: Defines error-handling tasks that run if any task in the block fails (like a "catch" block).
- always: Defines tasks that should always run, regardless of success or failure of the block tasks (like a "finally" block).


# ansible-config init --disabled > ansible.cfg => this will generate ansible.cfg main file