PageModule.prototype.testing = function (qualification) {
    let empty = '';
    if (qualification == 'DE') {
      empty = "activeFlag='Y' AND (globalPractice = 180 OR pSCQualified = 'No' OR capabilityQualified = 'No')";
    }
    if (qualification == 'PSC') {
      empty = `activeFlag='Y' AND pSCQualified = 'No'`;
    }
    if (qualification == 'Cap') {
      empty = `activeFlag='Y' AND capabilityQualified = 'No'`;
    }
    return empty;

  };



//   <!--
//             style="border: 1px solid #ced4da; border-radius: 6px; padding: 8px; background-color: white; box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);"
//             -->

<!-- Demand ID Label and Input -->
<div style="display: flex; flex-direction: column; min-width: 160px;">
  <label style="font-size: 14px; color: #333; margin-bottom: 6px; text-align: center; letter-spacing: 1px;">Demand ID</label>
  <div class="oj-flex">
    <oj-input-text value="{{ $variables.searchButton.DemandID }}" class="">
    </oj-input-text>
  </div>
</div>
