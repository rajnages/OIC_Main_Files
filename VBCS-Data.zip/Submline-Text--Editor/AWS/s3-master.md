-> s3:
Amazon S3, or Simple Storage Service, is a cloud storage service by AWS. It stores data like files, images, and backups in a secure way. Data is kept in 'buckets,' and each file has a unique name. It is scalable, meaning it can handle large amounts of data, and very reliable, with almost no chance of losing data. S3 is used for backups, website files, and storing data for apps.

-> share predefined url => it accessed by hours only
-> s3fs -> s3fs is a FUSE (Filesystem in Userspace) implementation that allows you to mount an Amazon S3 bucket as a local file system on your system
-> access points => Amazon S3 Access Points make it easier to manage and control access to your S3 bucket. Instead of using one big policy for the whole bucket, you can create separate "access points" with different permissions for different use cases.

===================================================================================================================

# SSM (systems manager):
AWS Systems Manager (SSM) is a service that helps you manage and automate tasks on your Amazon Web Services (AWS) resources, such as EC2 instances, on-premises servers, and virtual machines.

1. ec2 systems manager
2. automation
3. run command
4. parameter store
5. session manager
6. patch manager
7. inventory
8. compliance
9. state manager

# In real-time environments, Run Command, Session Manager, Patch Manager, and Parameter Store are the most commonly used SSM components because they simplify management, enhance security, and automate tasks on AWS resources.

# Key Differences Summarized:
1. User Data is for initial configuration at the time of instance launch and runs once during the first boot.
2. SSM Run Command allows you to run commands at any time on running instances, even after the instance has been launched, and can be executed multiple times.

package name => AmazonCloudWatchAgent --> path : cd /opt/aws/agent/bin

1. run command => Executes shell scripts or commands on an instance, even if the instance is already running.
2. session manager => Provides secure, browser-based or CLI access to an instance without requiring SSH keys or opening port 22.
3. state manager => Automatically runs specific scripts or configurations on instances at scheduled intervals. 


# Real-Time Example:
1. AWS Environment: Use SSM to patch and maintain EC2 instances, manage configurations via State Manager, and secure access with Session Manager.
2. Hybrid Environment: Use Ansible to provision and configure servers in AWS, on-premises, and other clouds in a unified manner.

/var/log/nginx/access.log
/var/log/nginx/error.log

[/var/log/nginx/error.log]
log_group_name = nginx-error-log
log_stream_name = {instance_id}/error.log
file = /var/log/nginx/error.log

[/var/log/nginx/access.log]
log_group_name = nginx-access-log
log_stream_name = {instance_id}/access.log
file = /var/log/nginx/access.log



# CloudWatch:
- Purpose: Monitors AWS resources and shows performance (like CPU or memory usage).
- Use: Sets alarms when something goes wrong and collects logs.

# EventBridge:
- Purpose: Handles events and triggers actions automatically.
- Use: Sends events from services (like S3 or EC2) and starts tasks (e.g., triggering Lambda).

# Key Difference:
- CloudWatch is for monitoring.
- EventBridge is for automating tasks based on events.

===========================================================================================================================

# Developer tools:

1. code commit
2. cloud9
3. cloudbuild
4. code deploy
5. code pipeline

tar -xzvf /tmp/tomcat-10.tar.gz --strip-components=1 -C /opt/tomcat
vi /etc/systemd/system/tomcat.service


Summary:
CloudWatch: Monitors performance.
EventBridge: Automates tasks based on events.
CloudTrail: Logs API activity for security and auditing.
Config: Tracks resource configuration changes.