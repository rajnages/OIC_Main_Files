############################################# Oracle APEX Developer Professional ###############################################################

-> Oracle apex is low-code development  platform provided by oracle to build web-based applications that runs on oracle database.
   it is used mostly data driven application that used sql and plsql
   
# classic report and interactive report
-> classic report is a read only like end user can not edit or create just read only if anything extra functionlity we need set
   extra code
-> interactive report advanced capabilities we can do anything here

# Private views?
-> private views are system generated database views that are specific apex workspace or application

# components?
-> Pages, Regions, Items, Processes, Shared compoenents

# Regions
-> it is like a container on a page that holds UI elements like reports and charts or html content

# collection?
-> collection is a temporary in-memory table used to store and manipulate data across mutliple pages or sessions.

# page zero?
-> page zero is a global page across whose compoenents like navigation or buttons appears on all pages of the application.


# Three panels are showing in the console
-> Left side panel -> Page Components tree -> page rendering, components, post rendering
-> middle plane -> layout editor -> canvas
-> right plane -> Property editor.

# Rendering meant
-> Rendering means displaying something on the screen for the user.
-> it is the process where apex takes your page defination like regions, buttons, charts and generates HTML,CSS and Javascript so that the browser can show it.

# About Applications
An application is a collection of pages linked together using navigation menus, tabs, buttons, or hypertext links. 
Application pages share a common session state and authentication.

To create an application, a developer runs the Create Application Wizard to declaratively assemble pages and navigation. 
Individual pages are organized using containers called regions. Regions can contain text, custom PL/SQL, reports, charts, maps, calendars, web service content, or forms. 
Forms are made up of fields (called items) which can be selected from the multitude of built-in types (such as text fields, text areas, radio groups, select lists, 
checkboxes, date pickers, and popup list of values).

Developers can also create their own custom item types using plug-ins. 
Session state (or application context) is transparently managed and the user interface presentation is separated from the application logic enabling developers 
to manage the look and feel of an application by simply selecting a different theme.

# About Application Pages
A page is the basic building block of an application. 
Every application consists of one or multiple pages. 
Each page can have buttons and fields (called items) which are grouped into containers called regions. 
Pages can include application logic (or processes). You can branch from one page to the next using conditional navigation; 
perform calculations (called computations); perform validations (such as edit checks); 
and display reports, calendars, and charts. You view and edit a page in Page Designer.
==================================================================================================================================================================

# Understanding Page Rendering and Page Processing
-> Page rendering -> Show page -> front end page showing actual and starting the page: 
   before header
   after header
   before Region
-> Page Processing -> Accept page -> This is another process and update and create of the details

# understanding computations:
-> computations is a logic that assigns values  to a single Item
-> Page computations -> Page level
-> Application computations -> Application level -> under share components -> Application logic

# Understanding Page Processes:
a page process is a specific event that runs when a page is loaded or submitted

# invoke API process type:
-> Process to invoke a procedure or function stored in the local database or an operation defined in a rest data source
-> foreground -> a task or process that runs actively and interacts with the user
-> background -> A task or process that runs behind the scenes without user interaction.

# background Page Processing
-> Instance level -> Default
-> workspace level
-> Application level

# Understanding Validations:
-> 
# Understanding Validations and branches

# branches is the navigations or redirection of Pages

------- flowing one application ----------------------------
-> Application -> Pages -> inside pages we have all 
-> Pre Rendering -> Before header, after header, Before Regions
-> components -> Breadcumb bar -> Body
-> Post rendoring -> After Regions, Before Footer, After Footer
-> Inside body we have button like inside region -> Button actions -> insert,update,delete
-> events -> Page load, Change, Click, Dialog Closed -> Here only avaliable dynamic action


# Dynamic Actions:
-> Dynamic Actions provide a way to define complex client-side bahaviour declaratively without the need for javascript.
   => when the action happen with optional conditions
   => what action or actions are performed
   => what elements are affected by action
-> Browser events
-> framework events
-> component events
-> custom events


=====================================================================================================================================================================


