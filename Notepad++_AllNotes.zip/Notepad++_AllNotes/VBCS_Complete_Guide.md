# What is vbcs 
-> vbcs is a low-code development platform for building web and mobile application quickly with drag and drop feature 
   without much knowledge on coding
   

# what is BO
-> BO is built in database for storing structure data for applications it's like a tempraroy database.

# Service connection
-> service connections is used to communicated with external rest api's/services like erp cloud, oic
-> When you need to integrate with a specific external service without additional security layers.

# Authentication methods:
-> Basic Authentication
-> Oracle cloud Account
-> OAuth 2.0 client credentials
-> OAuth 2.0 resource owner password credentials
-> OAuth 2.0 User Assertion

# Backend connection:
-> backend is group of service connections additionally provide security controls.
-> When multiple service connections need to be managed under a single security framework.

# what are action chains
-> action chains is a series of actions that are triggered by user response. like button clicks page reload

# Event lister and events
-> event lister is like watchers that wait for specific action or event to happen on the page such as a button click, 
   page load.
   When the event occurs, the listener triggers a response, usually an action chain.

# Events:
-> An event is something that happens in the application like a user clicking the button and entering text
   VBEnter,VBExit,VBNotification,VBBeforeexit, VBAfterNavigate

# Data Providers
-> SDP is connecting to external rest apis usually service connections or BO rest endpoints.
-> ADP is custom data validations and manipulation inside vbcs application.
-> BDP is used to temporily store and manipulate data in memory during the app session.
   Two Sections: Data Provider, Options
   usually Data provider is SDP, ADP because bydefault BDP is not Provider
   Options is advanced capabiilities
-> MSDP is multi service data provider is combine data from multiple rest services into a single data Provider.

# Business object rules:
object trigger -> Executes when a record (object) is created or updated.
object validator -> Validates the entire object before saving.
field trigger ->  Executes logic when a specific field is changed.
field validator -> Validates a specific field when it is changed.
object functions -> Custom logic written in Groovy script (or similar scripting language). used for complex calcualtions

# How to connect Rest api bo endpoints outside world
-> Using Rest Api's endpoint like we have two sets like metadata and data
-> main endpoints is data section we can take development or live or stage endpoints and configure the required
-> BO -> Section of Endpoints -> We have option called Resource API's -> It will give the rest api endpoints
-> for testing purpose take that endpoint i will test using postman required credentils

# Service connections
-> define catalog -> by defauly oic erp applications
-> define specification -> it supports OpenAPI (Swagger) or WSDL file. to upload document it will automatically populate details
-> define endpoints -> Used when you want to manually define the REST or SOAP endpoints.


# Actions in action chains
-> call rest, assign variables, call function, Call action chain, Call variable, Js code, Fire notification, reset variables.

# UI components:
-> Forms,tables,dynamic form,dynamic table, select single, select many, combobox one, combobox many.Charts (area chart,pie charts,bar chart)
   dialog box, progressbar, 
   
# Application Profiles, user roles in application settings.
-> Application profiles is used to set the environments
-> user roles is used BO level and security purpose

# input date -> min max -> ojs/dateconveter -> new Date function in javascript function is will give current date and time
  get day,getfullyear,getMonth then we can filter required 
# input number -> fraction sets -> or custom javascript functions -> ojs/ojnumberconveter,Intlnumberconveter
# data binding -> store variables and manipulate the required info

# what is types:
-> types is data structures typically it's like blue print for data

# what is use of json
-> this is store application realted metadata

# variables:
-> page level -> it is accessible inside flow current page
-> application level -> all parts of application and it's current page
-> flow level -> is it accessible current flow
-> action chain level -> it is used in action chain variables

# Page Flow:
 -> Page Flow is in vbcs is the logical sequence or navigation path that defines how users move b/w different pages
    like main edit create update delete

# Versioning in VBCS
-> Versioning in Oracle Visual Builder Cloud Service (VBCS) allows developers 
   to create new versions of an application without affecting the main version.
-> In the application interface, click the three dots on the right side. 
   Select "New Version" to create a new version under the parent version.
   If the starting version is 1.0, the new version will be 1.0.1, ensuring changes do not impact the main version.
 
# what are the stages in vbcs
-> Development, stage, Live 
   stage => Used for testing and validation before making an application live => here we can do anything like edit and more
   Live => The final production version of the application => this is comes read only we can't edit

# Oracle JET
1. Oracle JET is a modular javascript framework designed for building enterprise -level applications.
2. Architecture => MVVM (model view - viewModel)

view(UI layer) -> Represents the frontend of the application => Uses HTML, CSS, and Oracle JET components to define the user interface.
model(Data layer)  -> Handles data access and storage -> Uses JavaScript, REST API calls, and local storage to fetch and manage data.
viewModel(Logic Layer) -> Manages view logic and user interactions => Uses JavaScript, event handlers, and data references to connect the View and Model.

=> Method: a method refers to a function that is exposed by a Oracle JET component

### javascript

-> Map : method is used for creating new array for existing one.
-> filter : The filter() method takes each element in an array and it applies a conditional statement against it. 
          If this conditional returns true, the element gets pushed to the output array. 
          If the condition returns false, the element does not get pushed to the output array
-> find: This method returns first element of the array that satisfies the condition specified in the callback function.
-> reduce : The reduce() method reduces an array of values down to just one value
-> this: in global functions this refers to the global object
         in methods if refers to the object
		 in arrow functions this retains the value from the parent scope
-> == -> compares values with type coercion
-> === -> compares both value and type (strict equality)
-> var -> function scoped, let  and const is block scoped
-> Promises handle asynchronous operations

=====================================================================================================================================================
-> Add ons in excel for oracle visual builder:
website -> customer connect

https://eqjz.ds-fa.oraclepdemos.com/fscmRestApi/resources/11.13.18.05/purchaseRequisitions