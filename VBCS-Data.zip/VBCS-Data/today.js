PageModule.prototype.testing = function (qualification, demandid) {
    console.log('-------------------------------------------------', qualification);
    console.log('-------------------------------------', demandid);

    let empty = '';


    // if (demandid && !qualification) {
    //   empty = `activeFlag='Y' AND teamRequestNumber = ${demandid}`;
    // }

    // if ((qualification != undefined && qualification != '') && (demandid != undefined && demandid != '')) {
    //   if (qualification == 'DE') {
    //     empty = `activeFlag='Y' AND globalPractice = 180 AND teamRequestNumber = ${demandid}`;
    //   }
    //   if (qualification == 'PSC') {
    //     empty = `activeFlag='Y' AND pSCQualified = 'No' AND teamRequestNumber = ${demandid}`;
    //   }
    //   if (qualification == 'Cap') {
    //     empty = `activeFlag='Y' AND capabilityQualified = 'No' AND teamRequestNumber = ${demandid}`;
    //   }

    // }

    // if ((qualification != undefined && qualification != '') && (demandid == undefined || demandid == '' || demandid == null)) {
    //   if (qualification == 'DE') {
    //     empty = `activeFlag='Y' AND globalPractice = 180`;
    //   }
    //   if (qualification == 'PSC') {
    //     empty = `activeFlag='Y' AND pSCQualified = 'No'`;
    //   }
    //   if (qualification == 'Cap') {
    //     empty = `activeFlag='Y' AND capabilityQualified = 'No'`;
    //   }

    // }






    if (qualification) {
      if (demandid) {
        if (qualification == 'DE') {
          empty = `activeFlag='Y' AND globalPractice = 180 AND teamRequestNumber = ${demandid}`;
        }
        if (qualification == 'PSC') {
          empty = `activeFlag='Y' AND pSCQualified = 'No' AND teamRequestNumber = ${demandid}`;
        }
        if (qualification == 'Cap') {
          empty = `activeFlag='Y' AND capabilityQualified = 'No' AND teamRequestNumber = ${demandid}`;
        }
      }
      else {
        if (qualification == 'DE') {
          empty = `activeFlag='Y' AND globalPractice = 180`;
        }
        if (qualification == 'PSC') {
          empty = `activeFlag='Y' AND pSCQualified = 'No'`;
        }
        if (qualification == 'Cap') {
          empty = `activeFlag='Y' AND capabilityQualified = 'No'`;
        }

      }
    }
    else {
      empty = `activeFlag='Y' AND teamRequestNumber = ${demandid}`;

    }










    return empty;

  };