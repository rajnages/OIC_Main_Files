# lambda intro
1. AWS Lambda is a serverless compute service that lets you run your code without provisioning or managing servers. You simply upload your code, and Lambda automatically runs it in response to specific events, like changes in data, HTTP requests, or file uploads.

2. You don’t need to worry about scaling or server management because Lambda automatically handles both based on the number of requests. It’s ideal for running small tasks like data processing, automating workflows, or handling API calls.

3. In short, Lambda is event-driven, cost-effective (you pay only for the compute time used), and scalable, making it a great solution for microservices or short-lived tasks

# AWS Lambda can interact with the outside world in several ways, depending on the use case. Here are the main methods:

1. API Gateway:
   You can expose Lambda functions to the outside world as APIs using Amazon API Gateway. It allows you to create RESTful or HTTP APIs, which can trigger Lambda in response to HTTP requests from external users or applications.

2. AWS SDK and External APIs:
   Lambda can use the AWS SDK to interact with other AWS services or make HTTP requests to external APIs. For example, Lambda can call third-party APIs using libraries like requests in Python or https in Node.js.

3. SNS (Simple Notification Service):
   Lambda can be triggered by messages sent to an SNS topic. External systems or applications can publish messages to an SNS topic, which then invokes the Lambda function.

4. S3 Events:
   Lambda can be triggered by S3 events. For instance, when a file is uploaded to an S3 bucket, it can automatically trigger a Lambda function for processing that file.

5. EventBridge:
   You can use AWS EventBridge (formerly CloudWatch Events) to trigger Lambda based on events from external sources or AWS services, such as scheduled tasks or custom events from applications.

6. VPC Integration:
   Lambda can access resources within a VPC (Virtual Private Cloud), such as private databases or EC2 instances. This allows Lambda to securely interact with internal services that are not publicly accessible.



# difference between lambda function vs lambda service?
1. lambda function:
    your function defination that will be initialized and called by the lambda service
2. lambda service:
   handles initializing and calling lambda functions as well as handling inputs and outputs


# In short:
1. Synchronous = Wait for the function to finish and get a result.
2. Asynchronous = Function runs in the background, and you don’t wait for a resul

# runtime:
- a runtime is the environment that allows AWS Lambda to execute your code in a specific programming language.
# runtime depreciation:
- runtime deprecation is when AWS stops supporting older versions of runtimes, and you must upgrade to avoid potential issues.

# limits:
- 1,000 functions per region by default.
- 1,000 concurrent executions per region by default.
- No specific limit on the number of functions per Availability Zone (Lambda scales automatically).

# lambda handler:
- The Lambda handler is the main function AWS Lambda calls when your code runs. It processes input events, executes your logic, and returns a result.
1. event object
2. context object
3. returing value

- invocation in AWS Lambda refers to calling or triggering the Lambda function in response to an event, and the Lambda function processes that event accordingly.

- What is the maximum execution timeout for an AWS Lambda function?
Expected Answer: The maximum execution timeout for a Lambda function is 15 minutes (900 seconds).


=====================================================================================================================

# api gateway:
1. AWS API Gateway is a fully managed service that allows you to create, publish, monitor, and secure APIs at any scale. It acts as a bridge between client applications (like web or mobile apps) and backend services (such as AWS Lambda functions, EC2 instances, or other HTTP endpoints).

2. It supports multiple API types, including REST APIs, WebSocket APIs, and HTTP APIs. API Gateway is scalable, meaning it automatically adjusts to handle varying levels of traffic, and it also integrates with AWS services like Lambda, S3, and DynamoDB.

3. Additionally, it offers features like request throttling, caching, security (with authentication via IAM, API keys, or AWS Cognito), and detailed monitoring through Amazon CloudWatch. This makes it a powerful tool for building serverless applications and APIs that are highly available and cost-effective


# lambda proxy:
- Lambda Proxy is a feature in AWS API Gateway that allows you to send all the details of an HTTP request (like headers, query parameters, and body) directly to a Lambda function. The Lambda function then processes the request and sends back a response in a specific format, which API Gateway uses to send the result back to the client.

# execution life cycle:
  The execution lifecycle of AWS Lambda explains how a Lambda function works from start to finish:
- Creation:
  You create a Lambda function with code, settings, and triggers.

- Trigger:
  The function runs when something happens, like an API call, file upload to S3, or a scheduled event.

- Initialization (Cold Start):
  When the function runs for the first time or after a long break, AWS sets up a container for it.  
  It loads the code and runtime environment.
  This step can take a little extra time.

- Execution:
- The function processes the event using your code.
- It returns a response when done.

Idle (Warm Start):
- After running, the container stays ready for a while.
- If another request comes quickly, it skips the setup (faster response).

Termination:
- If the container stays idle for too long, AWS shuts it down.
- Everything resets.

# snapstart:
- SnapStart is a feature in AWS Lambda that helps reduce cold start latency. When you deploy a Lambda function, SnapStart initializes the runtime environment, code, and dependencies once and takes a snapshot of the initialized state. For subsequent invocations, this snapshot is quickly restored instead of setting everything up from scratch.
- This makes the function start faster, especially useful for Java-based Lambda functions and latency-sensitive workloads

====================================================================================================================


# step functions:
AWS Step Functions is a service that helps you automate workflows by linking multiple AWS services together. It breaks down a task into smaller steps, which can run in order or parallel. Step Functions takes care of the flow, retries, and error handling.

Example:
For example, in an order processing system:

Step 1: Check inventory
Step 2: Process payment
Step 3: Ship product

==================================================================================================================

# dynamodb:
- Amazon DynamoDB is a fully managed NoSQL database service from AWS. It’s serverless, meaning you don’t need to manage any servers, and it automatically handles scaling to match your application's traffic.

# Where It’s Used:
- Shopping apps to store product and order information.
- Gaming apps to track player scores.
- Websites to manage user sessions or real-time data.