username: john.dunbar
username: fin_impl,hcm_impl,scm_impl

# What is VBS
=> vbs is cloud based development platform designed to help developer build,test,deploy application with ease.
   it provides a low code enviroment that allows users to create web and mobile application with drag and drop features. 
   
# Components
=> Orgnization -> Top level container
=> Projects => Projects exist within an organization
   -> A project is a unit of work that typically different of Components
   -> git, build jobs, deployment configuration, issue tracking, workspaces, environments, wiki or documentation
  
=================================================================================================================================================

# In oracle fusion application -> configuration -> Sandboxes:
1. Avalible Sandboxes, Published, Deleted
2. Tools:
   -> Application composer
   -> Apperance
   -> structure
   -> user interface text
   -> lookups
   -> flexfields
   -> configure business objects
   -> Page integration
   -> Page composer
   -> Page Template composer

# Application composer:
=> Application composer is a design time at runtime tool, which means that you can navigate to application composer directly 
   from any application, make your changes, and see most changes take immediate effect in real time without having to
   sign in and sign out and sign back in.
   
   Note: Roles for Application Composer:
			ORA_ASM_APPLICATION_IMPLEMENTATION_CONSULTANT_JOB
		 Custom Object Access:
			ORA_CRM_EXTN_ROLE
			ORA_HZ_RESOURCE_ABSTRACT
		 Run below job - after adding the Roles
			Import user and role application security data
			
	Custom Api object -> Table Details
	Main Table =---> MOT_REF_ENTITIES
		 
1. Application Composer => Supports CRM,SCM,ERP
   HCM => HCM Experience Design studio
   
2. Objects => Custom Objects, standared objects
   => custom objects (user-defined business objects ):
				-> fields => Fields are data elements within your custom object — like columns in a database table.
							 To store specific pieces of information.
				-> pages => Pages define the user interface for interacting with your custom object.
				-> Actions and links => These are custom buttons or links that perform specific actions on your object.
				-> security => Security controls who can see or do what with your custom object.
				-> server scripts  => These are custom business logic scripts written in Groovy that run on the server.	
				
3. Pages => Landing Page Layouts -> This is the main list view that users see when they open the object (standard or custom).
                                    Table of Site Visits
									
            creation Page Layouts -> This is the form users fill out when creating a new record.
									 New Visit form
									 
			Details Page Layouts -> This is the view/edit page for a single record.
									Visit details + actions
									
			Reuseable Regions ->  These are modular UI components that you can create once and reuse across multiple pages or objects.
								  Audit Info section
								  
==================================================================================================================================

# Application Development in VBS
1. first Add Dependecies for development
2. Sales and Services -> countryCodes, accounts
# Key Modules Under Sales and Service
# Sales Modules
   => Oracle Sales: Core CRM for managing leads, opportunities, and accounts.
   => Sales Planning: Territory and quota management.
   => Sales Performance Management: Incentive compensation and performance tracking.
   => Partner Relationship Management: Manage indirect sales channels and partners.
   => Customer Data Management (CDM): Centralized customer data repository.
# Service Modules
   => Oracle B2B Service: Manage service requests and customer interactions.
   => Oracle B2C Service: Omnichannel support for consumer-facing businesses.
   => Field Service: Manage mobile workforce and field operations.
   => Knowledge Management: Centralized knowledge base for agents and customers.
   => Digital Customer Service: Self-service portals, chatbots, and digital engagement.
   
########################################################################################################################################

# Application Extension
=> in VBS extension refers to a customization or enhancement build on top existing fusion applications using low-code 
   development.
   
# Sandboxes:
-> it is a isolated environment to make customizations or extensions to the application without affecting live version.

# Difference between extensions and application composer?
-> Application composer supports only -> Supports CRM,SCM,ERP.
-> VBS suuports all modules for oracle cloud applications customizations.