#!/bin/bash

# Define variables
ROLE=$1  # Accepts "master" or "agent"
MASTER_HOSTNAME="puppet-master"  # Replace with your Puppet master hostname
AGENT_HOSTNAME=$(hostname)       # Automatically detect agent hostname
MASTER_IP="192.168.1.10"          # Replace with your Puppet master IP address

# Function to install Puppet Server (Master)
install_puppet_master() {
    echo "Installing Puppet Server (Master)..."

    # Update system
    sudo apt update && sudo apt upgrade -y

    # Add Puppet repository
    wget https://apt.puppet.com/puppet7-release-focal.deb
    sudo dpkg -i puppet7-release-focal.deb
    sudo apt update

    # Install Puppet Server
    sudo apt install puppetserver -y

    # Configure memory allocation (optional, adjust as needed)
    sudo sed -i 's/-Xms2g -Xmx2g/-Xms1g -Xmx1g/' /etc/default/puppetserver

    # Start and enable Puppet Server
    sudo systemctl start puppetserver
    sudo systemctl enable puppetserver

    # Open firewall port
    sudo ufw allow 8140/tcp

    # Verify Puppet Server status
    sudo systemctl status puppetserver --no-pager
}

# Function to install Puppet Agent
install_puppet_agent() {
    echo "Installing Puppet Agent..."

    # Update system
    sudo apt update && sudo apt upgrade -y

    # Add Puppet repository
    wget https://apt.puppet.com/puppet7-release-focal.deb
    sudo dpkg -i puppet7-release-focal.deb
    sudo apt update

    # Install Puppet Agent
    sudo apt install puppet-agent -y

    # Configure Puppet Agent
    sudo tee /etc/puppetlabs/puppet/puppet.conf > /dev/null <<EOF
[main]
server = $MASTER_HOSTNAME
certname = $AGENT_HOSTNAME
environment = production
runinterval = 30m
EOF

    # Start and enable Puppet Agent
    sudo systemctl start puppet
    sudo systemctl enable puppet

    # Trigger a manual Puppet run
    sudo /opt/puppetlabs/bin/puppet agent --test
}

# Main logic
if [[ "$ROLE" == "master" ]]; then
    install_puppet_master
elif [[ "$ROLE" == "agent" ]]; then
    install_puppet_agent
else
    echo "Usage: $0 {master|agent}"
    exit 1
fi