const sample = {
	"name":"john",
	"age":23
}

console.log(sample)