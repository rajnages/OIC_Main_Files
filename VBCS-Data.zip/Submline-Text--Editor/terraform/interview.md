# Q1. What is Terraform, and how is it different from other Infrastructure-as-Code (IaC) tools like Ansible or CloudFormation?

Answer:
- Terraform is an open-source IaC tool by HashiCorp that allows declarative configuration to provision and manage infrastructure.
- Unlike Ansible, Terraform is declarative and focuses on infrastructure provisioning, while Ansible is procedural and better suited for configuration management.
- Compared to CloudFormation, Terraform is cloud-agnostic, supporting multiple providers like AWS, Azure, GCP, and more, whereas CloudFormation is AWS-specific.

# What are Terraform providers, and how do they work?
Answer:
- Terraform providers act as plugins that interact with cloud platforms, SaaS providers, or other APIs.
- Providers define the resources Terraform can manage, such as aws_instance or azure_storage_account.

# What are the key components of a Terraform configuration file?
Answer:
Providers: Define cloud platforms (e.g., AWS, GCP).
Resources: Represent infrastructure components (e.g., EC2, S3).
Variables: Input values for configurations.
Outputs: Return data after execution.
Modules: Reusable configurations for scalability.

# Explain the difference between terraform apply and terraform plan.
Answer:
terraform plan: Generates and displays an execution plan, showing what actions will occur.
terraform apply: Executes the actions proposed in the plan to modify infrastructure.

# What are the advantages of using remote backends in Terraform?
Answer:
Enables collaboration by storing the state file remotely.
Provides state locking to prevent concurrent modifications.

# What is the difference between count and for_each in Terraform?
Answer:
count: Creates multiple instances based on a numeric value.
for_each: Iterates over a map or set for finer control.

#  Explain the concept of "drift" in Terraform. How do you detect and resolve it?
Answer:
Drift occurs when the actual infrastructure state differs from the Terraform configuration.
Detect drift: Use terraform plan to see changes.
Resolve: Update the configuration or infrastructure, then run terraform apply.

# What Are Dynamic Blocks?
In Terraform, dynamic blocks provide a way to dynamically generate repeated nested blocks within resource, data, provider, and provisioner blocks. They're commonly used in resource blocks to make your configurations more flexible and follow the "Don't Repeat Yourself" (DRY) principle.

# What are Modules in Terraform?
In Terraform, a module is a container for multiple resources that are used together. A module can be thought of as a reusable blueprint for deploying infrastructure

Modules can include:
Root Module: The primary working directory with Terraform configuration files (.tf files).
Child Modules: Reusable modules that can be called by the root module or other modules.

#  State Management and Troubleshooting
Q16. How do you manage Terraform state files in a team environment?
Answer:
Use remote backends (e.g., S3, Azure Blob) to centralize state files and enable locking using DynamoDB or Consul.

#  Have you ever faced corruption in the Terraform state file? How did you recover from it?
Answer:
Backup: Always keep backups of state files.
Recovery: Use a backup to restore or manually edit the JSON file if corruption is minor.

# How do you handle encryption of Terraform state files?
Use remote backends with server-side encryption enabled. For example, encrypt S3 state files using

# How do you securely pass credentials to Terraform in a CI/CD pipeline?
Use environment variables: Store secrets in tools like AWS Secrets Manager or Azure Key Vault.
Inject them securely into the pipeline:

# What steps do you take when terraform plan or apply fails due to a resource conflict?
When a Terraform plan or apply fails due to a resource conflict, the primary steps to take are: analyze the error message to identify the conflicting resources, manually adjust your Terraform configuration to resolve the conflict by either changing resource names, attributes, or dependencies using "depends_on" blocks, and then re-run the "terraform plan" to verify the issue is fixed before applying the changes; if needed, you can also manually update the Terraform state file to reflect the existing infrastructure if the conflict is due to a state inconsistency.

# What is the terraform refresh command, and when should you use it?
Answer:
The terraform refresh command updates the state file to reflect the current state of infrastructure without changing any resources.
Use it when:
Resources have been modified outside Terraform.
To ensure the state file is up-to-date before running plan or apply.


# How can you optimize a Terraform configuration for a large-scale infrastructure?
Answer:
Use modules for reusability and to organize code.
Use count or for_each for resource replication instead of duplicating code.
Avoid inline variables; use variables.tf for better maintainability.
Implement remote state management with locking to avoid conflicts.
Use data sources to retrieve existing resources instead of re-creating them.


#  How do you reduce Terraform execution time for large-scale environments?
Answer:

Split configurations into smaller modules and apply them independently.
Use parallelism (-parallelism flag) to process multiple resources concurrently
terraform apply -parallelism=10
Use resource-level dependency graphs to avoid unnecessary waits.


# How do you handle shared variables and secrets in Terraform across teams?
Answer:
Shared Variables: Use a central location like a Git repository for *.tfvars files.
Secrets: Use secure storage solutions:
AWS Secrets Manager: Store credentials securely and use a data block to retrieve them.
HashiCorp Vault: Integrate Vault with Terraform.	
# Describe a time when Terraform failed during a deployment in production. How did you handle it?
Answer:
Scenario: terraform apply failed due to an IAM permission issue.
Resolution:
Reviewed the error logs to identify the missing permissions.
Updated the IAM policy to include required permissions.
Re-ran the deployment.
Implemented better pre-deployment validation using terraform validate and plan




# How would you manage cross-account AWS resources using Terraform?

provider "aws" {
  alias  = "prod"
  region = "us-east-1"
}

provider "aws" {
  alias  = "dev"
  region = "us-west-2"
}
