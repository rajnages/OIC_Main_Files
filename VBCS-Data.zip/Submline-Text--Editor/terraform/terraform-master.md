####################################### Introduction to Terraform #####################################

# What is Terraform?
Terraform is a tool for provisioning, managing, and deploying infrastructure resources. It is an open-source tool written in Golang and created by the HashiCorp company. With Terraform, you can manage infrastructure for your applications across multiple cloud providers - AWS, Azure, GCP, etc. - using a single tool.

# What is Infrastructure as Code?
Infrastructure as Code is a way of defining and managing your infrastructure using code, rather than manual processes like clicking through a UI or using the command line.


# declarative and imperative programming
=> In imperative programming, the programmer tells the system how to do something by explicitly writing out all the steps in a specific order. For example, if you wanted to build a house, you would give instructions step-by-step: lay the foundation first, then build the walls, install the roof, and so on.

=> In declarative programming, you simply describe what you want as the end result, and the system figures out the best way to achieve it. For the same house example, you would just say, "I want a house with three bedrooms, two bathrooms, and a garage," and the system would figure out the order and logic to build it.

=> Terraform uses a declarative syntax, meaning you only need to declare what resources you want (e.g., "I need a virtual server with an attached storage volume and a network"). Terraform then automatically figures out the dependencies (e.g., the network must exist before the server can connect to it) and the correct order to create these resources.

# Here are the key benefits of Terraform:
Infrastructure as Code (IaC): Easily manage and version infrastructure using code.
Multi-Cloud Support: Works with various cloud providers like AWS, Azure, and GCP.
Declarative Syntax: Focus on the desired end state, and Terraform handles the execution order.
Automation: Automates resource creation, updates, and deletions.
Modularity: Enables reuse of code with modules for consistency and efficiency.
Collaboration: Teams can share and manage infrastructure configurations together.
State Management: Tracks infrastructure changes to prevent resource drift.
Cost Efficiency: Detects and removes unused resources automatically.

# Here are the key features of Terraform:
Infrastructure as Code (IaC): Define infrastructure using code for automation and version control.
Declarative Syntax: Focus on the desired end state rather than execution steps.
Multi-Cloud Support: Manage resources across various cloud providers like AWS, Azure, and GCP.
State Management: Tracks and stores infrastructure state for consistency and updates.
Modular Design: Reuse code with modules for scalable and organized configurations.
Dependency Management: Automatically handles dependencies between resources.
Extensibility: Supports custom providers and plugins.
Plan and Preview: Preview changes before applying them with terraform plan.

# Here are simple and short use cases for Terraform:
Cloud Infrastructure Provisioning: Automate creating servers, networks, and storage across AWS, Azure, GCP, etc.
Multi-Cloud Management: Manage resources in multiple clouds with a unified tool.
Environment Management: Create consistent dev, staging, and production environments.
Disaster Recovery: Quickly rebuild infrastructure in disaster recovery scenarios.
CI/CD Integration: Automate infrastructure changes in CI/CD pipelines.
Infrastructure Scaling: Dynamically scale resources to handle traffic or workloads.
Kubernetes Management: Provision and manage Kubernetes clusters and resources.
Compliance Automation: Enforce policies with Terraform Sentinel for security and compliance.


# Difference between chef,ansible,cloud formation, terraform, puppet
1. Terraform
   - Focuses on infrastructure provisioning using Infrastructure as Code (IaC).
   - Works across multiple cloud providers like AWS, Azure, and GCP.
   - Uses a declarative approach to define desired states.
   - Best for creating and managing cloud infrastructure.

2. Ansible
   - Primarily for configuration management and application deployment.
   - Uses an agentless approach with YAML playbooks.
   - Automates tasks like package installation and system updates.
   - Supports both on-premises and cloud environments.

3. Puppet
   - Specialized in configuration management with a client-server model.
   - Uses its own declarative language for automation.
   - Ideal for managing large-scale, consistent server configurations.
   - Requires agents installed on managed nodes.

4. Chef
   - Focuses on configuration management with a code-centric approach.
   - Uses Ruby-based recipes to define configurations.
   - Offers flexibility for complex setups and workflows.
   - Requires agents to apply configurations.

5. CloudFormation
   - AWS-specific IaC tool for provisioning resources.
   - Uses JSON or YAML to define cloud infrastructure.
   - Automatically manages dependencies between resources.
   - Best for AWS-native environments.


######################### terraform basics ###########################################################

Providers:
Providers are plugins in Terraform that allow interaction with various cloud services and APIs (e.g., AWS, Azure, Google Cloud) to manage resources.

Resources:
Resources represent the infrastructure components that Terraform manages (e.g., EC2 instances, S3 buckets) and defines their desired state.

Data Sources:
Data sources allow Terraform to fetch information from existing resources or external sources to use in configurations.

Terraform State:
The state is a snapshot of the infrastructure managed by Terraform, used to track and compare the current state with the desired state.

Execution Plans:
Execution plans are generated by terraform plan to preview the changes Terraform will make to infrastructure, such as creating, modifying, or deleting resources.

Modules:
Modules are reusable Terraform configurations that allow organizing and structuring infrastructure code for better maintainability and modularity

Backend:
A backend in Terraform determines where the state file is stored (local or remote) and how it is managed (e.g., S3, Consul).

Provisioners:
Provisioners allow executing scripts or commands on a resource after it's created, often used for configuration tasks.

Workspaces:
Workspaces are isolated environments within a Terraform configuration, useful for managing multiple environments (e.g., dev, prod).

Terraform Plan:
terraform plan generates an execution plan, showing what actions Terraform will take to align the infrastructure with the desired state.

Terraform Apply:
terraform apply executes the changes described in the execution plan and updates the infrastructure accordingly.

Variables:
Variables in Terraform let you set values that can change, like region or instance type, making your setup more flexible and reusable.

Outputs:
Outputs are values that Terraform shows after applying the configuration, helping you share important information, like IP addresses, between modules or systems.


# WorkFlow of terraform
terraform init:
Initializes the working directory and downloads necessary provider plugins. It also creates .terraform directory to store provider and module data (like git init does for Git).

terraform plan:
Generates a preview of the changes Terraform will make to reach the desired state, based on the configuration and current infrastructure state.

terraform apply:
Applies the changes described in the plan to update the infrastructure to match the desired state. It updates the current state.

terraform destroy:
Destroys the resources defined in the configuration, effectively removing the current infrastructure (reverting the state).

# resource lifecycle
- Resource lifecycle (create, read, update, delete)


========================================================================================================


# variables and types variables
# Summary of Variable Types:
string
number
bool
list(<type>)
map(<type>)
set(<type>)
object({ <name> = <type>, ... })
tuple([<type>, ...])
any

# outputs and showing
output block: Used to define the output value.
description (optional): Provides a brief explanation of the output.
value: The value to be returned as output, in this case, the EC2 instance ID.


# Terraform CLI Variable Overrides
terraform apply -var "region=us-west-1" -var "instance_type=t2.micro"
terraform apply -var-file="variables.tfvars"
export TF_VAR_region="us-west-1"
export TF_VAR_instance_type="t2.micro"



Variables Commands
terraform plan -var="key=value"
terraform plan -var-file="filename.tfvars"
terraform apply -var="key=value"
terraform apply -var-file="filename.tfvars"
terraform console

Outputs Commands
terraform output
terraform output <output_name>
terraform output -json

State File Commands
terraform state list
terraform state show <resource>
terraform state rm <resource>
terraform state mv <old_resource> <new_resource>
terraform state pull
terraform state push
terraform state backup

====================================================================================================================

# workspaces and modules

Workspace: Used to manage different environments (e.g., dev, prod) within the same Terraform configuration. It creates separate state files for each environment.
Example: Separate state files for dev and prod in an S3 bucket.

Module: A reusable, self-contained block of code that defines specific resources or functionality. It helps organize and standardize configurations.
Example: A module for creating EC2 instances, VPCs, or S3 buckets that can be used across multiple projects.


export AWS_ACCESS_KEY_ID=AKIA5FTZB7HUYMJXE3W3
export AWS_SECRET_ACCESS_KEY=jzoGGM2p1c9J9cair2kRVP0OJXes7XSOxvWGcO54
export AWS_DEFAULT_REGION=us-east-1


Use count when the decision is binary (create or don't create).
Use for_each when you need to iterate over a collection (map or set).
Leverage conditional logic with ternary operators for dynamic values.
Dynamic blocks are essential for repeating configurations within a resource or module.


====================================================================================================================
# Logs and Debugging Output
a. Using TF_LOG for Debugging
Purpose: Terraform provides extensive logging capabilities through the TF_LOG environment variable to help debug issues. Setting the log level to TRACE, DEBUG, INFO, WARN, or ERROR provides different levels of verbosity.

Usage:
TRACE: Most detailed logging, includes internal details.
DEBUG: Detailed information for debugging.
INFO: Normal operation logs (default).
WARN: Warnings indicating potential issues.
ERROR: Only error messages


terraform state pull > state_backup.tfstate  # Backing up the state
terraform state push state_backup.tfstate    # Restoring the state


# State Drift:
- Symptoms: The state file no longer reflects the actual infrastructure, which can happen if resources are modified manually.
- Solution: Use terraform refresh to update the local state to match the real infrastructure.

- Use terraform plan regularly: This command provides you with a dry run of what Terraform plans to do, which is often the first place to spot errors.



WARNING! dev mode is enabled! In this mode, Vault runs entirely in-memory
and starts unsealed with a single unseal key. The root token is already
authenticated to the CLI, so you can immediately begin using Vault.

You may need to set the following environment variables:

    $ export VAULT_ADDR='http://0.0.0.0:8200'

The unseal key and root token are displayed below in case you want to
seal/unseal the Vault or re-authenticate.

Unseal Key: 73qvoqemGnJbH8shZFmn/gMGz7JjNz6///Ez0CQjGIs=
Root Token: hvs.Vg4zyZNsXQkMjDTtYvqwEuc6
