Oracle ATP TNS/Service Name : devatp_high Password:7569235694@Nages, UserName: ADMIN
Oracle Fusion URL => https://fa-esll-saasfademo1.ds-fa.oraclepdemos.com
Username : fin_impl
password: demo.oraclecloud.com get the password

# Oracle Fusion Cloud Modules(SAAS Services):
1. Enterprise Resource Planning (ERP):
# Financial Management: Handles accounting, treasury, and tax processes.
1.Accounts Payable (AP): Sends payment data to Cash Management (CM) and accounting entries to General Ledger (GL).
2.Accounts Receivable (AR): Sends received payment data to CM and revenue entries to GL.
3.Fixed Assets (FA): Sends asset purchase and depreciation data to GL, and cash flow info to CM.
4.Expenses: Sends employee reimbursement data to CM and accounting entries to GL.
5.Cash Management (CM): Collects all cash inflow/outflow data and sends a summary to GL.
6.General Ledger (GL): Acts as the central accounting system, receiving data from all modules for financial reporting.


Role Of Skills:
1. Oracle Cloud Developer / Consultant:
   You would be responsible for building and deploying applications using Oracle’s low-code platforms (VBCS, APEX), 
   integrating them with other Oracle and third-party systems using OIC.
2. Integration Specialist / Middleware Developer:
	With OIC, you can design and implement integrations between SaaS and on-premise applications, 
	automate workflows, and manage APIs.
3. Full-Stack Oracle Developer:
   Combining front-end development in VBCS/APEX with back-end integrations via OIC, you can deliver end-to-end solutions.
4. Oracle Technical Architect:
   If you have experience designing solutions, you could architect cloud-native applications and 
   integrations using Oracle’s PaaS offerings.
5. DevOps Engineer (Oracle Cloud):
   With Visual Builder Studio, you can manage CI/CD pipelines, version control, and deployment 
   automation for Oracle applications.
   
=================================================================================================================================================


# Call BI reports in OIC
WSDL URL => https://eqjz.ds-fa.oraclepdemos.com/xmlpserver/services/ExternalReportWSSService?WSDL
SOAP => Adapter
Scheduled Integration-> Operation name “runReport”,
-> Ensure that an incoming structured payload from a BIP does not exceed 10 MB in size. 
   If the size of the payload exceeds 10 MB, an HTTP error code message is returned to the client.
   
====> BI reports parameters in mapping section:
=> attributeFormat – Defines the output format of the report (e.g., PDF, Excel, CSV, etc.).
=> attributeLocale – Specifies the locale for the report (e.g., en_US, fr_FR).
=> reportAbsolutePath – Provides the full path to the report in the BI Publisher repository.
=> sizeOfDataChunkDownload – Controls the amount of data returned; -1 retrieves all data.
=> parameterNameValues – Allows dynamic passing of report parameters and values.
Take an assign action and decode the base64 reaponse to reference using decodeBase64ToReference() function

opaque schema provided by oracle this is used in stage file mapped to response this file reference.
after send to the mail that file

=====================================================================================================================

# OTBI and BI Publisher reports
-> OTBI (Oracle Transactional Business Intelligence).
-> BI (Business Intelligence) reports.
-> Data model -> Query  / parameters
-> Report -> Design Template pdf/text/xml/excel


===========================================================================================
Send An Email Attachment BI Reports Using SOAP Adapter and StageFile
Report Path : "/~FIN_IMPL/ankit rr/bip_1.xdo"
URL : https://eqjz.ds-fa.oraclepdemos.com/xmlpserver/services/ExternalReportWSSService?WSDL
BIP mapping in oic -> Body -> runReport -> reportRequest have so many parameters like
                      (sizeOfDataChunkDownload,reportAbsolutePath,parameterNameValues)

==========================================================================================
# Call BI Report using OIC
URL -> https://eqjz.ds-fa.oraclepdemos.com/xmlpserver/services/ExternalReportWSSService?WSDL
Report Path -> /Custom/Nag_PO_HEADERS_ALL_Second.xdo
FTP -> fs-testing-purpose-axaevnx0kuxw-hy.integration.ap-hyderabad-1.ocp.oraclecloud.com
Port -> 10176
FTP Path -> /home/users/rajavarapu.nageswarao@capgemini.com
					  
===============================================================================================

# FBDI => file based data import like bulk data
-> to load large amount of volumes of data into oracle cloud using predefined execl or csv Templates
-> import data in a structured and validate way through oic or manual upload

# Steps:
1. Prepare the FBDI Template
2. Upload to UCM -> Universal content Management
3. Trigger import job via OIC

=> FBDI itself is a template and process but when used with oic or ESS enterprise scheduler service it becomes a fully automated
   bulk data processing solution.
=> UCM -> universal content managment it is oracle's internal file repository used mainly by oracle fusion applications
          to store and retrieve files. especially during FBDI,BIP or integration processes.
=> ESS -> Enterprise Scheduler Service -> it is oracle's cloud job Scheduling engine used to run background processes in ERP,SCM,HCM
          these jobs can be manually started, Scheduled or triggered automatically by tools like oic or BI Publisher
		  
---> Preparing Excel sheets:
1. PO_HEADERS_INTERFACE
2. PO_LINES_INTERFACE
3. PO_LINE_LOCATIONS_INTERFACE
4. PO_DISTRIBUTIONS_INTERFACE		  

----> FTP setup
FTP -> fs-testing-purpose-axaevnx0kuxw-hy.integration.ap-hyderabad-1.ocp.oraclecloud.com
Port -> 10176
FTP Path -> /home/users/rajavarapu.nageswarao@capgemini.com  -> password : Eswarsai@799

---> Lookup details
interface_id, interfacename, source, target, source_dir, file_name_pattern


--> in integration 
    -> schedule -> assign variables(Lookup values store) -> invoke FTP List files
	-> next for each loop to retrieve file in After list files
	-> inside for each loop download file for FTP server
	-> switch -> because of different files we need retrieve  -> files
	-> inside switch stage file -> read entire file ->after text in debug


-> In Fusion
 Job -> Load Interface File for Import
 Import Processes -> Import Orders -> Purchasing
 file -> as you generated zip file
 
-> Next run job
   job -> Import Orders -> Purchasing


-> ERP Cloud
  UCM -> prc/purchaseOrder/import
  Package Name -> /oracle/apps/ess/prc/po/pdoi;ImportSPOJob
  interfaceid: 21

###################################################################################################

# ERPBusinessEvents
-> Business Events as notifications or alerts that Oracle ERP sends out when something important happens.
   Example: -> A purchase order is approved
			-> A supplier is created
			-> An invoice is paid
			-> These events can be subscribed to in OIC to initiate integrations automatically.
			
	Flow: -> ERP emits a business event (e.g., "Invoice Created").
		  -> OIC listens for that event via the ERP Adapter.
          -> Integration flow is triggered, performing actions like:
		  -> Sending an email
          -> Calling a REST API
		  -> Updating another system
	
	Events -> Publish,subscribed
	       Publish -> sents the message and notification
		   subscribed -> listen that message and reacts
		   
		   
######################################################################################################################

-> Cycles of all oracle O2C (Order to Cash), P2P (Procure to Pay)

