# Cloud Native:
=> cloud native is a modern software approach that uses cloud technologies, microservices, containers, and automation to build
   scalable,resilient, and flexible applications.
   
-> scalable -> A scalable system can handle more users or data by adding more resources—and reduce them when not needed.
-> resilient -> Resilient means the software can keep working even when something goes wrong.
-> flexible -> A flexible system can quickly adapt to new requirements, technologies, or environments.

# stack:
1. infra layer
2. provisioning layer
3. runtime layer
4. orchestration and management layer
5. Application defination and development layer
6. observability and analysis tools


# Docker, kubernates,Devops,CI/CD, API
