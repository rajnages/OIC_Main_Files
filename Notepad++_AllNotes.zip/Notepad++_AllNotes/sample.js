const arr = ["sample","sample"]
console.log(arr)

