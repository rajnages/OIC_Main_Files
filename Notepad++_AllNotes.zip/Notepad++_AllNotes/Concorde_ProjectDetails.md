-> Type of Users:supplier portal users, and HPA and Normal users -> access IDM portal
->Application tier is the oracle fusion cloud/concorde cloud -> SAAS
  Application tier place inside VCN in oracle cloud
  Modules is operating -> sourcing,S&OP and supply planning
->geaviationgov -> this is the paas instance name -> like OIC gen2 -> PAAS
-> integrated servers->thorugh SFTP ->GC,ComputeSFTP,SSS, Bridger,CP
                     ->through REST and Email ->BOX, Webmethod
                     ->ODBC ->PAAS DB
# 11,12,13 Days INT KT sessions
OIC integrations support
SFTP Connections -> NO
Bridger Integration -> SOP -> onboarding,on-going-> supplier address details validation
SSS Supplier Integration -> SOP
CP Supplier Integration -> SOP
IDM to Concorde User Integrarion -> SOP
User Deactivation Process and Integration -> SOP
Concorde to Support Central DB  Supplier Integration -> SOP
Item Integration from CP to Concorde



======================================================================================================================================================================
Confluence page: https://devcloud.swcoe.ge.com/devspace/pages/viewpage.action?spaceKey=UOEUF&title=Cloning+SaaS&preview=/2391973392/2391973424/Concorde%20Clone%20Strategy.pptx
-> Cloning Process 
# PRODUCTION-TO-TEST (P2T)
  Refresh from a production (source) environment to a non-production (target) environment.
# TEST-TO-TEST (T2T)
  If you have multiple non-production environments, you can refresh from one non-production environment to another.
# REFRESH POINT
  A refresh uses the latest backup of the source environment. The refresh point tells you the timestamp of the source backup that was used. 
  Note that because the backup is used, data entered or changed after the source backup was taken but before the refresh was initiated, won't be included.

20897380


10 -> Non prod outage communications
11 -> 


The next Oracle ERP Cloud release will be 25D, according to Oracle Help Center. 
Based on Oracle's quarterly update schedule, with 25C released in August, the 25D release will likely be deployed in November 2025. 
Test environments for Cohort A would receive the update on the first Friday of November, with production environments updated two weeks later


Additional Maintenance # In order to maintain the FEDRAMP certification Oracle preforms following maintenance activities :
§Monthly Maintenance # Every Month 3rd Friday  ( Outage required) – Production
§Every 1st Friday of the month – Non productions
§Server FEDRAMP security patches ( weekly) – (Outage Not required)




===================================================================================================================================================================

=======================================================================================================
What are the instances we are doing backup cloning, like P2T All other  instances
why we are doing backup Cloning
What are the access required --> instances, roles
after and before Emails to send anyone,or any group chat --> Doubt
at what Time backup -> 


what time to take backup -> time limit also they provide after instances leases
need to inform anyone in group chat
what will happen if we don't take backup -> 
why we take backup 
need to mail anyone before or after clone 
if yes any sample mail for pre/post cloning
how do we know cloning activity completed -->like mail or group chat
for all instance doing clone activity or specific instance
========================================================================================================
-> After P2T clone  -->
Doubt -> what are the Source instance and target instance
1. Before the clone:
   -> Report Name: GEA_User_Role_Details_Report 
   -> Doubt -> it is getting Cloned
   -> and prepare the data file by applying VLOOKUP in both Outputs.
2. After clone:
   -> Remove roles from Prod NPA's
   -> Non-Prod NPA 502832266
   -> NPA_Users 502818229, 502818230 and 502819895 needs to be deactivated
   -> And All the Roles in these accounts needs to be added to the User 502832266
   
   
-> 








table -> roles name



GEA_CONCOEDE_P2T_T2T_USERS_RESTORATION
