PageModule.prototype.testing = function (qualification, demandid) {
    // if (!demandid || demandid.trim() === '') {
    //   console.error('Invalid Demand ID');
    //   return 'Error: Invalid Demand ID';
    // }

    console.log('Qualification:', qualification);
    console.log('Demand ID:', demandid);

    let empty = '';

    if (qualification) {
      if (demandid) {
        if (qualification === 'DE') {
          empty = `activeFlag='Y' AND globalPractice = 180 AND teamRequestNumber = '${demandid}'`;
        } else if (qualification === 'PSC') {
          empty = `activeFlag='Y' AND pSCQualified = 'No' AND teamRequestNumber = '${demandid}'`;
        } else if (qualification === 'Cap') {
          empty = `activeFlag='Y' AND capabilityQualified = 'No' AND teamRequestNumber = '${demandid}'`;
        }
      } else {
        if (qualification === 'DE') {
          empty = `activeFlag='Y' AND globalPractice = 180`;
        } else if (qualification === 'PSC') {
          empty = `activeFlag='Y' AND pSCQualified = 'No'`;
        } else if (qualification === 'Cap') {
          empty = `activeFlag='Y' AND capabilityQualified = 'No'`;
        }
      }
    } else {
      empty = `activeFlag='Y' AND teamRequestNumber = '${demandid}'`;
    }

    console.log('Generated Query:', empty);
    return empty;
  };




    

  



       