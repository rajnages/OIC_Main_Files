# Self intro:
1.	Good afternoon, My self Rajavarapu Nageswarao and I am from Adhra Pradesh, 
    and I have 2.6 years of experience as a Senior Analyst at Capgemini.
2.	durig my time I developed web applications using Oracle VBCS and integrated them with other systems through 
    OIC using REST APIs.
3.	As part of my project, I developed several dashboards using Oracle VBCS, including timecards, employee details, 
    employee training, shadow details, and file uploads, along with key modules like onboarding, transfers, and approvals.
4.	My technical skillset includes Oracle Visual Builder Studio, Oracle JET, Redwood UI templates, and JavaScript, 
    which I use to build clean and professional user interfaces.
5.	Additionally i have strong hands-on experience with Oracle Cloud, AWS Cloud, DevOps tools, as well as SQL, 
    PL/SQL, and Oracle APEX and OIC.
6.	I have completed AWS and OCI foundational training and certifications, and I am currently preparing for the OIC certification 
    as well as the Oracle VBS Redwood certification for Oracle Cloud application customizations to further enhance my skills in 
	cloud development and integration.

# Why do you want to work here?
  i have been following your company for a while and i am really impressed by your focus on innovation especially in 
  oracle cloud technologies. so im looking for a company that values continuous learning and teamwork and
  i believe this role offers the perfect environement to contribute and grow.
  
  
# Why are you looking for a job change?
  i'm looking for new challenges and oppurtunities to grow both technically and professionally. 
  while i have learned a lot in my current role i feel it's the right time to exploare a dynamic environement
  where i can work in more technologies and have broader responsibilities.
  
# where do you see yourself in 5 years?
  in 5 years i see myself in a senior role where im leading a team, 
  mentoring juniors and contributing to key business decisions-possibly as a cloud or solution architect 
  i also hope to be certified in multiple cloud technologies.
  
# why should we hire you?
  i bring hands-on experience in oracle cloud technologies i'm adaptable and i love solving the problems.
  i 'm confident i can quickly understand your system and start contribution from day one while continuously improving
  myself and the team.
  
  
# Salary expectations?
  based on my 2.7 years of experience working with oracle vbcs and oic and paas solutions along with the current industry
  standrds for similar roles outside oracle
  i'm looking for a compensation package in the range of 10 to 12 LPA
  However i am open to discussion based on the role, responsibilities and overall benefits.
  
  ======= or ========
  
  i am expecting around 10 to 12 LPA  based on my experience and market trends but i am open to discussing it futher
  depending on the full package and role fit.
  
# Tell me about your strengths?
   my strengths include quick learning, adaptability and strong problem-solving skills. i m also good at collabration across teams
   and delivering under tight deadline. i often take initiative when something needs to be improved
   
# what is your biggest weekness?
  i used to struggle with delegation and preferred to do tasks myself. but i have realized that trusting teammastes
  distributing work leads to better productivity now i consiciously make efforts to delegate effectively

# How to handle stress or pressure?
  i stay calm and prioritize my tasks i break down complex problems into smaller steps and focus on one thing at a time.
  also i communicate with my team or manager early if i loose and delays which helps reduce last-minute stress.
  