=> eks
1. EKS (Elastic Kubernetes Service) is a managed service by AWS that helps you run Kubernetes clusters on the AWS cloud. It automates tasks like setting up, scaling, and managing Kubernetes so you can focus on deploying and managing your containerized applications.

- AWS EKS manages the Kubernetes master node for you (control plane). You only need to take care of the worker nodes, where your applications run.
Think of it like this:
1. EKS: Handles the brain (master node) of Kubernetes.
2. You: Manage the arms and legs (worker nodes) for your tasks.

=> Benifits:
1. AWS EKS is great because it manages the Kubernetes master nodes for you, so you don't have to worry about setting up or maintaining them. It integrates well with other AWS services, like IAM for security and CloudWatch for monitoring. EKS also scales easily, is highly reliable, and supports existing Kubernetes tools. AWS handles updates and patches for the control plane, which saves time and effort. Overall, it helps run Kubernetes clusters securely and efficiently, letting you focus on your applications.


===> differnece between kubernates and eks
- Kubernetes is an open-source container orchestration tool you manage yourself, while AWS EKS is a managed Kubernetes service. In EKS, AWS handles the master nodes (control plane) for you, so you only need to manage the worker nodes. EKS is great for simplifying Kubernetes operations on AWS

export AWS_ACCESS_KEY_ID=AKIAVRUVV3YUDYTHRBOM
export AWS_SECRET_ACCESS_KEY=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
export AWS_DEFAULT_REGION=us-east-1


===> high level architecture:
- In Kubernetes, you can think of it as a cluster inside a cluster. At the top level, you have the Kubernetes Cluster. Inside this cluster, there are nodes, which are individual machines that run workloads. Each node can have one or more pods, and each pod contains one or more containers. Containers are where the actual application runs


====================================================================================================================

-> pod:
1. pod is small box that holds one or more containers. 
2. containers inside a pod share resource like network, storage
3. It’s the basic unit that runs in Kubernetes.

-> containers:
1. A container is like a mini-environment where an application runs. 
2. It includes everything the app needs, like code and libraries. 
3. Containers are separate from each other but can work together if they're in the same pod. 

-> Deployment:
1. A deployment is a tool that helps you manage and update your pods. 
2. It makes sure you always have the right number of pods running and helps you update them without any downtime.

-> ReplicaSet:
1. A replica set makes sure that a certain number of identical pods are always running. 
2. If one pod stops, the replica set will create a new one to replace it.

-> Service:
1. A service gives a stable way to access your pods. 
2. It helps route traffic to the right pods, even if the pods change or restart.
 

---> Interviewer : tell me in simple terms , what kubelet does ? 
1. Kubelet makes sure that containers in a pod are running and healthy. 

----> Interviewer : okay, how does it know about container status ? 
1. Kubelet knows about the container status by regularly checking on it. It uses health probes, like simple checks to see if the container is running and responding correctly. If there's a problem, kubelet can restart the container to fix it.

----> Interviewer: okay, What are health Probes ? 
1. Health probes are checks that Kubernetes uses to ensure your application is running correctly. we can call them from our manifest file . 

- Readiness ProbeChecks if the app is ready to handle requests. If it fails, the pod temporarily stops receiving traffic.
- Liveness ProbebChecks if the app is running. If it fails, Kubernetes restarts the container.

Kubelet :) 



In Simple Terms:
EKS manages Kubernetes.
ECS manages Docker containers.
Fargate makes both EKS and ECS serverless, meaning it handles the underlying infrastructure automatically, so you don’t need to worry about managing servers.


############################################################################################################################

# aws ecs => AWS ECS (Elastic Container Service) is a service provided by Amazon that helps manage Docker containers. We use it to easily run, scale, and organize containerized applications without worrying about server setup or maintenance, enabling quick deployments and efficient workload handling."

# components:
1. cluster:
- A group of resources (EC2 instances or Fargate tasks) where your containers run.
- think of it => it's a container playground where all magic happens here

2. tasks
- What it is: A single running instance of your containerized application.
- Think of it as: A container's job. It defines what container to run and how.

3. task defination:
- What it is: The blueprint for running a task. It specifies details like the container image, CPU, memory, and network settings.
- Think of it as: A recipe or plan for creating tasks.
- Example: A task definition might say: "Use this Docker image, allocate 1 GB memory, and expose port 80."

4. Services
- What it is: Ensures your tasks are running and can scale them up or down.
- Think of it as: A task manager that keeps the specified number of tasks running.
- Example: If you need 3 instances of your web app running at all times, the service will make sure they’re running.


5. Container Agent
- What it is: A software that runs on EC2 instances and communicates with ECS to manage containers.
- Think of it as: The middleman between ECS and the servers (EC2).

1. cluster => group of resources like (ec2 or faragte) where we need to containers run(think of it container playground)
2. tasks => a single instace of your containerized application(it defines what container to run and how)
3. task defination => (it's blueprint of running tasks,this will provide cpu,memory,network)
4. container agent => (communication between ec2 instances and ecs containers)
5. services => (a task manager that keeps the specofied no of tasks running)
6. container instances =>  EC2 instances for running containers (if using EC2).
7. lanch types => EC2 (you manage) or Fargate (AWS manages).
8. load balancer => Distributes traffic to containers.
9. ecr  => Stores container images.


===========================================================================================================================