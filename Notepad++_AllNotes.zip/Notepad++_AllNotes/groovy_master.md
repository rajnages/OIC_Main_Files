-> groovy is a standlone, dynamic scripting langauge for the java platform for which the application composer provides
   deep support
   
-> Variables : def, Integer, String, boolean
-> adf.context
-> throw new oracle.jbo.ValidationException(message)
-> adf -> application development framework -> predefined object made avalible in groovy scripting in oracle fusion that gives you access yo contextual info
   like the current user, current object, session details, new/old attribute values
-> When writing scripts that execute in the context of the current busi 
   you can reference the value of any field in the current object by simply using its API name.
   
   
3rd party systems
GECars -> 
IBS -> Internal Billing System -> Internal Customers open invoice
PMG -> planning and manufacturing


MD100,MD200
BR200

1. RITM and Change Request -> Code Changes, OTBI Changes -> RITM,INC.
2. RITM -> Some Minor Changes comes under.
3. OTBI and Template Changes 
4. Code Changes and how we need to add in CCB
