========================================================================================================================
=> Scope Activity in OIC Like a Try-Catch-Finally block in programming.
Component	   	             Purpose
Scope	                     Groups a set of actions into a single unit. Useful for modular design and error handling.
Try Block(main block)	     The main logic goes here. This is where you place the steps you want to execute.
Catch Block(fault handler)	 Handles errors if anything fails inside the Try block. You can define fault handlers here.
Finally Block	             Executes steps regardless of success or failure. Useful for cleanup or logging.

==========================================================================================================================
-> Global Fault handler -> This is used entire integration 
                        -> Acts as a catch-all mechanism for errors that are not handled within specific scopes.
						-> If an error occurs anywhere in the integration and is not handled within a specific scope, 
						   the Global Fault Handler takes over.
						   
-> Normal fault handler -> This is used Specific Scope or block
						-> Handles errors locally within a defined scope.
						-> If an API call fails within a scope, the Normal Fault Handler 
						   can retry the request taking action.

-> Re-throw Fault: Passes the same error to another scope without modifying it.
-> Throw New Fault: Catches an existing error and throws a new, custom error message.
					example: Unable to retrieve employee details. Please check the employee ID

========================================================================================================================

=> How to send error details as an attachment in OIC:
   -> Use a Scope, which creates two sections by default: Main (safe block) and Fault Handler (error handling).
   -> Inside the Scope, you can access detailed error information using the fault object, which includes:
      -> errorCode
      -> reason
   -> You can also access integration metadata using the self object, which provides:
      -> metadata.integration
      -> metadata.runtime
      -> metadata.environment
   -> Store all these details in Assign variables, and then use them in the Notification component to send an 
      email with the error details.
	  
=========================================================================================================================

=> Data stitch : is used That allows complex data structures especially repeating elements it supports operations like
                 Assign, Append and Remove.

=> Assign Variables => Assign Variables is for straightforward value assignments.

=> Mapper => Mapper is used transform one Data format to another data format
			 Example: mapping a json payload from a rest api to an xml structure expected by soap service.

=> repeating element => repeatable elements in the mapper section refer to elements that can appear multiple times in a data structure.

=> Logger => is used for dubbugging and logging and monitoring Purpose.

=> Stagefile: is used to temporory store and manipulate files within the integration flow. 
              it allows operations Like read,write,list,zip,unzip, Delete files
			  
==================================================================================================================================

=> XSLT (Extensible Stylesheet Language Transformations) : 
   -> XSLT Functions => string(concat, substring) 
                     => mathematical (sum, floor), Dates (format date, current-datetime)
                     => boolean, conversion,nodeset, 
					 => Advanced functions like decodebase64, decodebase64ToReference
					    encodebase64, encodebase64ToReference, current Group
						
   -> XSLT operations => =, !=, > < , +, &, multiplcation, modules
   -> XSLT Statements => xsl:if, xsl:choose, xsl:for-each
   -> XSLT Templates => named template, match template
   -> XSLT variables => global, local
   -> XSl contructors => Flow control, output
                      -> flow control -> choose,for each,if,while,otherwise
					  -> output -> value of, text