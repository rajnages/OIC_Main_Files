# Start with Oracle cloud
=> OCI Basics -> Instances,VCN,storage
# Backend 
=> OIC -> Adapter,integration patterns,error handling
#frontend
=> VB,VBCS -> JS,HTML,CSS,JET,DevOps,Oracle SAAS Applications
# DB
=> APEX -> SQL,PLSQL
# Automation workflows
=> Processes Automation -> Workflows 