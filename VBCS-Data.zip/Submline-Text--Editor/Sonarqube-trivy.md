Trivy Scanner:
=>Primary Focus: Containers (Docker images, Kubernetes clusters, etc.) and Infrastructure 
file systems, Git repositories).
=>Use Case: Scans container images and infrastructure for vulnerabilities 
(such as security flaws, outdated dependencies, and configuration issues).
=>Scope: Primarily used to detect security vulnerabilities in containerized applications, 
including operating system packages and application dependencies 
(e.g., libraries in Python, JavaScript, etc.).

SonarQube:
=>Primary Focus: Code Quality and Static Code Analysis.
=>Use Case: Scans the source code for bugs, vulnerabilities, code smells, and technical 
debt. It enforces coding standards and helps maintain high-quality, secure code 
throughout the software development process.
=>Scope: Primarily used to identify issues in the codebase, including coding errors, 
security flaws, and maintainability problems.

Key Difference:
=>SonarQube focuses on code quality and static code analysis to improve code practices 
and security from a software development perspective.
=>Trivy focuses on container security and scanning for vulnerabilities in images, 
infrastructure, and dependencies to ensure security in a deployment environment.

========================================================================================================================

1. DevOps:
=>What it is: DevOps is a culture and set of practices that combine software development (
Dev) and IT operations (Ops) to enhance collaboration, automation, and the continuous delivery 
of software.
=>Key Focus:
Collaboration between development and operations teams.
Automation of software delivery and infrastructure management.
Continuous integration (CI) and continuous delivery (CD) of applications.
=.Goal: Improve the speed, quality, and reliability of software delivery and operations.

2. GitOps:
=>What it is: GitOps is an approach to continuous delivery that uses Git as the single source of 
truth for declarative infrastructure and application deployment.
=>Key Focus:
Version-controlled infrastructure and application code stored in Git repositories.
Automated deployment via Git operations (e.g., push changes to Git triggers deployment).
Declarative infrastructure, where infrastructure is defined as code (e.g., using tools like Kubernetes, 
Terraform).
=>Goal: Achieve easy and reliable deployments by using Git as the source of truth, automating 
infrastructure and deployment management.

3. DevSecOps:
=>What it is: DevSecOps is an extension of DevOps that integrates security practices into the 
DevOps pipeline, ensuring that security is part of every stage of software development and delivery.
=>Key Focus:
Security as code: Automate security checks and integrate security into CI/CD pipelines.
Collaboration between development, operations, and security teams.
Automated security scanning and continuous monitoring.
=>Goal: Ensure security is integrated from the start, making it an essential part of the development lifecycle, not an afterthought.

Key Differences:
DevOps focuses on collaboration, automation, and continuous delivery of software between dev and ops 
teams.
GitOps simplifies continuous delivery by using Git as the central control point for infrastructure 
and deployment.
DevSecOps emphasizes integrating security into the entire DevOps lifecycle, ensuring that security 
is not compromised during rapid software development and delivery.