# Self
My Self rajavarapu Nageswarao I have a total of 2.7 years experience in capgemini. out of this i have 2.5 years of specialized experience working with oracle cloud technologies. including Oracle VBCS,OIC,AWS and Devops tools and Oracle APEX and oracle VBS and Oracle BIP

================================================================================
Item INT from CP to Concarde
SOD INT
-> concarde system -> Supplier Maintainence
-> centerpiece system -> Supplier,Items-> GLO,SVO
-> SSS -> Payment system
-> webmethod system -> item integration -> we are pulling 23 items
-> BOX system
-> compute SFTP
-> IDM Portal

Source -> CP system, Creating,Updating Items Master details
SOD-> VBCS Form->corpoarte

SOX -> SOD -> HPA

concarde --> report -> GLobal scape -> OIC -> calling api -> 30 NPA Accounts -> publishing in the dashboard
OIC ->

--------------------------------------------------------------------------------

-> Main systems:
1.tread connect
2.OIC
3.GC
4.web method
5.BOX
6. Center Piece

->IDM,Paas Apex,Bridger
->SSS -> payment systems
->SOD,SOX,HPA


----> Concorde, Middleware, Legacy
# concorde is the supplier portal, user roles, user creation
# new supplier register, supplier address validation,supply planning capacity planning,SSS supplier data,CP supplier data,Items,Supplier extract,Negotiation and user supplier,HPA Data
# computeSFTP
#

===============================================================================
-------->Concorde SOX
Sourcing  -> Concorde SOX
supplier -> few negotiation
            supplier contact
            Qualification
Planning -> supply planning
            S&OP
            Capacity planning
Audit parameters This is yearly Audit This is external
        -> Change control ->
        -> HPA -> High priviledge account, Audits
        -> NPA. -> Non Personal Accounts
        -> IT SOD -> Related to IT SOD - Segreation of Duties
        -> IT BSA -> BSA
        -> Job monitor ->
        -> Authentication
        -> Provisioning -> Access the provisioning
        -> DeProvisioning -> De provisioning Access like deactivation
        -> Transfer and JOb changes
        -> Deloite Audit Portal in the we have questions we need answers the questions

-> internal Audit
       -> ITBSA (Monthly)
       -> IT SOD(Monthly)
       -> HPA (QAR)(Quarterly) -- Workflow -> role set file so that persons comes HPA role set it is covers across all modules
       -> Quarterly Folder Backtrack(Quarterly)
-> role set or rule category
    ->BSA
    ->BSA_HPA
    ->HPA
    ->HPA_Deployer
    ->IT_HPA
    ->IT_HPA_DEPLOYER
->HPA -> Quarterly -> Non of IT peoples
->IT/BSA -> Monthly -> Non of IT peoples
-> Deployer/Development ->


--------------------------------------------------------------------------------

CAB -> CR
