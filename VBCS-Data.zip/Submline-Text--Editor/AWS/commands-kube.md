1. kubectl get pods/po
2. kubectl describe pod<pod_name>
3. kubectl logs <pod_name>
4. kubectl exec -it <pod_name> -c <container_name> -- bash
5. kubectl top pod/po
6. --options
7. kubectl delete pod <pod_name>
