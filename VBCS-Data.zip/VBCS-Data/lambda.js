const { EC2Client, RunInstancesCommand } = require("@aws-sdk/client-ec2");
const { S3Client, CreateBucketCommand } = require('@aws-sdk/client-s3');



// Create an EC2 client
const ec2Client = new EC2Client({ region: "us-east-1" });
const s3Client = new S3Client({ region: "us-east-1" });

async function launchInstance() {
    const params = {
        ImageId: 'ami-0c55b159cbfafe1f0',  // Replace with your AMI ID
        InstanceType: 't2.micro',
        MinCount: 1,
        MaxCount: 1
    };

    try {
        const data = await ec2Client.send(new RunInstancesCommand(params));
        console.log("Instance launched:", data.Instances[0].InstanceId);
    } catch (err) {
        console.error("Error launching instance:", err);
    }
}

async function CreateS3Bucket() {
    const params = {
        Bucket: 'SampleBucketForTesting1234',
    };
    
    try {
        const data = await s3Client.send(new CreateBucketCommand(params));
        console.log("Bucket created:", data.Location);
    } catch (err) {
        console.error("Error creating bucket:", err);
    }
}

async function uploadFile() {
    const params = {
        Bucket: 'SampleBucketForTesting1234',
        Key: 'example.txt',
        Body: 'Hello, World!'
    };

    try {
        const data = await s3Client.send(new PutObjectCommand(params));
        console.log("File uploaded:", data.Location);
    } catch (err) {
        console.error("Error uploading file:", err);
    }
}

launchInstance();
CreateS3Bucket();
uploadFile();


