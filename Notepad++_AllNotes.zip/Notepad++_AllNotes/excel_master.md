-> workbook -> excel file
-> worksheet -> inside excel file data
-> columns -> A, rows -> 1
-> ctrl + left arrow and ctrl + down arrow ====> This is shows how many columns and how many rows exists in sheet.
-> in excel left align for text and right align for numbers -> be careful these values
-> even date values also align right side
-> Date format -> in number section in excel
-> microsoft power query:
   1. Microsoft Power Query is an essential Extract, Transform, Load (ETL) tool integrated within Excel, Power BI, and other Microsoft products.
   
   


